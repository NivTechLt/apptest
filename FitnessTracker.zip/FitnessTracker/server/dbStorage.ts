import { db } from './db';
import { IStorage } from './storage';
import { 
  User, InsertUser, Workout, InsertWorkout, Goal, InsertGoal, UpdateSubscription,
  Friendship, InsertFriendship, Challenge, InsertChallenge, ChallengeParticipant, InsertChallengeParticipant,
  users, workouts, goals, friendships, challenges, challengeParticipants
} from '@shared/schema';
import { eq, desc, and, or, gte, lte, sql } from 'drizzle-orm';
import { startOfWeek, endOfWeek, addDays } from 'date-fns';

export class DbStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }
  
  async getUserByStripeCustomerId(stripeCustomerId: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.stripeCustomerId, stripeCustomerId));
    return result[0];
  }
  
  async createUser(user: InsertUser): Promise<User> {
    // Remove the confirmPassword field as it's not in the database schema
    const { confirmPassword, ...userData } = user as any;
    const result = await db.insert(users).values(userData).returning();
    return result[0];
  }
  
  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const result = await db.update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }
  
  // Subscription operations
  async updateUserSubscription(id: number, subscription: UpdateSubscription): Promise<User | undefined> {
    const result = await db.update(users)
      .set(subscription)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }
  
  async updateUserStripeCustomerId(id: number, stripeCustomerId: string): Promise<User | undefined> {
    const result = await db.update(users)
      .set({ stripeCustomerId })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  // Workout operations
  async createWorkout(workout: InsertWorkout): Promise<Workout> {
    // Add calculated calories if not provided
    const workoutWithCalories = { 
      ...workout,
      calories: workout.calories || this.calculateCalories(
        workout.exerciseType, 
        workout.duration, 
        workout.intensity
      )
    };
    
    const result = await db.insert(workouts).values(workoutWithCalories).returning();
    return result[0];
  }

  async getWorkoutById(id: number): Promise<Workout | undefined> {
    const result = await db.select().from(workouts).where(eq(workouts.id, id));
    return result[0];
  }

  async getWorkoutsByUserId(userId: number): Promise<Workout[]> {
    return await db.select().from(workouts)
      .where(eq(workouts.userId, userId))
      .orderBy(desc(workouts.date));
  }

  async getRecentWorkoutsByUserId(userId: number, limit: number): Promise<Workout[]> {
    return await db.select().from(workouts)
      .where(eq(workouts.userId, userId))
      .orderBy(desc(workouts.date))
      .limit(limit);
  }

  // Goal operations
  async createGoal(goal: InsertGoal): Promise<Goal> {
    const result = await db.insert(goals).values(goal).returning();
    return result[0];
  }

  async getGoalById(id: number): Promise<Goal | undefined> {
    const result = await db.select().from(goals).where(eq(goals.id, id));
    return result[0];
  }

  async getGoalsByUserId(userId: number): Promise<Goal[]> {
    return await db.select().from(goals)
      .where(eq(goals.userId, userId))
      .orderBy(desc(goals.createdAt));
  }

  async updateGoal(id: number, updates: Partial<Goal>): Promise<Goal | undefined> {
    const result = await db.update(goals)
      .set(updates)
      .where(eq(goals.id, id))
      .returning();
    return result[0];
  }

  async deleteGoal(id: number): Promise<boolean> {
    const result = await db.delete(goals).where(eq(goals.id, id));
    return true;
  }

  // Statistics
  async getWeeklyStats(userId: number): Promise<{ 
    workoutCount: number; 
    totalMinutes: number; 
    totalCalories: number;
    dailyCounts: number[]; 
  }> {
    const today = new Date();
    const weekStart = startOfWeek(today, { weekStartsOn: 1 }); // Start from Monday
    const weekEnd = endOfWeek(today, { weekStartsOn: 1 });
    
    // Get workouts for the current week
    const weeklyWorkouts = await db.select().from(workouts)
      .where(
        and(
          eq(workouts.userId, userId),
          gte(workouts.date, weekStart),
          lte(workouts.date, weekEnd)
        )
      );
    
    // Calculate totals
    const workoutCount = weeklyWorkouts.length;
    const totalMinutes = weeklyWorkouts.reduce((sum, workout) => sum + workout.duration, 0);
    const totalCalories = weeklyWorkouts.reduce((sum, workout) => 
      sum + (workout.calories || 0), 0);
    
    // Calculate counts per day of the week (0 = Monday, 6 = Sunday)
    const dailyCounts = Array(7).fill(0);
    
    weeklyWorkouts.forEach(workout => {
      const workoutDate = new Date(workout.date);
      const dayOfWeek = (workoutDate.getDay() + 6) % 7; // Convert Sunday=0 to Sunday=6
      dailyCounts[dayOfWeek]++;
    });
    
    return {
      workoutCount,
      totalMinutes,
      totalCalories,
      dailyCounts
    };
  }

  // Utility operations
  calculateCalories(workoutType: string, duration: number, intensity: string): number {
    const intensityMultiplier = {
      'low': 5,
      'medium': 8,
      'high': 12
    }[intensity] || 8;
    
    const typeMultiplier = {
      'Running': 1.2,
      'Cycling': 1.0,
      'Swimming': 1.3,
      'Walking': 0.7,
      'Hiking': 0.9,
      'Yoga': 0.6,
      'Strength Training': 1.1,
      'HIIT': 1.4
    }[workoutType] || 1.0;
    
    return Math.round(duration * intensityMultiplier * typeMultiplier);
  }
  
  // Friendship operations
  async createFriendship(friendship: InsertFriendship): Promise<Friendship> {
    const result = await db.insert(friendships).values(friendship).returning();
    return result[0];
  }
  
  async getFriendship(userId: number, friendId: number): Promise<Friendship | undefined> {
    const result = await db.select().from(friendships).where(
      or(
        and(
          eq(friendships.userId, userId),
          eq(friendships.friendId, friendId)
        ),
        and(
          eq(friendships.userId, friendId),
          eq(friendships.friendId, userId)
        )
      )
    );
    return result[0];
  }
  
  async getFriendsByUserId(userId: number): Promise<User[]> {
    // First get all friendship records where this user has accepted friendships
    const friendshipRecords = await db.select().from(friendships).where(
      and(
        eq(friendships.status, "accepted"),
        or(
          eq(friendships.userId, userId),
          eq(friendships.friendId, userId)
        )
      )
    );
    
    // Extract the friend IDs from these records
    const friendIds = friendshipRecords.map(friendship => 
      friendship.userId === userId ? friendship.friendId : friendship.userId
    );
    
    if (friendIds.length === 0) {
      return [];
    }
    
    // Now get the user details for these friends
    const friendUsers = await db.select().from(users).where(
      sql`${users.id} IN (${friendIds.join(',')})`
    );
    
    return friendUsers;
  }
  
  async getPendingFriendRequests(userId: number): Promise<Friendship[]> {
    return db.select().from(friendships).where(
      and(
        eq(friendships.status, "pending"),
        eq(friendships.friendId, userId)
      )
    );
  }
  
  async updateFriendshipStatus(id: number, status: "accepted" | "rejected"): Promise<Friendship | undefined> {
    const result = await db.update(friendships)
      .set({ status })
      .where(eq(friendships.id, id))
      .returning();
    return result[0];
  }
  
  async deleteFriendship(userId: number, friendId: number): Promise<boolean> {
    const friendship = await this.getFriendship(userId, friendId);
    if (!friendship) return false;
    
    await db.delete(friendships).where(eq(friendships.id, friendship.id));
    return true;
  }
  
  // Challenge operations
  async createChallenge(challenge: InsertChallenge): Promise<Challenge> {
    const result = await db.insert(challenges).values({
      ...challenge,
      exerciseType: challenge.exerciseType || null,
      description: challenge.description || null,
      isPublic: challenge.isPublic !== undefined ? challenge.isPublic : true
    }).returning();
    return result[0];
  }
  
  async getChallengeById(id: number): Promise<Challenge | undefined> {
    const result = await db.select().from(challenges).where(eq(challenges.id, id));
    return result[0];
  }
  
  async getUserChallenges(userId: number): Promise<Challenge[]> {
    // First get all challenges created by the user
    const createdChallenges = await db.select().from(challenges)
      .where(eq(challenges.creatorId, userId));
    
    // Get all challenges the user participates in
    const participatedChallengesQuery = db.select({
      challengeId: challengeParticipants.challengeId
    })
    .from(challengeParticipants)
    .where(eq(challengeParticipants.userId, userId));
    
    const participatedChallengeIds = (await participatedChallengesQuery).map(
      record => record.challengeId
    );
    
    if (participatedChallengeIds.length === 0) {
      return createdChallenges;
    }
    
    const participatedChallenges = await db.select().from(challenges)
      .where(sql`${challenges.id} IN (${participatedChallengeIds.join(',')})`);
    
    // Combine both sets without duplicates
    const challengeMap = new Map();
    
    [...createdChallenges, ...participatedChallenges].forEach(challenge => {
      if (!challengeMap.has(challenge.id)) {
        challengeMap.set(challenge.id, challenge);
      }
    });
    
    return Array.from(challengeMap.values());
  }
  
  async getPublicChallenges(limit?: number): Promise<Challenge[]> {
    const baseQuery = db.select().from(challenges)
      .where(eq(challenges.isPublic, true))
      .orderBy(desc(challenges.createdAt));
    
    if (limit) {
      return await baseQuery.limit(limit);
    }
    
    return await baseQuery;
  }
  
  async joinChallenge(participant: InsertChallengeParticipant): Promise<ChallengeParticipant> {
    const result = await db.insert(challengeParticipants).values(participant).returning();
    return result[0];
  }
  
  async getChallengeParticipants(challengeId: number): Promise<(ChallengeParticipant & { user: User })[]> {
    // Get all participants for this challenge
    const participants = await db.select().from(challengeParticipants)
      .where(eq(challengeParticipants.challengeId, challengeId));
    
    if (participants.length === 0) {
      return [];
    }
    
    // Get the user details for all participants
    const userIds = participants.map(participant => participant.userId);
    const usersQuery = await db.select().from(users)
      .where(sql`${users.id} IN (${userIds.join(',')})`);
    
    // Create a map of userId to user object
    const userMap = new Map();
    usersQuery.forEach(user => {
      userMap.set(user.id, user);
    });
    
    // Join participants with their user details
    return participants.map(participant => {
      const user = userMap.get(participant.userId);
      if (!user) {
        throw new Error(`User with id ${participant.userId} not found`);
      }
      return {
        ...participant,
        user
      };
    });
  }
  
  async updateChallengeProgress(userId: number, challengeId: number, progress: number): Promise<ChallengeParticipant | undefined> {
    // Get the current participant record
    const [participant] = await db.select().from(challengeParticipants)
      .where(
        and(
          eq(challengeParticipants.userId, userId),
          eq(challengeParticipants.challengeId, challengeId)
        )
      );
    
    if (!participant) return undefined;
    
    // Get the challenge to check if the progress meets the target
    const challenge = await this.getChallengeById(challengeId);
    if (!challenge) return undefined;
    
    // Check if challenge is completed
    const completed = progress >= challenge.targetValue;
    const completedAt = completed && !participant.completed ? new Date() : participant.completedAt;
    
    // Update the participant's progress
    const result = await db.update(challengeParticipants)
      .set({ 
        currentProgress: progress,
        completed,
        completedAt
      })
      .where(eq(challengeParticipants.id, participant.id))
      .returning();
    
    return result[0];
  }
  
  async getLeaderboard(challengeId: number): Promise<(ChallengeParticipant & { user: User })[]> {
    const participants = await this.getChallengeParticipants(challengeId);
    
    // Sort by progress in descending order
    return participants.sort((a, b) => b.currentProgress - a.currentProgress);
  }
}

// Create a singleton instance
export const dbStorage = new DbStorage();