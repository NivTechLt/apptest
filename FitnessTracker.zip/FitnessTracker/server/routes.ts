import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertWorkoutSchema, insertGoalSchema, 
  insertFriendshipSchema, insertChallengeSchema, insertChallengeParticipantSchema,
  insertBodyMeasurementSchema, insertUserDeviceSchema, insertUserSettingsSchema
} from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { ZodError } from "zod";
import { isAuthenticated, setupAuth, hasSubscription, hashPassword } from "./auth";
import { createCheckoutSession, cancelSubscription, getSubscriptionPlans, handleStripeWebhook } from "./subscription";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);
  
  // Use storage to perform CRUD operations
  
  // Get weekly stats for a user
  app.get("/api/stats/weekly/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const stats = await storage.getWeeklyStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching weekly stats:", error);
      res.status(500).json({ message: "Failed to fetch weekly statistics" });
    }
  });
  
  // Create a new workout
  app.post("/api/workouts", async (req, res) => {
    try {
      const workoutData = insertWorkoutSchema.parse(req.body);
      const workout = await storage.createWorkout(workoutData);
      
      // Update goals progress after adding a workout
      // Get all goals for this user
      const goals = await storage.getGoalsByUserId(workoutData.userId);
      console.log("Found goals for user:", goals);
      
      // Update each goal's progress based on the new workout
      for (const goal of goals) {
        let shouldUpdate = false;
        let newValue = goal.currentValue;
        
        console.log(`Processing goal ${goal.id}: ${goal.name} (type: ${goal.type}, current: ${goal.currentValue}, target: ${goal.targetValue})`);
        
        // Check if this workout contributes to the goal
        if (goal.type === 'workout_count') {
          // Any workout counts towards workout_count goals
          newValue++;
          shouldUpdate = true;
          console.log(`- Workout count goal: incrementing from ${goal.currentValue} to ${newValue}`);
        } else if (goal.type === 'duration') {
          // Add duration of this workout
          newValue += workout.duration;
          shouldUpdate = true;
          console.log(`- Duration goal: adding ${workout.duration} minutes (new total: ${newValue})`);
        } else if (goal.type === 'distance' && workout.exerciseType === 'Running') {
          // For simplicity, we'll assume each running minute = 0.125 miles (8 min/mile pace)
          const estimatedMiles = workout.duration * 0.125;
          newValue += estimatedMiles;
          shouldUpdate = true;
          console.log(`- Distance goal: adding ~${estimatedMiles.toFixed(2)} miles from running (new total: ${newValue.toFixed(2)})`);
        } else {
          console.log(`- Goal type '${goal.type}' doesn't match this workout, skipping`);
        }
        
        // If goal should be updated, do it
        if (shouldUpdate) {
          // Check if goal is now completed
          const isCompleted = newValue >= goal.targetValue;
          console.log(`- Updating goal ${goal.id}: new value = ${newValue}, completed = ${isCompleted}`);
          
          try {
            // Update the goal
            const updatedGoal = await storage.updateGoal(goal.id, {
              currentValue: newValue,
              isCompleted
            });
            console.log(`- Goal update result:`, updatedGoal);
          } catch (error) {
            console.error(`- Error updating goal ${goal.id}:`, error);
          }
        }
      }
      
      res.status(201).json(workout);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          message: "Invalid workout data", 
          errors: fromZodError(error as ZodError).toString() 
        });
      }
      console.error("Error creating workout:", error);
      res.status(500).json({ message: "Failed to create workout" });
    }
  });
  
  // Get all workouts for a user
  app.get("/api/workouts/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const workouts = await storage.getWorkoutsByUserId(userId);
      res.json(workouts);
    } catch (error) {
      console.error("Error fetching workouts:", error);
      res.status(500).json({ message: "Failed to fetch workouts" });
    }
  });
  
  // Get recent workouts for a user
  app.get("/api/workouts/recent/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const limit = parseInt(req.query.limit as string || "3", 10);
      const workouts = await storage.getRecentWorkoutsByUserId(userId, limit);
      res.json(workouts);
    } catch (error) {
      console.error("Error fetching recent workouts:", error);
      res.status(500).json({ message: "Failed to fetch recent workouts" });
    }
  });
  
  // Get specific workout
  app.get("/api/workouts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid workout ID" });
      }
      
      const workout = await storage.getWorkoutById(id);
      if (!workout) {
        return res.status(404).json({ message: "Workout not found" });
      }
      
      res.json(workout);
    } catch (error) {
      console.error("Error fetching workout:", error);
      res.status(500).json({ message: "Failed to fetch workout" });
    }
  });
  
  // Goals endpoints
  
  // Create a new goal
  app.post("/api/goals", async (req, res) => {
    try {
      const goalData = insertGoalSchema.parse(req.body);
      const goal = await storage.createGoal(goalData);
      res.status(201).json(goal);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          message: "Invalid goal data", 
          errors: fromZodError(error as ZodError).toString() 
        });
      }
      console.error("Error creating goal:", error);
      res.status(500).json({ message: "Failed to create goal" });
    }
  });
  
  // Get all goals for a user
  app.get("/api/goals/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const goals = await storage.getGoalsByUserId(userId);
      res.json(goals);
    } catch (error) {
      console.error("Error fetching goals:", error);
      res.status(500).json({ message: "Failed to fetch goals" });
    }
  });
  
  // Update a goal
  app.patch("/api/goals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid goal ID" });
      }
      
      const updates = req.body;
      const goal = await storage.updateGoal(id, updates);
      
      if (!goal) {
        return res.status(404).json({ message: "Goal not found" });
      }
      
      res.json(goal);
    } catch (error) {
      console.error("Error updating goal:", error);
      res.status(500).json({ message: "Failed to update goal" });
    }
  });
  
  // Delete a goal
  app.delete("/api/goals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid goal ID" });
      }
      
      const deleted = await storage.deleteGoal(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Goal not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting goal:", error);
      res.status(500).json({ message: "Failed to delete goal" });
    }
  });

  // Subscription endpoints
  
  // Get subscription plans
  app.get("/api/subscription/plans", (req, res) => {
    const plans = getSubscriptionPlans();
    res.json(plans);
  });

  // Create checkout session
  app.post("/api/checkout", isAuthenticated, async (req, res) => {
    try {
      const { planId } = req.body;
      
      if (!planId || !['basic', 'premium', 'pro'].includes(planId)) {
        return res.status(400).json({ message: "Invalid plan ID" });
      }
      
      const session = await createCheckoutSession(
        req.user! as Express.User,
        planId as 'basic' | 'premium' | 'pro'
      );
      
      res.json({ url: session.url });
    } catch (error: any) {
      console.error("Error creating checkout session:", error);
      res.status(500).json({ message: error.message || "Failed to create checkout session" });
    }
  });

  // Cancel subscription
  app.post("/api/cancel-subscription", isAuthenticated, async (req, res) => {
    try {
      const result = await cancelSubscription(req.user!.id);
      res.json(result);
    } catch (error: any) {
      console.error("Error cancelling subscription:", error);
      res.status(500).json({ message: error.message || "Failed to cancel subscription" });
    }
  });

  // Handle Stripe webhooks
  app.post("/api/webhooks/stripe", express.raw({ type: 'application/json' }), handleStripeWebhook);

  // Profile update endpoint
  app.patch("/api/user/profile", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const { firstName, lastName, email } = req.body;
      
      // Basic validation for email
      if (email && !email.includes('@')) {
        return res.status(400).json({ message: "Invalid email format" });
      }
      
      // Check if email already exists (except for the current user)
      if (email) {
        const existingUser = await storage.getUserByEmail(email);
        if (existingUser && existingUser.id !== req.user.id) {
          return res.status(400).json({ message: "Email is already in use" });
        }
      }
      
      // Update user
      const updatedUser = await storage.updateUser(req.user.id, {
        firstName,
        lastName,
        email
      });
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return updated user (without password)
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // Social features endpoints (requires subscription)
  
  // --- Friendship endpoints ---
  
  // Send friend request
  app.post("/api/friends/request", isAuthenticated, hasSubscription('basic'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const { friendId } = req.body;
      if (!friendId) {
        return res.status(400).json({ message: "Friend ID is required" });
      }
      
      // Validate friendId
      const friendIdNum = parseInt(friendId, 10);
      if (isNaN(friendIdNum)) {
        return res.status(400).json({ message: "Invalid friend ID" });
      }
      
      // Check if friend exists
      const friend = await storage.getUser(friendIdNum);
      if (!friend) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if trying to add self
      if (friendIdNum === req.user.id) {
        return res.status(400).json({ message: "Cannot add yourself as a friend" });
      }
      
      // Check if friendship already exists
      const existingFriendship = await storage.getFriendship(req.user.id, friendIdNum);
      if (existingFriendship) {
        return res.status(400).json({ 
          message: `Friendship already ${existingFriendship.status}`,
          status: existingFriendship.status
        });
      }
      
      // Create friendship request
      const friendshipData = {
        userId: req.user.id,
        friendId: friendIdNum,
        status: "pending" as "pending" | "accepted" | "rejected"
      };
      
      const friendship = await storage.createFriendship(friendshipData);
      res.status(201).json(friendship);
    } catch (error: any) {
      console.error("Error creating friend request:", error);
      res.status(500).json({ message: "Failed to create friend request" });
    }
  });
  
  // Get friends list
  app.get("/api/friends", isAuthenticated, hasSubscription('basic'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const friends = await storage.getFriendsByUserId(req.user.id);
      res.json(friends);
    } catch (error) {
      console.error("Error fetching friends:", error);
      res.status(500).json({ message: "Failed to fetch friends" });
    }
  });
  
  // Get pending friend requests
  app.get("/api/friends/requests", isAuthenticated, hasSubscription('basic'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const pendingRequests = await storage.getPendingFriendRequests(req.user.id);
      
      // Get user details for each request
      const requestsWithUsers = await Promise.all(pendingRequests.map(async (request) => {
        const user = await storage.getUser(request.userId);
        return {
          ...request,
          sender: user
        };
      }));
      
      res.json(requestsWithUsers);
    } catch (error) {
      console.error("Error fetching friend requests:", error);
      res.status(500).json({ message: "Failed to fetch friend requests" });
    }
  });
  
  // Respond to friend request
  app.post("/api/friends/respond/:id", isAuthenticated, hasSubscription('basic'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid friendship ID" });
      }
      
      const { action } = req.body;
      if (!action || !["accept", "reject"].includes(action)) {
        return res.status(400).json({ message: "Action must be 'accept' or 'reject'" });
      }
      
      const status = action === "accept" ? "accepted" : "rejected";
      const friendship = await storage.updateFriendshipStatus(id, status);
      
      if (!friendship) {
        return res.status(404).json({ message: "Friendship request not found" });
      }
      
      res.json(friendship);
    } catch (error) {
      console.error("Error responding to friend request:", error);
      res.status(500).json({ message: "Failed to respond to friend request" });
    }
  });
  
  // Remove friend
  app.delete("/api/friends/:friendId", isAuthenticated, hasSubscription('basic'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const friendId = parseInt(req.params.friendId, 10);
      if (isNaN(friendId)) {
        return res.status(400).json({ message: "Invalid friend ID" });
      }
      
      const deleted = await storage.deleteFriendship(req.user.id, friendId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Friendship not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error removing friend:", error);
      res.status(500).json({ message: "Failed to remove friend" });
    }
  });
  
  // --- Challenge endpoints ---
  
  // Create a new challenge
  app.post("/api/challenges", isAuthenticated, hasSubscription('premium'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const challengeData = insertChallengeSchema.parse({
        ...req.body,
        creatorId: req.user.id
      });
      
      // Convert date strings to Date objects if needed
      if (typeof challengeData.startDate === 'string') {
        challengeData.startDate = new Date(challengeData.startDate);
      }
      if (typeof challengeData.endDate === 'string') {
        challengeData.endDate = new Date(challengeData.endDate);
      }
      
      const challenge = await storage.createChallenge(challengeData);
      
      // Creator automatically joins their own challenge
      await storage.joinChallenge({
        challengeId: challenge.id,
        userId: req.user.id
      });
      
      res.status(201).json(challenge);
    } catch (error: any) {
      if (error.name === "ZodError") {
        console.error("Zod validation error:", JSON.stringify(error.format(), null, 2));
        return res.status(400).json({ 
          message: "Invalid challenge data", 
          errors: fromZodError(error as ZodError).toString(),
          details: error.format()
        });
      }
      console.error("Error creating challenge:", error);
      res.status(500).json({ message: "Failed to create challenge" });
    }
  });
  
  // Get user's challenges (created + participating)
  app.get("/api/challenges/user", isAuthenticated, hasSubscription('premium'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const challenges = await storage.getUserChallenges(req.user.id);
      res.json(challenges);
    } catch (error) {
      console.error("Error fetching user challenges:", error);
      res.status(500).json({ message: "Failed to fetch challenges" });
    }
  });
  
  // Get public challenges
  app.get("/api/challenges/public", isAuthenticated, hasSubscription('basic'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : undefined;
      const challenges = await storage.getPublicChallenges(limit);
      res.json(challenges);
    } catch (error) {
      console.error("Error fetching public challenges:", error);
      res.status(500).json({ message: "Failed to fetch public challenges" });
    }
  });
  
  // Get specific challenge
  app.get("/api/challenges/:id", isAuthenticated, hasSubscription('basic'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid challenge ID" });
      }
      
      const challenge = await storage.getChallengeById(id);
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found" });
      }
      
      res.json(challenge);
    } catch (error) {
      console.error("Error fetching challenge:", error);
      res.status(500).json({ message: "Failed to fetch challenge" });
    }
  });
  
  // Join a challenge
  app.post("/api/challenges/:id/join", isAuthenticated, hasSubscription('basic'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const challengeId = parseInt(req.params.id, 10);
      if (isNaN(challengeId)) {
        return res.status(400).json({ message: "Invalid challenge ID" });
      }
      
      // Check if challenge exists
      const challenge = await storage.getChallengeById(challengeId);
      if (!challenge) {
        return res.status(404).json({ message: "Challenge not found" });
      }
      
      // Get participants to check if user already joined
      const participants = await storage.getChallengeParticipants(challengeId);
      const alreadyJoined = participants.some(p => p.userId === req.user!.id);
      
      if (alreadyJoined) {
        return res.status(400).json({ message: "Already joined this challenge" });
      }
      
      const participant = await storage.joinChallenge({
        challengeId,
        userId: req.user.id
      });
      
      res.status(201).json(participant);
    } catch (error) {
      console.error("Error joining challenge:", error);
      res.status(500).json({ message: "Failed to join challenge" });
    }
  });
  
  // Update challenge progress
  app.post("/api/challenges/:id/progress", isAuthenticated, hasSubscription('basic'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const challengeId = parseInt(req.params.id, 10);
      if (isNaN(challengeId)) {
        return res.status(400).json({ message: "Invalid challenge ID" });
      }
      
      const { progress } = req.body;
      if (progress === undefined || isNaN(progress)) {
        return res.status(400).json({ message: "Valid progress value is required" });
      }
      
      const participant = await storage.updateChallengeProgress(
        req.user.id,
        challengeId,
        progress
      );
      
      if (!participant) {
        return res.status(404).json({ message: "Not participating in this challenge" });
      }
      
      res.json(participant);
    } catch (error) {
      console.error("Error updating challenge progress:", error);
      res.status(500).json({ message: "Failed to update challenge progress" });
    }
  });
  
  // Get challenge leaderboard
  app.get("/api/challenges/:id/leaderboard", isAuthenticated, hasSubscription('basic'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const challengeId = parseInt(req.params.id, 10);
      if (isNaN(challengeId)) {
        return res.status(400).json({ message: "Invalid challenge ID" });
      }
      
      const leaderboard = await storage.getLeaderboard(challengeId);
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  // Export workouts (premium feature)
  app.get("/api/workouts/export", isAuthenticated, hasSubscription('premium'), async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const userId = req.query.userId ? parseInt(req.query.userId as string, 10) : req.user.id;
      
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid workout ID" });
      }
      
      const workouts = await storage.getWorkoutsByUserId(userId);
      
      // Format data for export
      const formattedWorkouts = workouts.map(workout => ({
        id: workout.id,
        date: workout.date,
        exercise_type: workout.exerciseType,
        duration_minutes: workout.duration,
        intensity: workout.intensity,
        calories_burned: workout.calories,
        notes: workout.notes
      }));
      
      // Return as JSON with useful filename in header
      res.setHeader('Content-Disposition', 'attachment; filename="workouts_export.json"');
      res.setHeader('Content-Type', 'application/json');
      res.json(formattedWorkouts);
    } catch (error) {
      console.error("Error exporting workouts:", error);
      res.status(500).json({ message: "Failed to export workouts" });
    }
  });
  
  // Body Measurement endpoints
  
  // Create a new body measurement entry
  app.post("/api/measurements", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const measurementData = insertBodyMeasurementSchema.parse(req.body);
      
      // Ensure the user can only create measurements for themselves
      if (measurementData.userId !== req.user.id) {
        return res.status(403).json({ message: "You can only add measurements for yourself" });
      }
      
      const measurement = await storage.createBodyMeasurement(measurementData);
      res.status(201).json(measurement);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          message: "Invalid measurement data", 
          errors: fromZodError(error as ZodError).toString() 
        });
      }
      console.error("Error creating body measurement:", error);
      res.status(500).json({ message: "Failed to create body measurement" });
    }
  });
  
  // Get all body measurements for a user
  app.get("/api/measurements/user/:userId", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Ensure the user can only see their own measurements
      if (req.user && userId !== req.user.id) {
        return res.status(403).json({ message: "You can only view your own measurements" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : undefined;
      const measurements = await storage.getBodyMeasurementsByUserId(userId, limit);
      res.json(measurements);
    } catch (error) {
      console.error("Error fetching body measurements:", error);
      res.status(500).json({ message: "Failed to fetch body measurements" });
    }
  });
  
  // Get measurements by date range
  app.get("/api/measurements/range/:userId", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Ensure the user can only see their own measurements
      if (req.user && userId !== req.user.id) {
        return res.status(403).json({ message: "You can only view your own measurements" });
      }
      
      const { start, end } = req.query;
      if (!start || !end) {
        return res.status(400).json({ message: "Start and end dates are required" });
      }
      
      const startDate = new Date(start as string);
      const endDate = new Date(end as string);
      
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }
      
      const measurements = await storage.getBodyMeasurementsByDateRange(userId, startDate, endDate);
      res.json(measurements);
    } catch (error) {
      console.error("Error fetching body measurements by date range:", error);
      res.status(500).json({ message: "Failed to fetch body measurements" });
    }
  });
  
  // Get the latest body measurement for a user
  app.get("/api/measurements/latest/:userId", isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Ensure the user can only see their own measurements
      if (req.user && userId !== req.user.id) {
        return res.status(403).json({ message: "You can only view your own measurements" });
      }
      
      const measurement = await storage.getLatestBodyMeasurement(userId);
      if (!measurement) {
        return res.status(404).json({ message: "No measurements found" });
      }
      
      res.json(measurement);
    } catch (error) {
      console.error("Error fetching latest body measurement:", error);
      res.status(500).json({ message: "Failed to fetch latest body measurement" });
    }
  });
  
  // User Device endpoints
  
  // Register a new device
  app.post("/api/devices", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const deviceData = insertUserDeviceSchema.parse(req.body);
      
      // Ensure the user can only register devices for themselves
      if (deviceData.userId !== req.user.id) {
        return res.status(403).json({ message: "You can only register devices for yourself" });
      }
      
      const device = await storage.createUserDevice(deviceData);
      res.status(201).json(device);
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          message: "Invalid device data", 
          errors: fromZodError(error as ZodError).toString() 
        });
      }
      console.error("Error registering device:", error);
      res.status(500).json({ message: "Failed to register device" });
    }
  });
  
  // Get all devices for a user
  app.get("/api/devices", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const devices = await storage.getUserDevices(req.user.id);
      res.json(devices);
    } catch (error) {
      console.error("Error fetching devices:", error);
      res.status(500).json({ message: "Failed to fetch devices" });
    }
  });
  
  // Update device
  app.patch("/api/devices/:id", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid device ID" });
      }
      
      const updates = req.body;
      const device = await storage.updateUserDevice(id, updates);
      
      if (!device) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      // Ensure the user can only update their own devices
      if (device.userId !== req.user.id) {
        return res.status(403).json({ message: "You can only update your own devices" });
      }
      
      res.json(device);
    } catch (error) {
      console.error("Error updating device:", error);
      res.status(500).json({ message: "Failed to update device" });
    }
  });
  
  // Delete device
  app.delete("/api/devices/:id", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid device ID" });
      }
      
      // Get device to check ownership
      const device = await storage.getUserDevices(req.user.id)
        .then(devices => devices.find(d => d.id === id));
      
      if (!device) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      // Ensure the user can only delete their own devices
      if (device.userId !== req.user.id) {
        return res.status(403).json({ message: "You can only delete your own devices" });
      }
      
      const deleted = await storage.deleteUserDevice(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Device not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting device:", error);
      res.status(500).json({ message: "Failed to delete device" });
    }
  });
  
  // User Settings endpoints
  
  // Get user settings
  app.get("/api/settings", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const settings = await storage.getUserSettings(req.user.id);
      
      if (!settings) {
        // If no settings exist yet, create default settings
        const defaultSettings = {
          userId: req.user.id,
          weightUnit: "kg",
          reminderEnabled: false,
          healthKitEnabled: false,
          fitbitEnabled: false,
          language: "en"
        };
        
        const newSettings = await storage.createUserSettings(defaultSettings);
        return res.json(newSettings);
      }
      
      res.json(settings);
    } catch (error) {
      console.error("Error fetching user settings:", error);
      res.status(500).json({ message: "Failed to fetch user settings" });
    }
  });
  
  // Update user settings
  app.patch("/api/settings", isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const updates = req.body;
      
      // Get current settings
      let settings = await storage.getUserSettings(req.user.id);
      
      if (!settings) {
        // If no settings exist yet, create with provided updates
        const defaultSettings = {
          userId: req.user.id,
          weightUnit: updates.weightUnit || "kg",
          reminderEnabled: updates.reminderEnabled ?? false,
          healthKitEnabled: updates.healthKitEnabled ?? false,
          fitbitEnabled: updates.fitbitEnabled ?? false,
          language: updates.language || "en",
          ...updates
        };
        
        settings = await storage.createUserSettings(defaultSettings);
      } else {
        // Update existing settings
        settings = await storage.updateUserSettings(req.user.id, updates);
      }
      
      if (!settings) {
        return res.status(500).json({ message: "Failed to update settings" });
      }
      
      res.json(settings);
    } catch (error) {
      console.error("Error updating user settings:", error);
      res.status(500).json({ message: "Failed to update user settings" });
    }
  });
  
  // Admin API Endpoints
  
  // Middleware to check if user is admin
  const isAdmin = (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    if (req.user?.username !== "admin") {
      return res.status(403).json({ message: "Admin access required" });
    }
    
    next();
  };
  
  // Get admin statistics
  app.get("/api/admin/stats", isAuthenticated, isAdmin, async (req, res) => {
    try {
      // Calculate general statistics
      const userCount = (await storage.getAllUsers()).length;
      
      const allUsers = await storage.getAllUsers();
      const subscribedUsers = allUsers.filter(user => user.isSubscribed).length;
      
      const allWorkouts = await Promise.all(
        allUsers.map(user => storage.getWorkoutsByUserId(user.id))
      );
      const totalWorkouts = allWorkouts.reduce((sum, workouts) => sum + workouts.length, 0);
      
      // Get active users in the last 7 days
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      
      const activeUsers = (await Promise.all(
        allUsers.map(async user => {
          const recentWorkouts = await storage.getWorkoutsByUserId(user.id);
          return recentWorkouts.some(workout => 
            new Date(workout.createdAt) > sevenDaysAgo
          );
        })
      )).filter(Boolean).length;
      
      // Get new users today
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const newUsersToday = allUsers.filter(user => 
        new Date(user.createdAt) >= today
      ).length;
      
      // Get goals and challenges counts
      const allGoals = await Promise.all(
        allUsers.map(user => storage.getGoalsByUserId(user.id))
      );
      const totalGoals = allGoals.reduce((sum, goals) => sum + goals.length, 0);
      
      const allChallenges = await storage.getPublicChallenges();
      const totalChallenges = allChallenges.length;
      
      // Dummy revenue stat - in a real app, this would come from the payment system
      const revenue = subscribedUsers * 10; // Just a placeholder calculation
      
      res.json({
        userCount,
        subscribedUsers,
        totalWorkouts,
        activeUsers,
        newUsersToday,
        totalGoals,
        totalChallenges,
        revenue
      });
      
    } catch (error) {
      console.error("Error getting admin stats:", error);
      res.status(500).json({ message: "Failed to get admin statistics" });
    }
  });
  
  // Get all users
  app.get("/api/admin/users", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Remove password field from response
      const sanitizedUsers = users.map(user => {
        const { password, ...userWithoutPassword } = user as any;
        return userWithoutPassword;
      });
      
      res.json(sanitizedUsers);
    } catch (error) {
      console.error("Error getting all users:", error);
      res.status(500).json({ message: "Failed to get users" });
    }
  });
  
  // Update user
  app.patch("/api/admin/users/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const updates = req.body;
      const updatedUser = await storage.updateUser(userId, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password field from response
      const { password, ...userWithoutPassword } = updatedUser as any;
      
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });
  
  // Delete user
  app.delete("/api/admin/users/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id, 10);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Prevent deleting the admin account
      const userToDelete = await storage.getUser(userId);
      if (!userToDelete) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (userToDelete.username === "admin") {
        return res.status(403).json({ message: "Cannot delete admin account" });
      }
      
      // In a real application, you would delete all related data (workouts, goals, etc.)
      // Here we'll just implement a simple user deletion
      const deleted = await storage.deleteUser(userId);
      
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });
  
  // Add a new user (Admin only)
  app.post("/api/admin/users", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { username, password, email, firstName, lastName, isSubscribed, subscriptionTier } = req.body;
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Hash the password
      const hashedPassword = await hashPassword(password);
      
      // Create user with admin-specified data
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        email,
        firstName: firstName || null,
        lastName: lastName || null,
        isSubscribed: isSubscribed || false,
        subscriptionTier: subscriptionTier || null,
        createdAt: new Date(),
        subscriptionStartDate: isSubscribed ? new Date() : null,
        subscriptionEndDate: null,
        stripeCustomerId: null,
        stripeSubscriptionId: null
      });
      
      // Remove password from response
      const { password: _, ...userWithoutPassword } = user as any;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
