import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from '@shared/schema';

// Create the connection
const connectionString = process.env.DATABASE_URL || '';
const client = postgres(connectionString);
export const db = drizzle(client, { schema });

// Run migrations programmatically
export async function migrate() {
  console.log('Migrating database...');
  
  try {
    // Create tables if they don't exist
    await client`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
      )
    `;
    
    await client`
      CREATE TABLE IF NOT EXISTS workouts (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        exercise_type TEXT NOT NULL,
        duration INTEGER NOT NULL,
        intensity TEXT NOT NULL,
        notes TEXT,
        calories INTEGER,
        date TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `;
    
    await client`
      CREATE TABLE IF NOT EXISTS goals (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        target_value INTEGER NOT NULL,
        current_value INTEGER NOT NULL DEFAULT 0,
        type TEXT NOT NULL,
        periodicity TEXT NOT NULL,
        is_completed BOOLEAN NOT NULL DEFAULT FALSE,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `;
    
    // Add tables for social features
    await client`
      CREATE TABLE IF NOT EXISTS friendships (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL,
        friend_id INTEGER NOT NULL,
        status TEXT NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `;
    
    await client`
      CREATE TABLE IF NOT EXISTS challenges (
        id SERIAL PRIMARY KEY,
        creator_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        exercise_type TEXT,
        target_metric TEXT NOT NULL,
        target_value INTEGER NOT NULL,
        start_date TIMESTAMP NOT NULL,
        end_date TIMESTAMP NOT NULL,
        is_public BOOLEAN NOT NULL DEFAULT TRUE,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `;
    
    await client`
      CREATE TABLE IF NOT EXISTS challenge_participants (
        id SERIAL PRIMARY KEY,
        challenge_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        joined_at TIMESTAMP NOT NULL DEFAULT NOW(),
        current_progress INTEGER NOT NULL DEFAULT 0,
        completed BOOLEAN NOT NULL DEFAULT FALSE,
        completed_at TIMESTAMP
      )
    `;
    
    console.log('Migration completed successfully');
    
    // Seed the database with a test user if none exists
    const userCount = await client`SELECT COUNT(*) FROM users`;
    if (userCount[0].count === '0') {
      // Insert a test user
      await client`
        INSERT INTO users (username, password)
        VALUES ('testuser', 'testpassword')
      `;
      
      console.log('Created test user with ID 1');
      
      // We no longer add sample data automatically
      // Users will now add their own workouts and goals through the app
    }
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  }
}