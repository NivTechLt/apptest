import passport from 'passport';
import { Strategy as LocalStrategy } from 'passport-local';
import bcrypt from 'bcrypt';
import { storage } from './storage';
import { User, insertUserSchema } from '@shared/schema';
import session from 'express-session';
import pgSession from 'connect-pg-simple';
import { Express, Request, Response, NextFunction } from 'express';
import { db } from './db';
import { createId } from '@paralleldrive/cuid2';
import MemoryStore from 'memorystore';
import crypto from 'crypto';
import { sendEmail, getVerificationEmailTemplate, getPasswordResetEmailTemplate, initializeEmailService } from './services/email';

// Create session stores
const PgSessionStore = pgSession(session);
const MemStore = MemoryStore(session);

// Add Express.User type for type safety
declare global {
  namespace Express {
    // Add user properties without circular reference
    interface User {
      id: number;
      username: string;
      email: string;
      firstName?: string | null;
      lastName?: string | null;
      createdAt: Date;
      isSubscribed: boolean;
      subscriptionTier: string | null;
      subscriptionStartDate: Date | null;
      subscriptionEndDate: Date | null;
      stripeCustomerId: string | null;
      stripeSubscriptionId: string | null;
    }
  }
}

// Configure passport with local strategy
passport.use(
  new LocalStrategy(async (username, password, done) => {
    try {
      console.log('\n[AUTH] Login attempt for username:', username);
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        console.log('[AUTH] User not found');
        return done(null, false, { message: 'Incorrect username.' });
      }
      
      const isValidPassword = await bcrypt.compare(password, user.password);
      console.log('[AUTH] Password validation:', isValidPassword ? 'success' : 'failed');
      
      if (!isValidPassword) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      
      console.log('[AUTH] Login successful for user:', user.id);
      return done(null, user);
    } catch (error) {
      console.error('[AUTH] Error during authentication:', error);
      return done(error);
    }
  })
);

// Serialize user to store in session
passport.serializeUser((user, done) => {
  done(null, user.id);
});

// Deserialize user from session
passport.deserializeUser(async (id: number, done) => {
  try {
    const user = await storage.getUser(id);
    if (!user) {
      return done(null, false);
    }
    done(null, user);
  } catch (error) {
    done(error);
  }
});

// Setup authentication and session
export function setupAuth(app: Express) {
  // Create session storage - either PostgreSQL or memory store
  const sessionStore = process.env.NODE_ENV === 'production' 
    ? new PgSessionStore({
        conObject: {
          connectionString: process.env.DATABASE_URL,
        },
        tableName: 'sessions',
        createTableIfMissing: true,
      }) 
    : new MemStore({
        checkPeriod: 86400000 // prune expired entries every 24h
      });
  
  // Configure session
  app.use(
    session({
      store: sessionStore,
      secret: process.env.SESSION_SECRET || `fitness-tracker-${createId()}`,
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
        secure: process.env.NODE_ENV === 'production',
      },
    })
  );

  // Initialize passport
  app.use(passport.initialize());
  app.use(passport.session());
  
  // Helper functions for verification
  function generateVerificationToken(): string {
    return crypto.randomBytes(32).toString('hex');
  }
  
  function getTokenExpiryDate(): Date {
    // Token expires in 24 hours
    const expiryDate = new Date();
    expiryDate.setHours(expiryDate.getHours() + 24);
    return expiryDate;
  }
  
  async function sendVerificationEmail(email: string, token: string): Promise<void> {
    try {
      // Get email template
      const template = getVerificationEmailTemplate(token);
      
      // Send email using our email service
      await sendEmail({
        to: email,
        subject: template.subject,
        html: template.html,
        text: template.text
      });
      
      console.log(`[EMAIL] Verification email sent to ${email}`);
    } catch (error) {
      console.error('Error sending verification email:', error);
      throw error;
    }
  }
  
  async function sendPasswordResetEmail(email: string, token: string): Promise<void> {
    try {
      // Get email template
      const template = getPasswordResetEmailTemplate(token);
      
      // Send email using our email service
      await sendEmail({
        to: email,
        subject: template.subject,
        html: template.html,
        text: template.text
      });
      
      console.log(`[EMAIL] Password reset email sent to ${email}`);
    } catch (error) {
      console.error('Error sending password reset email:', error);
      throw error;
    }
  }

  // Add authentication routes
  app.post('/api/register', async (req, res) => {
    try {
      console.log('Registration request received:', JSON.stringify(req.body, null, 2));
      
      // Remove confirmPassword from validation - we'll validate it separately
      const { confirmPassword, ...userDataWithoutConfirm } = req.body;
      
      // Make sure passwords match
      if (req.body.password !== confirmPassword) {
        return res.status(400).json({ message: 'Passwords do not match' });
      }
      
      // Validate input
      try {
        insertUserSchema.parse(req.body);
      } catch (validationError) {
        console.error('Validation error:', validationError);
        // Format Zod errors in a more user-friendly way
        const zodError = validationError as any;
        const formattedErrors = zodError.errors?.map((err: any) => ({
          field: err.path.join('.'),
          message: err.message
        })) || [];
        
        return res.status(400).json({ 
          message: 'Invalid user data', 
          errors: formattedErrors 
        });
      }
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: 'Username already exists' });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(req.body.email);
      if (existingEmail) {
        return res.status(400).json({ message: 'Email already registered' });
      }
      
      // Hash password
      const hashedPassword = await hashPassword(req.body.password);
      
      // Generate verification token
      const verificationToken = generateVerificationToken();
      const verificationTokenExpiry = getTokenExpiryDate();
      
      // Create user (without the confirmPassword field)
      // Only pass the fields that are in the insertUserSchema
      const user = await storage.createUser({
        username: userDataWithoutConfirm.username,
        email: userDataWithoutConfirm.email,
        password: hashedPassword,
        firstName: userDataWithoutConfirm.firstName,
        lastName: userDataWithoutConfirm.lastName
      });
      
      // Then update the user with verification details
      await storage.updateUser(user.id, {
        isEmailVerified: false,
        verificationToken,
        verificationTokenExpiry
      });
      
      console.log('User created successfully:', user.id);
      
      // Send verification email
      try {
        await sendVerificationEmail(user.email, verificationToken);
      } catch (emailError) {
        console.error('Error sending verification email:', emailError);
        // We'll still continue even if the email fails, just log it
      }
      
      // Log the user in
      req.login(user, (err) => {
        if (err) {
          console.error('Login after registration error:', err);
          return res.status(500).json({ message: 'Error during login after registration' });
        }
        
        // Return user data without sensitive fields
        const { password, verificationToken, ...userData } = user;
        console.log('User logged in, returning data');
        return res.status(201).json({
          ...userData,
          message: 'Account created successfully. Please check your email for verification instructions.'
        });
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ message: 'Error during registration' });
    }
  });
  
  app.post('/api/login', (req, res, next) => {
    passport.authenticate('local', (err: any, user: any, info: any) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        return res.status(401).json({ message: info?.message || 'Authentication failed' });
      }
      
      req.login(user, (err) => {
        if (err) {
          return next(err);
        }
        
        // Return user data without sensitive fields
        const { password, ...userData } = user;
        return res.json(userData);
      });
    })(req, res, next);
  });
  
  app.post('/api/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: 'Error during logout' });
      }
      res.status(200).json({ message: 'Logged out successfully' });
    });
  });
  
  app.get('/api/user', (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    // Return user data without sensitive fields
    const { password, verificationToken, ...userData } = req.user as User;
    res.json(userData);
  });
  
  // Email verification endpoint
  app.get('/api/verify-email', async (req, res) => {
    const { token } = req.query;
    
    if (!token || typeof token !== 'string') {
      return res.status(400).json({ message: 'Invalid verification token' });
    }
    
    try {
      // Find user with this verification token
      const user = await db.query.users.findFirst({
        where: (users, { eq }) => eq(users.verificationToken, token)
      });
      
      if (!user) {
        return res.status(400).json({ message: 'Invalid verification token' });
      }
      
      // Check if token is expired
      if (user.verificationTokenExpiry && new Date() > new Date(user.verificationTokenExpiry)) {
        return res.status(400).json({ message: 'Verification token has expired' });
      }
      
      // Update user as verified
      await storage.updateUser(user.id, {
        isEmailVerified: true,
        verificationToken: null,
        verificationTokenExpiry: null
      });
      
      // If we're using SSR or a full-stack app, we could redirect here
      // res.redirect('/email-verified');
      
      // For now, just return a success message
      return res.json({ message: 'Email verified successfully. You can now log in.' });
    } catch (error) {
      console.error('Email verification error:', error);
      return res.status(500).json({ message: 'Error verifying email' });
    }
  });
  
  // Request password reset
  app.post('/api/forgot-password', async (req, res) => {
    const { email } = req.body;
    
    if (!email || typeof email !== 'string') {
      return res.status(400).json({ message: 'Email is required' });
    }
    
    try {
      // Find user by email
      const user = await storage.getUserByEmail(email);
      
      // For security reasons, don't reveal if the email exists or not
      if (!user) {
        // Still return a success message to prevent email enumeration
        return res.json({ message: 'If an account with that email exists, a password reset link has been sent.' });
      }
      
      // Generate reset token
      const resetToken = generateVerificationToken();
      const resetTokenExpiry = getTokenExpiryDate();
      
      // Update user with reset token
      await storage.updateUser(user.id, {
        verificationToken: resetToken,
        verificationTokenExpiry: resetTokenExpiry
      });
      
      // Send reset email
      await sendPasswordResetEmail(user.email, resetToken);
      
      return res.json({ message: 'If an account with that email exists, a password reset link has been sent.' });
    } catch (error) {
      console.error('Password reset request error:', error);
      return res.status(500).json({ message: 'Error requesting password reset' });
    }
  });
  
  // Reset password with token
  app.post('/api/reset-password', async (req, res) => {
    const { token, newPassword } = req.body;
    
    if (!token || typeof token !== 'string') {
      return res.status(400).json({ message: 'Invalid reset token' });
    }
    
    if (!newPassword || typeof newPassword !== 'string' || newPassword.length < 8) {
      return res.status(400).json({ message: 'Password must be at least 8 characters long' });
    }
    
    try {
      // Find user with this reset token
      const user = await db.query.users.findFirst({
        where: (users, { eq }) => eq(users.verificationToken, token)
      });
      
      if (!user) {
        return res.status(400).json({ message: 'Invalid reset token' });
      }
      
      // Check if token is expired
      if (user.verificationTokenExpiry && new Date() > new Date(user.verificationTokenExpiry)) {
        return res.status(400).json({ message: 'Reset token has expired' });
      }
      
      // Hash new password
      const hashedPassword = await hashPassword(newPassword);
      
      // Update user with new password and clear token
      await storage.updateUser(user.id, {
        password: hashedPassword,
        verificationToken: null,
        verificationTokenExpiry: null
      });
      
      return res.json({ message: 'Password reset successful. You can now log in with your new password.' });
    } catch (error) {
      console.error('Password reset error:', error);
      return res.status(500).json({ message: 'Error resetting password' });
    }
  });
  
  // Social authentication routes would typically be implemented here
  // For example, Google OAuth requires configuring passport with GoogleStrategy
  app.get('/api/auth/google', (req, res) => {
    // This would be an actual OAuth implementation
    res.status(501).json({ message: 'Google authentication not implemented yet' });
    
    // Example implementation with passport-google-oauth20:
    /*
    app.get('/api/auth/google',
      passport.authenticate('google', { scope: ['profile', 'email'] })
    );
    
    app.get('/api/auth/google/callback', 
      passport.authenticate('google', { 
        failureRedirect: '/login',
        successRedirect: '/'
      })
    );
    */
  });
  
  app.get('/api/auth/apple', (req, res) => {
    // This would be an actual OAuth implementation
    res.status(501).json({ message: 'Apple authentication not implemented yet' });
    
    // Example implementation with passport-apple:
    /*
    app.get('/api/auth/apple',
      passport.authenticate('apple')
    );
    
    app.get('/api/auth/apple/callback', 
      passport.authenticate('apple', { 
        failureRedirect: '/login',
        successRedirect: '/'
      })
    );
    */
  });
}

// Middleware to ensure authentication
export function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  
  res.status(401).json({ message: 'Unauthorized - Please log in' });
}

// Middleware to ensure admin or premium subscription
export function hasSubscription(type: 'basic' | 'premium' | 'pro') {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = req.user as User;
    
    if (!user) {
      return res.status(401).json({ message: 'Unauthorized - Please log in' });
    }
    
    // Allow access if user has requested subscription tier or higher
    const tierLevels = {
      'free': 0,
      'basic': 1,
      'premium': 2,
      'pro': 3
    };
    
    const userTierLevel = tierLevels[user.subscriptionTier as keyof typeof tierLevels] || 0;
    const requiredTierLevel = tierLevels[type];
    
    if (user.isSubscribed && userTierLevel >= requiredTierLevel) {
      return next();
    }
    
    res.status(403).json({ 
      message: 'Subscription required',
      requiredTier: type,
      currentTier: user.subscriptionTier
    });
  };
}

// Helper function to hash passwords
export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 10;
  return bcrypt.hash(password, saltRounds);
}

export { passport };