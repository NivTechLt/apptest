import { 
  users, type User, type InsertUser, type UpdateSubscription,
  workouts, type Workout, type InsertWorkout,
  goals, type Goal, type InsertGoal,
  friendships, type Friendship, type InsertFriendship,
  challenges, type Challenge, type InsertChallenge,
  challengeParticipants, type ChallengeParticipant, type InsertChallengeParticipant,
  bodyMeasurements, type BodyMeasurement, type InsertBodyMeasurement,
  userDevices, type UserDevice, type InsertUserDevice,
  userSettings, type UserSettings, type InsertUserSettings
} from "@shared/schema";

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByStripeCustomerId(stripeCustomerId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  deleteUser(id: number): Promise<boolean>;
  
  // Subscription operations
  updateUserSubscription(id: number, subscription: UpdateSubscription): Promise<User | undefined>;
  updateUserStripeCustomerId(id: number, stripeCustomerId: string): Promise<User | undefined>;
  
  // Workout operations
  createWorkout(workout: InsertWorkout): Promise<Workout>;
  getWorkoutById(id: number): Promise<Workout | undefined>;
  getWorkoutsByUserId(userId: number): Promise<Workout[]>;
  getRecentWorkoutsByUserId(userId: number, limit: number): Promise<Workout[]>;
  
  // Goal operations
  createGoal(goal: InsertGoal): Promise<Goal>;
  getGoalById(id: number): Promise<Goal | undefined>;
  getGoalsByUserId(userId: number): Promise<Goal[]>;
  updateGoal(id: number, updates: Partial<Goal>): Promise<Goal | undefined>;
  deleteGoal(id: number): Promise<boolean>;
  
  // Statistics
  getWeeklyStats(userId: number): Promise<{ 
    workoutCount: number; 
    totalMinutes: number; 
    totalCalories: number;
    dailyCounts: number[]; 
  }>;
  
  // Utility operations
  calculateCalories(workoutType: string, duration: number, intensity: string): number;
  
  // Friendship operations
  createFriendship(friendship: InsertFriendship): Promise<Friendship>;
  getFriendship(userId: number, friendId: number): Promise<Friendship | undefined>;
  getFriendsByUserId(userId: number): Promise<User[]>;
  getPendingFriendRequests(userId: number): Promise<Friendship[]>;
  updateFriendshipStatus(id: number, status: "accepted" | "rejected"): Promise<Friendship | undefined>;
  deleteFriendship(userId: number, friendId: number): Promise<boolean>;
  
  // Challenge operations
  createChallenge(challenge: InsertChallenge): Promise<Challenge>;
  getChallengeById(id: number): Promise<Challenge | undefined>;
  getUserChallenges(userId: number): Promise<Challenge[]>;
  getPublicChallenges(limit?: number): Promise<Challenge[]>;
  joinChallenge(participant: InsertChallengeParticipant): Promise<ChallengeParticipant>;
  getChallengeParticipants(challengeId: number): Promise<(ChallengeParticipant & { user: User })[]>;
  updateChallengeProgress(userId: number, challengeId: number, progress: number): Promise<ChallengeParticipant | undefined>;
  getLeaderboard(challengeId: number): Promise<(ChallengeParticipant & { user: User })[]>;
  
  // Body Measurement operations
  createBodyMeasurement(measurement: InsertBodyMeasurement): Promise<BodyMeasurement>;
  getBodyMeasurementById(id: number): Promise<BodyMeasurement | undefined>;
  getBodyMeasurementsByUserId(userId: number, limit?: number): Promise<BodyMeasurement[]>;
  getBodyMeasurementsByDateRange(userId: number, startDate: Date, endDate: Date): Promise<BodyMeasurement[]>;
  getLatestBodyMeasurement(userId: number): Promise<BodyMeasurement | undefined>;
  
  // User Device operations
  createUserDevice(device: InsertUserDevice): Promise<UserDevice>;
  getUserDevices(userId: number): Promise<UserDevice[]>;
  updateUserDevice(id: number, updates: Partial<UserDevice>): Promise<UserDevice | undefined>;
  deleteUserDevice(id: number): Promise<boolean>;
  
  // User Settings operations
  getUserSettings(userId: number): Promise<UserSettings | undefined>;
  createUserSettings(settings: InsertUserSettings): Promise<UserSettings>;
  updateUserSettings(userId: number, updates: Partial<UserSettings>): Promise<UserSettings | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private workouts: Map<number, Workout>;
  private goals: Map<number, Goal>;
  private friendships: Map<number, Friendship>;
  private challenges: Map<number, Challenge>;
  private challengeParticipants: Map<number, ChallengeParticipant>;
  private userId: number;
  private workoutId: number;
  private goalId: number;
  private friendshipId: number;
  private challengeId: number;
  private challengeParticipantId: number;

  constructor() {
    this.users = new Map();
    this.workouts = new Map();
    this.goals = new Map();
    this.friendships = new Map();
    this.challenges = new Map();
    this.challengeParticipants = new Map();
    this.userId = 1;
    this.workoutId = 1;
    this.goalId = 1;
    this.friendshipId = 1;
    this.challengeId = 1;
    this.challengeParticipantId = 1;
    
    // Add a default user for testing
    const now = new Date();
    this.users.set(1, {
      id: 1,
      username: "testuser",
      password: "password",
      email: "test@example.com",
      firstName: "Test",
      lastName: "User",
      createdAt: now,
      isSubscribed: false,
      subscriptionTier: null,
      subscriptionStartDate: null,
      subscriptionEndDate: null,
      stripeCustomerId: null,
      stripeSubscriptionId: null
    });
    
    // Add an admin user
    this.users.set(2, {
      id: 2,
      username: "admin",
      password: "admin123",
      email: "admin@example.com",
      firstName: "Admin",
      lastName: "User",
      createdAt: now,
      isSubscribed: true,
      subscriptionTier: "pro",
      subscriptionStartDate: now,
      subscriptionEndDate: new Date(now.getFullYear() + 1, now.getMonth(), now.getDate()),
      stripeCustomerId: null,
      stripeSubscriptionId: null
    });
    
    // Add some sample workouts for the default user
    
    // Running workout (today)
    this.workouts.set(1, {
      id: 1,
      userId: 1,
      exerciseType: "Running",
      duration: 45,
      intensity: "medium",
      calories: 320,
      notes: "",
      date: now
    });
    
    // Weight Training workout (yesterday)
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    this.workouts.set(2, {
      id: 2,
      userId: 1,
      exerciseType: "Weight Training",
      duration: 60,
      intensity: "high",
      calories: 450,
      notes: "",
      date: yesterday
    });
    
    // Cycling workout (2 days ago)
    const twoDaysAgo = new Date(now);
    twoDaysAgo.setDate(twoDaysAgo.getDate() - 2);
    this.workouts.set(3, {
      id: 3,
      userId: 1,
      exerciseType: "Cycling",
      duration: 30,
      intensity: "low",
      calories: 280,
      notes: "",
      date: twoDaysAgo
    });
    
    // Initialize with sample goals
    this.goals.set(1, {
      id: 1,
      userId: 1,
      name: "Workout 4 times per week",
      targetValue: 4,
      currentValue: 5,
      type: "workout_count",
      periodicity: "weekly",
      isCompleted: true,
      createdAt: now
    });
    
    this.goals.set(2, {
      id: 2,
      userId: 1,
      name: "Run 10 miles per week",
      targetValue: 10,
      currentValue: 6.2,
      type: "distance",
      periodicity: "weekly",
      isCompleted: false,
      createdAt: now
    });
    
    this.goals.set(3, {
      id: 3,
      userId: 1,
      name: "Strength training twice weekly",
      targetValue: 2,
      currentValue: 1,
      type: "workout_count",
      periodicity: "weekly",
      isCompleted: false,
      createdAt: now
    });
    
    this.workoutId = 4;
    this.goalId = 4;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }
  
  async getUserByStripeCustomerId(stripeCustomerId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.stripeCustomerId === stripeCustomerId,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    // Remove confirmPassword if present (it's not in the database schema)
    const { confirmPassword, ...userData } = insertUser as any;
    
    // Create user with default values for subscription fields
    const user: User = { 
      ...userData, 
      id,
      createdAt: new Date(),
      isSubscribed: false,
      subscriptionTier: null,
      subscriptionStartDate: null,
      subscriptionEndDate: null,
      stripeCustomerId: null,
      stripeSubscriptionId: null
    };
    
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Subscription operations
  async updateUserSubscription(id: number, subscription: UpdateSubscription): Promise<User | undefined> {
    return this.updateUser(id, subscription);
  }
  
  async updateUserStripeCustomerId(id: number, stripeCustomerId: string): Promise<User | undefined> {
    return this.updateUser(id, { stripeCustomerId });
  }
  
  // Workout operations
  async createWorkout(insertWorkout: InsertWorkout): Promise<Workout> {
    const id = this.workoutId++;
    const calories = this.calculateCalories(
      insertWorkout.exerciseType, 
      insertWorkout.duration, 
      insertWorkout.intensity
    );
    
    const workout: Workout = { 
      ...insertWorkout, 
      id, 
      calories,
      date: new Date(),
      notes: insertWorkout.notes || null // Ensure notes is never undefined
    };
    
    this.workouts.set(id, workout);
    return workout;
  }
  
  async getWorkoutById(id: number): Promise<Workout | undefined> {
    return this.workouts.get(id);
  }
  
  async getWorkoutsByUserId(userId: number): Promise<Workout[]> {
    return Array.from(this.workouts.values())
      .filter(workout => workout.userId === userId)
      .sort((a, b) => (b.date?.getTime() || 0) - (a.date?.getTime() || 0));
  }
  
  async getRecentWorkoutsByUserId(userId: number, limit: number): Promise<Workout[]> {
    return (await this.getWorkoutsByUserId(userId)).slice(0, limit);
  }
  
  // Goal operations
  async createGoal(insertGoal: InsertGoal): Promise<Goal> {
    const id = this.goalId++;
    const goal: Goal = { 
      ...insertGoal, 
      id, 
      currentValue: 0,
      isCompleted: false,
      createdAt: new Date() 
    };
    
    this.goals.set(id, goal);
    return goal;
  }
  
  async getGoalById(id: number): Promise<Goal | undefined> {
    return this.goals.get(id);
  }
  
  async getGoalsByUserId(userId: number): Promise<Goal[]> {
    return Array.from(this.goals.values())
      .filter(goal => goal.userId === userId);
  }
  
  async updateGoal(id: number, updates: Partial<Goal>): Promise<Goal | undefined> {
    const goal = this.goals.get(id);
    if (!goal) return undefined;
    
    const updatedGoal = { ...goal, ...updates };
    this.goals.set(id, updatedGoal);
    return updatedGoal;
  }
  
  async deleteGoal(id: number): Promise<boolean> {
    return this.goals.delete(id);
  }
  
  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async deleteUser(id: number): Promise<boolean> {
    // First, check if the user exists
    if (!this.users.has(id)) {
      return false;
    }
    
    // Delete all associated data
    // Delete workouts
    Array.from(this.workouts.values())
      .filter(workout => workout.userId === id)
      .forEach(workout => this.workouts.delete(workout.id));
    
    // Delete goals
    Array.from(this.goals.values())
      .filter(goal => goal.userId === id)
      .forEach(goal => this.goals.delete(goal.id));
    
    // Delete friendships
    Array.from(this.friendships.values())
      .filter(friendship => friendship.userId === id || friendship.friendId === id)
      .forEach(friendship => this.friendships.delete(friendship.id));
    
    // Delete challenge participations
    Array.from(this.challengeParticipants.values())
      .filter(participant => participant.userId === id)
      .forEach(participant => this.challengeParticipants.delete(participant.id));
    
    // Delete challenges created by the user
    Array.from(this.challenges.values())
      .filter(challenge => challenge.creatorId === id)
      .forEach(challenge => this.challenges.delete(challenge.id));
    
    // Delete body measurements
    Array.from(this.bodyMeasurements.values())
      .filter(measurement => measurement.userId === id)
      .forEach(measurement => this.bodyMeasurements.delete(measurement.id));
    
    // Delete user devices
    Array.from(this.userDevices.values())
      .filter(device => device.userId === id)
      .forEach(device => this.userDevices.delete(device.id));
    
    // Delete user settings
    Array.from(this.userSettings.values())
      .filter(settings => settings.userId === id)
      .forEach(settings => this.userSettings.delete(settings.id));
    
    // Finally, delete the user
    return this.users.delete(id);
  }
  
  // Statistics
  async getWeeklyStats(userId: number): Promise<{ 
    workoutCount: number; 
    totalMinutes: number; 
    totalCalories: number;
    dailyCounts: number[]; 
  }> {
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay()); // Start from Sunday
    startOfWeek.setHours(0, 0, 0, 0);
    
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 7);
    
    const weeklyWorkouts = Array.from(this.workouts.values()).filter(workout => {
      return workout.userId === userId && 
             workout.date >= startOfWeek && 
             workout.date < endOfWeek;
    });
    
    // Daily counts initialization (Sun, Mon, Tue, Wed, Thu, Fri, Sat)
    const dailyCounts = [0, 0, 0, 0, 0, 0, 0];
    
    let totalMinutes = 0;
    let totalCalories = 0;
    
    weeklyWorkouts.forEach(workout => {
      const day = workout.date.getDay(); // 0 for Sunday, 1 for Monday, etc.
      dailyCounts[day]++;
      totalMinutes += workout.duration;
      totalCalories += workout.calories || 0;
    });
    
    return {
      workoutCount: weeklyWorkouts.length,
      totalMinutes,
      totalCalories,
      dailyCounts
    };
  }
  
  // Utility functions
  calculateCalories(workoutType: string, duration: number, intensity: string): number {
    // Simplified calorie calculation
    // In a real app, this would be more sophisticated
    let caloriesPerMinute = 5; // Base rate
    
    // Adjust based on exercise type
    switch (workoutType.toLowerCase()) {
      case 'running':
        caloriesPerMinute = 10;
        break;
      case 'weight training':
        caloriesPerMinute = 8;
        break;
      case 'cycling':
        caloriesPerMinute = 9;
        break;
      case 'swimming':
        caloriesPerMinute = 11;
        break;
      case 'yoga':
        caloriesPerMinute = 5;
        break;
      default:
        caloriesPerMinute = 7;
    }
    
    // Adjust based on intensity
    const intensityMultiplier = 
      intensity.toLowerCase() === 'high' ? 1.3 :
      intensity.toLowerCase() === 'medium' ? 1.0 :
      0.8; // low intensity
      
    return Math.round(caloriesPerMinute * duration * intensityMultiplier);
  }
  
  // Friendship operations
  async createFriendship(friendship: InsertFriendship): Promise<Friendship> {
    const id = this.friendshipId++;
    const newFriendship: Friendship = {
      ...friendship,
      id,
      createdAt: new Date()
    };
    
    this.friendships.set(id, newFriendship);
    return newFriendship;
  }
  
  async getFriendship(userId: number, friendId: number): Promise<Friendship | undefined> {
    return Array.from(this.friendships.values()).find(
      friendship => 
        (friendship.userId === userId && friendship.friendId === friendId) ||
        (friendship.userId === friendId && friendship.friendId === userId)
    );
  }
  
  async getFriendsByUserId(userId: number): Promise<User[]> {
    // Get all accepted friendships where the user is either userId or friendId
    const friendships = Array.from(this.friendships.values()).filter(
      friendship => 
        friendship.status === "accepted" &&
        (friendship.userId === userId || friendship.friendId === userId)
    );
    
    // Map to get the friend ids
    const friendIds = friendships.map(friendship => 
      friendship.userId === userId ? friendship.friendId : friendship.userId
    );
    
    // Get user objects for these ids
    return Array.from(this.users.values()).filter(user => 
      friendIds.includes(user.id)
    );
  }
  
  async getPendingFriendRequests(userId: number): Promise<Friendship[]> {
    // Get all pending friendships where the user is the recipient (friendId)
    return Array.from(this.friendships.values()).filter(
      friendship => 
        friendship.status === "pending" &&
        friendship.friendId === userId
    );
  }
  
  async updateFriendshipStatus(id: number, status: "accepted" | "rejected"): Promise<Friendship | undefined> {
    const friendship = this.friendships.get(id);
    if (!friendship) return undefined;
    
    const updatedFriendship = { ...friendship, status };
    this.friendships.set(id, updatedFriendship);
    return updatedFriendship;
  }
  
  async deleteFriendship(userId: number, friendId: number): Promise<boolean> {
    const friendship = await this.getFriendship(userId, friendId);
    if (!friendship) return false;
    
    return this.friendships.delete(friendship.id);
  }
  
  // Challenge operations
  async createChallenge(challenge: InsertChallenge): Promise<Challenge> {
    const id = this.challengeId++;
    // Ensure description and exerciseType are properly initialized to null if undefined
    // Convert string dates to Date objects if needed
    const startDate = typeof challenge.startDate === 'string' ? new Date(challenge.startDate) : challenge.startDate;
    const endDate = typeof challenge.endDate === 'string' ? new Date(challenge.endDate) : challenge.endDate;
    
    const newChallenge: Challenge = {
      ...challenge,
      id,
      createdAt: new Date(),
      description: challenge.description ?? null,
      exerciseType: challenge.exerciseType ?? null,
      isPublic: challenge.isPublic ?? true,
      startDate,
      endDate
    };
    
    this.challenges.set(id, newChallenge);
    return newChallenge;
  }
  
  async getChallengeById(id: number): Promise<Challenge | undefined> {
    return this.challenges.get(id);
  }
  
  async getUserChallenges(userId: number): Promise<Challenge[]> {
    // Get challenges created by the user
    const createdChallenges = Array.from(this.challenges.values()).filter(
      challenge => challenge.creatorId === userId
    );
    
    // Get challenges the user participates in
    const participatedChallengeIds = Array.from(this.challengeParticipants.values())
      .filter(participant => participant.userId === userId)
      .map(participant => participant.challengeId);
    
    const participatedChallenges = Array.from(this.challenges.values()).filter(
      challenge => participatedChallengeIds.includes(challenge.id)
    );
    
    // Combine both sets and remove duplicates
    const combinedChallenges = [...createdChallenges, ...participatedChallenges];
    const uniqueChallenges = Array.from(new Map(combinedChallenges.map(
      challenge => [challenge.id, challenge]
    )).values());
    
    return uniqueChallenges;
  }
  
  async getPublicChallenges(limit?: number): Promise<Challenge[]> {
    const publicChallenges = Array.from(this.challenges.values())
      .filter(challenge => challenge.isPublic)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return limit ? publicChallenges.slice(0, limit) : publicChallenges;
  }
  
  async joinChallenge(participant: InsertChallengeParticipant): Promise<ChallengeParticipant> {
    const id = this.challengeParticipantId++;
    const newParticipant: ChallengeParticipant = {
      ...participant,
      id,
      joinedAt: new Date(),
      currentProgress: 0,
      completed: false,
      completedAt: null
    };
    
    this.challengeParticipants.set(id, newParticipant);
    return newParticipant;
  }
  
  async getChallengeParticipants(challengeId: number): Promise<(ChallengeParticipant & { user: User })[]> {
    const participants = Array.from(this.challengeParticipants.values())
      .filter(participant => participant.challengeId === challengeId);
    
    return participants.map(participant => {
      const user = this.users.get(participant.userId);
      if (!user) {
        throw new Error(`User with id ${participant.userId} not found`);
      }
      return {
        ...participant,
        user
      };
    });
  }
  
  async updateChallengeProgress(userId: number, challengeId: number, progress: number): Promise<ChallengeParticipant | undefined> {
    const participant = Array.from(this.challengeParticipants.values()).find(
      p => p.userId === userId && p.challengeId === challengeId
    );
    
    if (!participant) return undefined;
    
    // Get the challenge to check if the progress meets the target
    const challenge = await this.getChallengeById(challengeId);
    if (!challenge) return undefined;
    
    // Update progress
    const updatedParticipant: ChallengeParticipant = {
      ...participant,
      currentProgress: progress
    };
    
    // Check if challenge is completed
    if (progress >= challenge.targetValue && !participant.completed) {
      updatedParticipant.completed = true;
      updatedParticipant.completedAt = new Date();
    }
    
    this.challengeParticipants.set(participant.id, updatedParticipant);
    return updatedParticipant;
  }
  
  async getLeaderboard(challengeId: number): Promise<(ChallengeParticipant & { user: User })[]> {
    const participants = await this.getChallengeParticipants(challengeId);
    
    // Sort by progress in descending order
    return participants.sort((a, b) => b.currentProgress - a.currentProgress);
  }

  // Body Measurement operations
  private bodyMeasurements: Map<number, BodyMeasurement> = new Map();
  private bodyMeasurementId: number = 1;

  async createBodyMeasurement(measurement: InsertBodyMeasurement): Promise<BodyMeasurement> {
    const id = this.bodyMeasurementId++;
    const newMeasurement: BodyMeasurement = {
      ...measurement,
      id,
      date: measurement.date || new Date()
    };
    
    this.bodyMeasurements.set(id, newMeasurement);
    return newMeasurement;
  }

  async getBodyMeasurementById(id: number): Promise<BodyMeasurement | undefined> {
    return this.bodyMeasurements.get(id);
  }

  async getBodyMeasurementsByUserId(userId: number, limit?: number): Promise<BodyMeasurement[]> {
    const measurements = Array.from(this.bodyMeasurements.values())
      .filter(m => m.userId === userId)
      .sort((a, b) => b.date.getTime() - a.date.getTime());
    
    return limit ? measurements.slice(0, limit) : measurements;
  }

  async getBodyMeasurementsByDateRange(userId: number, startDate: Date, endDate: Date): Promise<BodyMeasurement[]> {
    return Array.from(this.bodyMeasurements.values())
      .filter(m => m.userId === userId && m.date >= startDate && m.date <= endDate)
      .sort((a, b) => a.date.getTime() - b.date.getTime());
  }

  async getLatestBodyMeasurement(userId: number): Promise<BodyMeasurement | undefined> {
    const measurements = await this.getBodyMeasurementsByUserId(userId, 1);
    return measurements.length > 0 ? measurements[0] : undefined;
  }

  // User Device operations
  private userDevices: Map<number, UserDevice> = new Map();
  private userDeviceId: number = 1;

  async createUserDevice(device: InsertUserDevice): Promise<UserDevice> {
    const id = this.userDeviceId++;
    const newDevice: UserDevice = {
      ...device,
      id,
      createdAt: new Date(),
      lastSynced: device.lastSynced || new Date()
    };
    
    this.userDevices.set(id, newDevice);
    return newDevice;
  }

  async getUserDevices(userId: number): Promise<UserDevice[]> {
    return Array.from(this.userDevices.values())
      .filter(device => device.userId === userId);
  }

  async updateUserDevice(id: number, updates: Partial<UserDevice>): Promise<UserDevice | undefined> {
    const device = this.userDevices.get(id);
    if (!device) return undefined;
    
    const updatedDevice = { ...device, ...updates };
    this.userDevices.set(id, updatedDevice);
    return updatedDevice;
  }

  async deleteUserDevice(id: number): Promise<boolean> {
    return this.userDevices.delete(id);
  }

  // User Settings operations
  private userSettings: Map<number, UserSettings> = new Map();
  private userSettingsId: number = 1;

  async getUserSettings(userId: number): Promise<UserSettings | undefined> {
    return Array.from(this.userSettings.values()).find(
      settings => settings.userId === userId
    );
  }

  async createUserSettings(settings: InsertUserSettings): Promise<UserSettings> {
    const id = this.userSettingsId++;
    const now = new Date();
    const newSettings: UserSettings = {
      ...settings,
      id,
      createdAt: now,
      updatedAt: now
    };
    
    this.userSettings.set(id, newSettings);
    return newSettings;
  }

  async updateUserSettings(userId: number, updates: Partial<UserSettings>): Promise<UserSettings | undefined> {
    const settings = Array.from(this.userSettings.values()).find(
      s => s.userId === userId
    );
    
    if (!settings) return undefined;
    
    const updatedSettings = { 
      ...settings, 
      ...updates,
      updatedAt: new Date() 
    };
    
    this.userSettings.set(settings.id, updatedSettings);
    return updatedSettings;
  }
}

// Import the database storage implementation
import { dbStorage } from './dbStorage';

// Use database storage instead of in-memory storage
export const storage = dbStorage;
