import Stripe from 'stripe';
import { storage } from './storage';
import { Request, Response } from 'express';

// Use Express.User type to avoid issues with the password property
type UserWithoutPassword = {
  id: number;
  username: string;
  email: string;
  firstName?: string | null;
  lastName?: string | null;
  createdAt: Date;
  isSubscribed: boolean;
  subscriptionTier: string | null;
  subscriptionStartDate: Date | null;
  subscriptionEndDate: Date | null;
  stripeCustomerId: string | null;
  stripeSubscriptionId: string | null;
};

// Initialize Stripe with API key
const stripeClient = new Stripe(process.env.STRIPE_SECRET_KEY || 'dummy_key');

// Subscription plans
export const subscriptionPlans = {
  basic: {
    name: 'Basic',
    price: 4.99,
    description: 'Basic fitness tracking features',
    features: [
      'Unlimited workout logs',
      'Basic workout statistics',
      'Goal tracking'
    ]
  },
  premium: {
    name: 'Premium',
    price: 9.99,
    description: 'Advanced fitness tracking and analysis',
    features: [
      'All Basic features',
      'Advanced workout analytics',
      'Personalized workout recommendations',
      'Progress reports'
    ]
  },
  pro: {
    name: 'Pro',
    price: 19.99,
    description: 'Complete fitness solution for serious athletes',
    features: [
      'All Premium features',
      'AI workout planning',
      'Nutrition tracking',
      'Coach access'
    ]
  }
};

// Create a Stripe checkout session
export async function createCheckoutSession(
  user: UserWithoutPassword,
  planId: 'basic' | 'premium' | 'pro'
) {
  try {
    const plan = subscriptionPlans[planId];
    if (!plan) {
      throw new Error('Invalid plan selected');
    }

    let customer;
    
    // If user doesn't have a Stripe customer ID, create one
    if (!user.stripeCustomerId) {
      customer = await stripeClient.customers.create({
        email: user.email,
        metadata: {
          userId: user.id.toString()
        }
      });
      
      // Update user with new customer ID
      await storage.updateUserStripeCustomerId(user.id, customer.id);
    } else {
      customer = { id: user.stripeCustomerId };
    }

    // Create the checkout session
    const session = await stripeClient.checkout.sessions.create({
      customer: customer.id,
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: `${plan.name} Subscription`,
              description: plan.description
            },
            unit_amount: Math.round(plan.price * 100), // Convert to cents
            recurring: {
              interval: 'month'
            }
          },
          quantity: 1
        }
      ],
      mode: 'subscription',
      success_url: `${process.env.APP_URL || 'http://localhost:5000'}/subscription/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.APP_URL || 'http://localhost:5000'}/subscription/cancel`,
      metadata: {
        userId: user.id.toString(),
        planId: planId
      }
    });

    return session;
  } catch (error) {
    console.error('Error creating checkout session:', error);
    throw error;
  }
}

// Handle Stripe webhook events
export async function handleStripeWebhook(req: Request, res: Response) {
  const signature = req.headers['stripe-signature'] as string;
  
  if (!signature) {
    return res.status(400).send('No signature provided');
  }
  
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!webhookSecret) {
    return res.status(500).send('Webhook secret not configured');
  }

  try {
    const event = stripeClient.webhooks.constructEvent(
      req.body,
      signature,
      webhookSecret
    );

    // Handle the event
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleSuccessfulCheckout(session);
        break;
      }
      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdated(subscription);
        break;
      }
      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionCancelled(subscription);
        break;
      }
      // Add more event handlers as needed
    }

    res.json({ received: true });
  } catch (error) {
    console.error('Webhook error:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    res.status(400).send(`Webhook error: ${errorMessage}`);
  }
}

// Handle successful checkout
async function handleSuccessfulCheckout(session: Stripe.Checkout.Session) {
  try {
    // Get user ID and plan from metadata
    const userId = parseInt(session.metadata?.userId || '0');
    const planId = session.metadata?.planId;
    
    if (!userId || !planId) {
      throw new Error('Missing metadata in checkout session');
    }
    
    // Get the subscription details
    const subscription = await stripeClient.subscriptions.retrieve(
      session.subscription as string
    );
    
    // Calculate end date
    const startDate = new Date(subscription.current_period_start * 1000);
    const endDate = new Date(subscription.current_period_end * 1000);
    
    // Validate plan ID
    const validTier = ['basic', 'premium', 'pro', 'free'].includes(planId)
      ? planId as "basic" | "premium" | "pro" | "free"
      : 'basic';
      
    // Update user subscription
    await storage.updateUserSubscription(userId, {
      isSubscribed: true,
      subscriptionTier: validTier,
      subscriptionStartDate: startDate,
      subscriptionEndDate: endDate,
      stripeSubscriptionId: subscription.id
    });
    
  } catch (error) {
    console.error('Error handling successful checkout:', error);
  }
}

// Handle subscription updates
async function handleSubscriptionUpdated(subscription: Stripe.Subscription) {
  try {
    // Find user by customer ID
    const user = await storage.getUserByStripeCustomerId(subscription.customer as string);
    
    if (!user) {
      throw new Error('User not found for subscription update');
    }
    
    // Calculate new end date
    const startDate = new Date(subscription.current_period_start * 1000);
    const endDate = new Date(subscription.current_period_end * 1000);
    
    // Get plan from metadata or subscription item
    const planId = subscription.metadata.planId;
    
    // Validate plan ID
    const validTier = ['basic', 'premium', 'pro', 'free'].includes(planId) 
      ? planId as "basic" | "premium" | "pro" | "free"
      : 'basic';
    
    // Update user subscription
    await storage.updateUserSubscription(user.id, {
      isSubscribed: subscription.status === 'active',
      subscriptionTier: validTier,
      subscriptionStartDate: startDate,
      subscriptionEndDate: endDate
    });
    
  } catch (error) {
    console.error('Error handling subscription update:', error);
  }
}

// Handle subscription cancellation
async function handleSubscriptionCancelled(subscription: Stripe.Subscription) {
  try {
    // Find user by customer ID
    const user = await storage.getUserByStripeCustomerId(subscription.customer as string);
    
    if (!user) {
      throw new Error('User not found for subscription cancellation');
    }
    
    // Update user subscription
    await storage.updateUserSubscription(user.id, {
      isSubscribed: false,
      subscriptionTier: 'free'
    });
    
  } catch (error) {
    console.error('Error handling subscription cancellation:', error);
  }
}

// Get subscription plans
export function getSubscriptionPlans() {
  return subscriptionPlans;
}

// Cancel a subscription
export async function cancelSubscription(userId: number) {
  try {
    const user = await storage.getUser(userId);
    
    if (!user || !user.stripeSubscriptionId) {
      throw new Error('User or subscription not found');
    }
    
    await stripeClient.subscriptions.cancel(user.stripeSubscriptionId);
    
    // Update user in database
    await storage.updateUserSubscription(userId, {
      isSubscribed: false,
      subscriptionTier: 'free'
    });
    
    return { success: true, message: 'Subscription cancelled successfully' };
  } catch (error) {
    console.error('Error cancelling subscription:', error);
    throw error;
  }
}