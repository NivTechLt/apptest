import nodemailer from 'nodemailer';

// Create email transporter
// For development/testing, create a test account with Ethereal Email
let transporter: nodemailer.Transporter;

// Initialize the transporter
export async function initializeEmailService() {
  // If we're in production, use real email credentials
  if (process.env.NODE_ENV === 'production' && process.env.EMAIL_HOST) {
    transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: parseInt(process.env.EMAIL_PORT || '587'),
      secure: process.env.EMAIL_SECURE === 'true',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
      },
    });
  } else {
    // For development - use Ethereal Email (fake SMTP service)
    const testAccount = await nodemailer.createTestAccount();

    transporter = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: {
        user: testAccount.user,
        pass: testAccount.pass,
      },
    });

    console.log('Development email account created:', testAccount.user);
    console.log('Preview URL for emails: https://ethereal.email/');
  }

  return transporter;
}

// Function to send an email
export async function sendEmail({
  to,
  subject,
  html,
  text
}: {
  to: string;
  subject: string;
  html: string;
  text?: string;
}) {
  if (!transporter) {
    console.log('Email transporter not initialized. Initializing now...');
    await initializeEmailService();
  }

  try {
    const info = await transporter.sendMail({
      from: `"Fitness Tracker" <${process.env.EMAIL_FROM || 'noreply@fitnessapp.example.com'}>`,
      to,
      subject,
      text: text || '',
      html,
    });

    console.log('Email sent:', info.messageId);
    
    // If using Ethereal Email, log the preview URL
    if (process.env.NODE_ENV !== 'production' && nodemailer.getTestMessageUrl(info)) {
      console.log('Preview URL:', nodemailer.getTestMessageUrl(info));
    }
    
    return info;
  } catch (error) {
    console.error('Error sending email:', error);
    throw error;
  }
}

// Email templates
export function getVerificationEmailTemplate(token: string) {
  const verificationUrl = `${process.env.APP_URL || 'http://localhost:5000'}/verify-email?token=${token}`;
  
  return {
    subject: 'Verify Your Email Address',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eaeaea; border-radius: 5px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <h1 style="color: #333;">Verify Your Email</h1>
        </div>
        
        <div style="color: #555; line-height: 1.5;">
          <p>Thank you for signing up! To complete your registration and access all features, please verify your email address.</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${verificationUrl}" style="background-color: #4CAF50; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Verify Email Address</a>
          </div>
          
          <p>Or copy and paste this link into your browser:</p>
          <p style="word-break: break-all; color: #0066cc;">${verificationUrl}</p>
          
          <p>This verification link will expire in 24 hours.</p>
          
          <p>If you did not create an account, you can safely ignore this email.</p>
        </div>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eaeaea; color: #777; font-size: 12px;">
          <p>This is an automated email. Please do not reply to this message.</p>
        </div>
      </div>
    `,
    text: `
      Verify Your Email Address
      
      Thank you for signing up! To complete your registration and access all features, please verify your email address by clicking the link below:
      
      ${verificationUrl}
      
      This verification link will expire in 24 hours.
      
      If you did not create an account, you can safely ignore this email.
    `
  };
}

export function getPasswordResetEmailTemplate(token: string) {
  const resetUrl = `${process.env.APP_URL || 'http://localhost:5000'}/reset-password?token=${token}`;
  
  return {
    subject: 'Reset Your Password',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eaeaea; border-radius: 5px;">
        <div style="text-align: center; margin-bottom: 20px;">
          <h1 style="color: #333;">Reset Your Password</h1>
        </div>
        
        <div style="color: #555; line-height: 1.5;">
          <p>We received a request to reset your password. If you didn't make this request, you can safely ignore this email.</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetUrl}" style="background-color: #4CAF50; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Reset Password</a>
          </div>
          
          <p>Or copy and paste this link into your browser:</p>
          <p style="word-break: break-all; color: #0066cc;">${resetUrl}</p>
          
          <p>This password reset link will expire in 24 hours.</p>
        </div>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eaeaea; color: #777; font-size: 12px;">
          <p>This is an automated email. Please do not reply to this message.</p>
        </div>
      </div>
    `,
    text: `
      Reset Your Password
      
      We received a request to reset your password. If you didn't make this request, you can safely ignore this email.
      
      To reset your password, please click the link below:
      
      ${resetUrl}
      
      This password reset link will expire in 24 hours.
    `
  };
}