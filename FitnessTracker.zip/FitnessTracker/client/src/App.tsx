import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Progress from "@/pages/Progress";
import Goals from "@/pages/Goals";
import Settings from "@/pages/Settings";
import AuthPage from "@/pages/auth-page";
import SubscriptionPage from "@/pages/subscription-page";
import PremiumFeatures from "@/pages/PremiumFeatures";
import Challenges from "@/pages/Challenges";
import BodyMeasurements from "./pages/BodyMeasurements";
import AdminDashboard from "@/pages/AdminDashboard";
import BottomNavigation from "@/components/BottomNavigation";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WorkoutForm from "@/components/WorkoutForm";
import { useState } from "react";
import { ThemeProvider } from "@/lib/theme-context";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { useAuth } from "@/hooks/use-auth";

function MainLayout() {
  const [showWorkoutForm, setShowWorkoutForm] = useState(false);
  const { user } = useAuth();

  const handleAddWorkout = () => {
    setShowWorkoutForm(true);
  };

  const handleCloseWorkout = () => {
    setShowWorkoutForm(false);
  };

  if (!user) return null;

  return (
    <div className="flex flex-col min-h-screen relative">
      <Header />
      
      <div className="flex-1 pb-20 overflow-y-auto">
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/progress" component={Progress} />
          <Route path="/goals" component={Goals} />
          <Route path="/settings" component={Settings} />
          <Route path="/premium" component={PremiumFeatures} />
          <Route path="/challenges" component={Challenges} />
          <Route path="/measurements" component={BodyMeasurements} />
        </Switch>
      </div>
      
      <Footer />
      <BottomNavigation onAddWorkout={handleAddWorkout} />
      <WorkoutForm 
        isVisible={showWorkoutForm}
        onClose={handleCloseWorkout}
      />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={MainLayout} />
      <ProtectedRoute path="/progress" component={MainLayout} />
      <ProtectedRoute path="/goals" component={MainLayout} />
      <ProtectedRoute path="/settings" component={MainLayout} />
      <ProtectedRoute path="/premium" component={MainLayout} />
      <ProtectedRoute path="/challenges" component={MainLayout} />
      <ProtectedRoute path="/measurements" component={MainLayout} />
      <ProtectedRoute path="/subscription" component={SubscriptionPage} />
      <ProtectedRoute path="/admin" component={AdminDashboard} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="system">
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <Router />
          <Toaster />
        </AuthProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
