import { Card, CardContent } from "@/components/ui/card";
import { startOfWeek, endOfWeek, format } from "date-fns";
import { Calendar, Flame, Clock } from "lucide-react";

interface WeeklySummaryProps {
  stats: {
    workoutCount: number;
    totalMinutes: number;
    totalCalories: number;
    dailyCounts: number[];
  };
  startDate: Date;
}

export default function WeeklySummary({ stats, startDate }: WeeklySummaryProps) {
  // Calculate date range for the week
  const weekStart = startOfWeek(startDate, { weekStartsOn: 1 }); // Start from Monday
  const weekEnd = endOfWeek(startDate, { weekStartsOn: 1 });
  
  const dateRange = `${format(weekStart, 'MMM d')} - ${format(weekEnd, 'MMM d')}`;
  
  // Weekday labels
  const weekdays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  
  return (
    <section className="bg-white dark:bg-gray-900 rounded-xl shadow-md p-5 overflow-hidden relative">
      <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 dark:bg-primary/10 rounded-full -mr-16 -mt-16 z-0"></div>
      
      <div className="flex items-center justify-between mb-6 relative z-10">
        <div className="flex items-center">
          <Calendar className="h-5 w-5 text-primary mr-2" />
          <h2 className="font-bold text-lg dark:text-white">Weekly Progress</h2>
        </div>
        <div className="text-sm font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full">
          {dateRange}
        </div>
      </div>
      
      {/* Bar Chart */}
      <div className="chart-container mb-3 h-[180px] relative z-10 mx-1">
        <div className="absolute left-0 right-0 h-[1px] bg-gray-100 dark:bg-gray-700 bottom-0"></div>
        <div className="absolute left-0 right-0 h-[1px] bg-gray-100 dark:bg-gray-700 bottom-1/4"></div>
        <div className="absolute left-0 right-0 h-[1px] bg-gray-100 dark:bg-gray-700 bottom-1/2"></div>
        <div className="absolute left-0 right-0 h-[1px] bg-gray-100 dark:bg-gray-700 bottom-3/4"></div>
        
        {stats.dailyCounts.map((count, index) => {
          const height = count === 0 ? 0 : Math.max(15, (count / Math.max(...stats.dailyCounts, 1)) * 100);
          const isToday = index === new Date().getDay() - 1;
          return (
            <div key={index} className="absolute bottom-0 flex flex-col items-center" style={{ left: `${index * 14.25}%` }}>
              <div 
                className={`w-7 rounded-t-md ${isToday ? 'bg-primary' : 'bg-primary/70'}`}
                style={{ 
                  height: `${height}%`,
                  transition: 'height 0.5s cubic-bezier(0.4, 0, 0.2, 1)',
                  boxShadow: isToday ? '0 4px 6px -1px rgba(0, 0, 0, 0.1)' : 'none'
                }}
              >
                {count > 0 && (
                  <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-gray-800 dark:bg-gray-700 text-white text-xs font-medium px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                    {count}
                  </div>
                )}
              </div>
              <div className={`text-xs mt-2 font-medium ${isToday ? 'text-primary' : 'text-gray-500 dark:text-gray-400'}`}>
                {weekdays[index]}
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Weekly Stats */}
      <div className="grid grid-cols-3 gap-4 mt-6 relative z-10">
        <div className="flex flex-col items-center justify-center p-3 rounded-lg bg-primary/5 dark:bg-primary/10">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 dark:bg-primary/20 mb-2">
            <Calendar className="h-4 w-4 text-primary" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.workoutCount}</p>
          <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mt-1">Workouts</p>
        </div>
        
        <div className="flex flex-col items-center justify-center p-3 rounded-lg bg-primary/5 dark:bg-primary/10">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 dark:bg-primary/20 mb-2">
            <Clock className="h-4 w-4 text-primary" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">{stats.totalMinutes}</p>
          <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mt-1">Minutes</p>
        </div>
        
        <div className="flex flex-col items-center justify-center p-3 rounded-lg bg-primary/5 dark:bg-primary/10">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/10 dark:bg-primary/20 mb-2">
            <Flame className="h-4 w-4 text-primary" />
          </div>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            {stats.totalCalories.toLocaleString()}
          </p>
          <p className="text-xs font-medium text-gray-500 dark:text-gray-400 mt-1">Calories</p>
        </div>
      </div>
    </section>
  );
}
