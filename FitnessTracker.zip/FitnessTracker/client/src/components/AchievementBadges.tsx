import { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/use-auth';
import { hasFeatureAccess } from '@/lib/subscription-utils';
import SubscriptionFeature from './SubscriptionFeature';
import { Star, Award, Zap, Heart, Flame, Trophy, Target } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// Sample achievement data
const achievements = [
  {
    id: 'first-workout',
    name: 'First Workout',
    description: 'Completed your first workout',
    icon: Zap,
    earned: true,
    date: '2023-09-15',
    color: 'green'
  },
  {
    id: 'streak-7',
    name: '7-Day Streak',
    description: 'Worked out for 7 consecutive days',
    icon: Flame,
    earned: true,
    date: '2023-09-22',
    color: 'orange'
  },
  {
    id: 'goal-reached',
    name: 'Goal Crusher',
    description: 'Reached your first fitness goal',
    icon: Target,
    earned: true,
    date: '2023-10-05',
    color: 'blue'
  },
  {
    id: 'calories-1000',
    name: 'Calorie Burner',
    description: 'Burned over 1,000 calories in a week',
    icon: Flame,
    earned: false,
    progress: 65,
    color: 'red'
  },
  {
    id: 'variety-5',
    name: 'Exercise Explorer',
    description: 'Tried 5 different workout types',
    icon: Star,
    earned: false,
    progress: 80,
    color: 'purple'
  },
  {
    id: 'pro-user',
    name: 'Pro Athlete',
    description: 'Upgraded to Pro subscription',
    icon: Trophy,
    earned: false,
    color: 'gold'
  },
  {
    id: 'heart-health',
    name: 'Heart Health',
    description: 'Logged 20 cardio workouts',
    icon: Heart,
    earned: false,
    progress: 40,
    color: 'pink'
  },
  {
    id: 'consistency',
    name: 'Consistency',
    description: 'Worked out 3+ times per week for a month',
    icon: Award,
    earned: false,
    progress: 25,
    color: 'indigo'
  }
];

export default function AchievementBadges() {
  const { user } = useAuth();
  
  // Check if user has access to achievements feature
  const hasAccess = hasFeatureAccess(user, 'achievementBadges');
  
  // Badge colors based on achievement type
  const getBadgeColor = (color: string) => {
    switch(color) {
      case 'green': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'blue': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'red': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      case 'orange': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300';
      case 'purple': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
      case 'pink': return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-300';
      case 'indigo': return 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-300';
      case 'gold': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
    }
  };
  
  // Badge components
  const Achievement = ({ achievement }: { achievement: typeof achievements[0] }) => {
    const Icon = achievement.icon;
    const badgeColor = getBadgeColor(achievement.color);
    
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div 
              className={`relative flex flex-col items-center justify-center p-3 rounded-lg transition-all ${
                achievement.earned 
                  ? `${badgeColor} cursor-pointer hover:scale-105` 
                  : 'bg-gray-100 text-gray-400 dark:bg-gray-800 dark:text-gray-500 opacity-60'
              }`}
            >
              <Icon className={`h-8 w-8 mb-2 ${achievement.earned ? '' : 'opacity-40'}`} />
              <p className="text-xs font-medium text-center">{achievement.name}</p>
              
              {!achievement.earned && achievement.progress && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-200 dark:bg-gray-700 rounded-b-lg overflow-hidden">
                  <div 
                    className="h-full bg-primary"
                    style={{ width: `${achievement.progress}%` }}
                  ></div>
                </div>
              )}
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <div className="space-y-1">
              <p className="font-medium">{achievement.name}</p>
              <p className="text-xs text-muted-foreground">{achievement.description}</p>
              {achievement.earned && (
                <p className="text-xs text-primary">Earned on {achievement.date}</p>
              )}
              {!achievement.earned && achievement.progress && (
                <p className="text-xs text-muted-foreground">Progress: {achievement.progress}%</p>
              )}
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  };
  
  // The achievements UI
  const Achievements = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-primary" />
          Achievements
        </CardTitle>
        <CardDescription>
          Track your fitness milestones and collect badges
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {achievements.map((achievement) => (
            <Achievement key={achievement.id} achievement={achievement} />
          ))}
        </div>
      </CardContent>
    </Card>
  );
  
  // Display the feature or the premium upgrade prompt
  return (
    <SubscriptionFeature 
      featureKey="achievementBadges" 
      requiredTier="premium"
    >
      <Achievements />
    </SubscriptionFeature>
  );
}