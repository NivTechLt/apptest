import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, Clock, Send, UserRound, Users } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

const coaches = [
  { 
    id: 1, 
    name: "Emma Wilson", 
    avatar: "/coach1.jpg",
    specialty: "Strength & Conditioning",
    experience: "8 years",
    availability: [10, 11, 14, 15, 16] // Hours
  },
  { 
    id: 2, 
    name: "Marcus Chen", 
    avatar: "/coach2.jpg",
    specialty: "Nutrition & Weight Management",
    experience: "6 years",
    availability: [9, 13, 14, 17, 18] // Hours
  },
  { 
    id: 3, 
    name: "Sarah Johnson", 
    avatar: "/coach3.jpg",
    specialty: "Yoga & Flexibility",
    experience: "10 years",
    availability: [8, 9, 12, 16, 17] // Hours
  }
];

export default function CoachConsultation() {
  const [selectedCoach, setSelectedCoach] = useState<number | null>(null);
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [timeSlot, setTimeSlot] = useState<number | null>(null);
  const [topic, setTopic] = useState('');
  const [message, setMessage] = useState('');
  const { toast } = useToast();
  
  const handleSubmit = () => {
    if (!selectedCoach || !date || timeSlot === null || !topic) {
      toast({
        title: "Missing information",
        description: "Please fill out all required fields to book a consultation.",
        variant: "destructive"
      });
      return;
    }
    
    // In a real app, this would make an API call to schedule the consultation
    toast({
      title: "Consultation scheduled!",
      description: `Your consultation with ${coaches.find(c => c.id === selectedCoach)?.name} is confirmed.`,
    });
    
    // Reset form
    setSelectedCoach(null);
    setDate(undefined);
    setTimeSlot(null);
    setTopic('');
    setMessage('');
  };
  
  const getAvailableHours = () => {
    if (!selectedCoach) return [];
    
    const coach = coaches.find(c => c.id === selectedCoach);
    return coach ? coach.availability : [];
  };
  
  const formatHour = (hour: number) => {
    return `${hour % 12 === 0 ? 12 : hour % 12}:00 ${hour >= 12 ? 'PM' : 'AM'}`;
  };
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Book a Coach Consultation
          </CardTitle>
          <CardDescription>
            Schedule a one-on-one session with one of our expert fitness coaches
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Coach Selection */}
          <div className="space-y-2">
            <Label>Select a Coach</Label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {coaches.map(coach => (
                <div
                  key={coach.id}
                  className={cn(
                    "border rounded-lg p-4 cursor-pointer transition-all",
                    selectedCoach === coach.id 
                      ? "border-primary bg-primary/5 dark:bg-primary/20" 
                      : "hover:border-muted-foreground"
                  )}
                  onClick={() => setSelectedCoach(coach.id)}
                >
                  <div className="flex items-center gap-3 mb-3">
                    <Avatar>
                      <AvatarImage src={coach.avatar} />
                      <AvatarFallback>{coach.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">{coach.name}</p>
                      <p className="text-xs text-muted-foreground">{coach.experience} experience</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="mb-1">{coach.specialty}</Badge>
                </div>
              ))}
            </div>
          </div>
          
          {/* Date Selection */}
          {selectedCoach && (
            <div className="space-y-2">
              <Label>Select Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : "Select a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={setDate}
                    initialFocus
                    disabled={(date) => 
                      date < new Date(new Date().setHours(0, 0, 0, 0)) ||
                      date > new Date(new Date().setDate(new Date().getDate() + 14))
                    }
                  />
                </PopoverContent>
              </Popover>
            </div>
          )}
          
          {/* Time Slot Selection */}
          {selectedCoach && date && (
            <div className="space-y-2">
              <Label>Select Time</Label>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                {getAvailableHours().map(hour => (
                  <Button
                    key={hour}
                    variant={timeSlot === hour ? "default" : "outline"}
                    className="flex items-center gap-1"
                    onClick={() => setTimeSlot(hour)}
                  >
                    <Clock className="h-3 w-3" />
                    {formatHour(hour)}
                  </Button>
                ))}
              </div>
            </div>
          )}
          
          {/* Consultation Details */}
          {selectedCoach && date && timeSlot !== null && (
            <>
              <div className="space-y-2">
                <Label htmlFor="topic">Consultation Topic</Label>
                <Input
                  id="topic"
                  placeholder="E.g., Weight loss plan, Strength training advice"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="message">Additional Information</Label>
                <Textarea
                  id="message"
                  placeholder="Describe your fitness goals, concerns, or questions for the coach..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={4}
                />
              </div>
            </>
          )}
        </CardContent>
        <CardFooter>
          <Button 
            className="w-full" 
            disabled={!selectedCoach || !date || timeSlot === null || !topic}
            onClick={handleSubmit}
          >
            <Send className="mr-2 h-4 w-4" />
            Schedule Consultation
          </Button>
        </CardFooter>
      </Card>
      
      {/* Active Consultations */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <UserRound className="h-4 w-4 text-primary" />
            Your Upcoming Consultations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6 text-muted-foreground">
            You don't have any upcoming consultations scheduled.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}