import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { X, Clock, Check, Dumbbell, Save } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertWorkoutSchema } from "@shared/schema";
import ExerciseTypeButton from "@/components/ui/exercise-type-button";
import IntensityButtonGroup from "@/components/ui/intensity-button-group";
import { EXERCISE_TYPES } from "@/lib/constants";

// Extend the workout schema with form validation
const workoutFormSchema = insertWorkoutSchema.extend({
  duration: z.number().min(1, "Duration must be at least 1 minute").max(1440, "Duration cannot exceed 24 hours"),
});

type WorkoutFormValues = z.infer<typeof workoutFormSchema>;

interface WorkoutFormProps {
  isVisible: boolean;
  onClose: () => void;
}

const DEFAULT_USER_ID = 1;

export default function WorkoutForm({ isVisible, onClose }: WorkoutFormProps) {
  const { toast } = useToast();
  const [selectedExerciseType, setSelectedExerciseType] = useState(EXERCISE_TYPES[0].value);
  const [selectedIntensity, setSelectedIntensity] = useState<'low' | 'medium' | 'high'>('medium');
  
  // Form setup
  const form = useForm<WorkoutFormValues>({
    resolver: zodResolver(workoutFormSchema),
    defaultValues: {
      userId: DEFAULT_USER_ID,
      exerciseType: selectedExerciseType,
      duration: 30,
      intensity: selectedIntensity,
      notes: '',
    },
  });
  
  // Create workout mutation
  const createWorkoutMutation = useMutation<unknown, Error, WorkoutFormValues>({
    mutationFn: (newWorkout: WorkoutFormValues) => {
      return apiRequest('POST', '/api/workouts', newWorkout);
    },
    onSuccess: () => {
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/workouts/user', DEFAULT_USER_ID] });
      queryClient.invalidateQueries({ queryKey: ['/api/workouts/recent', DEFAULT_USER_ID] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/weekly', DEFAULT_USER_ID] });
      
      toast({
        title: "Workout added",
        description: "Your workout has been recorded successfully.",
      });
      
      // Reset form and close
      form.reset({
        userId: DEFAULT_USER_ID,
        exerciseType: EXERCISE_TYPES[0].value,
        duration: 30,
        intensity: 'medium',
        notes: '',
      });
      setSelectedExerciseType(EXERCISE_TYPES[0].value);
      setSelectedIntensity('medium');
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Failed to add workout",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: WorkoutFormValues) => {
    // Update values with the latest selected options
    values.exerciseType = selectedExerciseType;
    values.intensity = selectedIntensity;
    
    createWorkoutMutation.mutate(values);
  };
  
  const handleExerciseTypeSelect = (type: string) => {
    setSelectedExerciseType(type);
    form.setValue('exerciseType', type);
  };
  
  const handleIntensitySelect = (intensity: 'low' | 'medium' | 'high') => {
    setSelectedIntensity(intensity);
    form.setValue('intensity', intensity);
  };
  
  return (
    <div 
      className={`fixed inset-0 bg-white dark:bg-gray-950 z-50 transform transition-transform duration-300 overflow-y-auto ${
        isVisible ? 'translate-y-0' : 'translate-y-full'
      }`}
    >
      <div className="sticky top-0 bg-white dark:bg-gray-950 z-10 border-b border-gray-100 dark:border-gray-800 shadow-sm">
        <div className="px-4 py-4 flex items-center justify-between">
          <button 
            className="rounded-full w-10 h-10 flex items-center justify-center hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            onClick={onClose}
            aria-label="Close form"
          >
            <X className="h-5 w-5 text-gray-600 dark:text-gray-400" />
          </button>
          <h2 className="font-bold text-lg flex items-center dark:text-white">
            <Dumbbell className="h-5 w-5 text-primary mr-2" />
            Add Workout
          </h2>
          <Button
            size="sm"
            onClick={form.handleSubmit(onSubmit)}
            disabled={createWorkoutMutation.isPending}
            className="rounded-full px-4"
          >
            {createWorkoutMutation.isPending ? (
              <span className="flex items-center">
                Saving
                <span className="ml-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
              </span>
            ) : (
              <span className="flex items-center">
                Save
                <Save className="ml-1 h-4 w-4" />
              </span>
            )}
          </Button>
        </div>
      </div>
      
      <div className="p-5 space-y-7 max-w-md mx-auto pb-24">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-7">
            {/* Exercise Type Selection */}
            <div className="space-y-3">
              <div className="flex items-center mb-1">
                <FormLabel className="text-base font-semibold text-gray-900 dark:text-white">Exercise Type</FormLabel>
                <FormDescription className="ml-2 dark:text-gray-400">Select your activity</FormDescription>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                {EXERCISE_TYPES.map((type) => (
                  <ExerciseTypeButton
                    key={type.value}
                    icon={type.icon}
                    label={type.label}
                    isSelected={selectedExerciseType === type.value}
                    onClick={() => handleExerciseTypeSelect(type.value)}
                  />
                ))}
              </div>
            </div>
            
            {/* Duration Input */}
            <FormField
              control={form.control}
              name="duration"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <div className="flex items-center mb-1">
                    <FormLabel className="text-base font-semibold text-gray-900 dark:text-white">Duration</FormLabel>
                    <FormDescription className="ml-2 dark:text-gray-400">Minutes spent exercising</FormDescription>
                  </div>
                  <div className="relative">
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        {...field}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                        className="pl-10 text-base h-12 dark:bg-gray-800 dark:border-gray-700 dark:text-white"
                      />
                    </FormControl>
                    <div className="absolute left-3 top-1/2 -translate-y-1/2">
                      <Clock className="h-5 w-5 text-gray-400 dark:text-gray-500" />
                    </div>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {/* Intensity Selection */}
            <div className="space-y-3">
              <div className="flex items-center mb-1">
                <FormLabel className="text-base font-semibold text-gray-900 dark:text-white">Intensity</FormLabel>
                <FormDescription className="ml-2 dark:text-gray-400">How hard did you push?</FormDescription>
              </div>
              <IntensityButtonGroup
                selectedIntensity={selectedIntensity}
                onSelect={handleIntensitySelect}
              />
            </div>
            
            {/* Notes Input */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <div className="flex items-center mb-1">
                    <FormLabel className="text-base font-semibold text-gray-900 dark:text-white">Notes</FormLabel>
                    <FormDescription className="ml-2 dark:text-gray-400">Optional details about your workout</FormDescription>
                  </div>
                  <FormControl>
                    <Textarea
                      placeholder="How was your workout? Add any details you want to remember..."
                      className="resize-none h-24 text-base dark:bg-gray-800 dark:border-gray-700 dark:text-white dark:placeholder:text-gray-500"
                      {...field}
                      value={field.value || ''} // Handle null values to fix TypeScript error
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </form>
        </Form>
      </div>
    </div>
  );
}
