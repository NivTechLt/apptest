import React from "react";
import NiaLogo from "./NiaLogo";

export default function Footer() {
  return (
    <footer className="py-4 pb-24 border-t border-border bg-background">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center justify-center">
          <div className="text-sm text-muted-foreground mb-3">
            FitTrack v1.0.0 © {new Date().getFullYear()}
          </div>
          
          {/* Using React component for the logo */}
          <div className="flex flex-col items-center">
            <div className="bg-black rounded-xl p-2">
              <NiaLogo width={80} height={80} />
            </div>
            <div className="text-sm font-semibold mt-2">
              NIV Technology
            </div>
          </div>
          
          <div className="text-xs text-muted-foreground mt-2">
            Developing innovative solutions for fitness and health
          </div>
        </div>
      </div>
    </footer>
  );
}