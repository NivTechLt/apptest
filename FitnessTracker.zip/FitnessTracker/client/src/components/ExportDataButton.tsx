import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { hasFeatureAccess } from '@/lib/subscription-utils';
import { Download, FileType, DownloadCloud, Loader2 } from 'lucide-react';
import SubscriptionFeature from './SubscriptionFeature';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ExportDataButtonProps {
  className?: string;
  variant?: 'default' | 'outline' | 'ghost' | 'secondary';
  compact?: boolean;
}

export default function ExportDataButton({ 
  className = '', 
  variant = 'outline', 
  compact = false 
}: ExportDataButtonProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isExporting, setIsExporting] = useState(false);
  const [exportFormat, setExportFormat] = useState<string | null>(null);
  
  // Check if user has access to export feature
  const canExport = hasFeatureAccess(user, 'exportData');
  
  // Handle export data
  const handleExport = async (format: 'csv' | 'pdf' | 'json') => {
    if (!canExport) return;
    
    setExportFormat(format);
    setIsExporting(true);
    
    try {
      const response = await apiRequest('GET', `/api/workouts/export?format=${format}`);
      
      // Check if response is successful
      if (!response.ok) {
        throw new Error('Failed to export data');
      }
      
      // Get the blob data
      const blob = await response.blob();
      
      // Create a download link and trigger download
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `workouts-export-${new Date().toISOString().split('T')[0]}.${format}`;
      document.body.appendChild(a);
      a.click();
      
      // Clean up
      window.URL.revokeObjectURL(url);
      a.remove();
      
      toast({
        title: 'Export successful',
        description: `Your workout data has been exported as ${format.toUpperCase()}`,
      });
    } catch (error) {
      toast({
        title: 'Export failed',
        description: error instanceof Error ? error.message : 'Failed to export data',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
      setExportFormat(null);
    }
  };
  
  // The button component to render inside the SubscriptionFeature
  const ExportButton = () => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant={variant} 
          size={compact ? "sm" : "default"}
          className={`gap-2 ${className}`}
          disabled={isExporting}
        >
          {isExporting ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Exporting {exportFormat?.toUpperCase()}...
            </>
          ) : (
            <>
              <Download className="h-4 w-4" />
              {!compact && "Export Data"}
            </>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => handleExport('csv')}>
          <FileType className="h-4 w-4 mr-2" />
          <span>Export as CSV</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport('pdf')}>
          <FileType className="h-4 w-4 mr-2" />
          <span>Export as PDF</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport('json')}>
          <FileType className="h-4 w-4 mr-2" />
          <span>Export as JSON</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
  
  // If user doesn't have premium access, show a compact button that reveals the premium feature
  return (
    <SubscriptionFeature 
      featureKey="exportData"
      requiredTier="premium"
      fallback={compact ? undefined : (
        <Button 
          variant={variant} 
          size={compact ? "sm" : "default"}
          className={`gap-2 ${className}`}
        >
          <DownloadCloud className="h-4 w-4" />
          {!compact && "Export Data"}
        </Button>
      )}
    >
      <ExportButton />
    </SubscriptionFeature>
  );
}