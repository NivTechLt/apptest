import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { BrainCircuit, Loader2, Calendar, Dumbbell } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { hasFeatureAccess } from '@/lib/subscription-utils';
import SubscriptionFeature from './SubscriptionFeature';
import { useToast } from '@/hooks/use-toast';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Mock fitness goals for the demo
const fitnessGoals = [
  { value: 'weightLoss', label: 'Weight Loss' },
  { value: 'muscleGain', label: 'Muscle Gain' },
  { value: 'endurance', label: 'Endurance' },
  { value: 'flexibility', label: 'Flexibility' },
  { value: 'general', label: 'General Fitness' }
];

// Mock fitness levels for the demo
const fitnessLevels = [
  { value: 'beginner', label: 'Beginner' },
  { value: 'intermediate', label: 'Intermediate' },
  { value: 'advanced', label: 'Advanced' }
];

// Sample workout routine that would be returned by the AI
const sampleWorkoutPlan = `
## Custom 4-Week Workout Plan

### Week 1: Foundation Building
**Monday**: Upper Body Focus
- Pushups: 3 sets of 10 reps
- Dumbbell rows: 3 sets of 12 reps
- Shoulder press: 3 sets of 10 reps
- Bicep curls: 3 sets of 12 reps
- Cool down: 5-minute stretching

**Wednesday**: Lower Body Focus
- Bodyweight squats: 3 sets of 15 reps
- Lunges: 3 sets of 10 reps each leg
- Glute bridges: 3 sets of 15 reps
- Calf raises: 3 sets of 20 reps
- Cool down: 5-minute stretching

**Friday**: Full Body Circuit
- Jumping jacks: 45 seconds
- Mountain climbers: 45 seconds
- Plank: 30 seconds
- Rest: 30 seconds
- Repeat circuit 4 times
- Cool down: 5-minute stretching

### Week 2: Progressive Overload
**Monday**: Upper Body Strength
- Pushups: 3 sets of 12 reps
- Dumbbell rows: 3 sets of 15 reps
- Shoulder press: 3 sets of 12 reps
- Tricep dips: 3 sets of 10 reps
- Cool down: 5-minute stretching

**Wednesday**: Lower Body Strength
- Bodyweight squats: 4 sets of 15 reps
- Walking lunges: 3 sets of 12 reps each leg
- Single-leg glute bridges: 3 sets of 10 reps each side
- Wall sit: 3 sets of 30 seconds
- Cool down: 5-minute stretching

**Friday**: HIIT Training
- High knees: 40 seconds
- Burpees: 40 seconds
- Plank jacks: 40 seconds
- Rest: 20 seconds
- Repeat circuit 5 times
- Cool down: 5-minute stretching

### Week 3: Intensity Increase
**Monday**: Upper Body Power
- Incline pushups: 3 sets of 12 reps
- Bent over rows: 3 sets of 15 reps
- Arnold press: 3 sets of 12 reps
- Hammer curls: 3 sets of 12 reps
- Cool down: 5-minute stretching

**Wednesday**: Lower Body Power
- Jump squats: 3 sets of 15 reps
- Reverse lunges: 3 sets of 12 reps each leg
- Sumo squats: 3 sets of 15 reps
- Step-ups: 3 sets of 10 reps each leg
- Cool down: 5-minute stretching

**Friday**: Tabata Workout
- Squat jumps: 20 seconds on, 10 seconds off
- Pushups: 20 seconds on, 10 seconds off
- Mountain climbers: 20 seconds on, 10 seconds off
- Bicycle crunches: 20 seconds on, 10 seconds off
- Repeat for 4 rounds
- Cool down: 5-minute stretching

### Week 4: Peak Performance
**Monday**: Upper Body Challenge
- Diamond pushups: 3 sets of 10 reps
- Renegade rows: 3 sets of 12 reps
- Pike pushups: 3 sets of 10 reps
- Plank to pushup: 3 sets of 8 reps
- Cool down: 5-minute stretching

**Wednesday**: Lower Body Challenge
- Pistol squats (assisted): 3 sets of 8 reps each leg
- Bulgarian split squats: 3 sets of 10 reps each leg
- Curtsy lunges: 3 sets of 12 reps each side
- Single-leg deadlifts: 3 sets of 10 reps each leg
- Cool down: 5-minute stretching

**Friday**: Final Challenge Circuit
- Burpees: 45 seconds
- Russian twists: 45 seconds
- Lateral lunges: 45 seconds
- Plank: 45 seconds
- Rest: 15 seconds
- Repeat circuit 4 times
- Cool down: 5-minute stretching

## Additional Notes:
- Stay hydrated throughout your workouts
- Focus on proper form rather than speed
- If exercises feel too difficult, modify as needed
- Rest at least one day between strength training sessions
- Add 5-10 minutes of cardio warm-up before each session
`;

export default function AiWorkoutPlanner() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [goal, setGoal] = useState('');
  const [fitnessLevel, setFitnessLevel] = useState('');
  const [preferences, setPreferences] = useState('');
  const [workoutPlan, setWorkoutPlan] = useState('');
  
  // Check if user has access to AI planning feature
  const hasAccess = hasFeatureAccess(user, 'aiPlanning');
  
  const handleGenerateWorkout = () => {
    if (!hasAccess) return;
    
    setIsGenerating(true);
    
    // In a real app, this would call an API to generate a workout plan
    // For the demo, we'll simulate an API call with a timeout
    setTimeout(() => {
      setWorkoutPlan(sampleWorkoutPlan);
      setIsGenerating(false);
      
      toast({
        title: 'Workout Plan Generated',
        description: 'Your personalized AI workout plan is ready!',
      });
    }, 2500);
  };
  
  const handleSavePlan = () => {
    toast({
      title: 'Workout Plan Saved',
      description: 'Your workout plan has been saved to your calendar',
    });
    setIsDialogOpen(false);
  };
  
  // The actual AI Workout Planner UI
  const WorkoutPlanner = () => (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <BrainCircuit className="h-4 w-4" />
          AI Workout Planner
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BrainCircuit className="h-5 w-5" /> AI Workout Planner
          </DialogTitle>
          <DialogDescription>
            Generate a personalized workout plan based on your goals and preferences.
          </DialogDescription>
        </DialogHeader>
        
        {!workoutPlan ? (
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="goal">Fitness Goal</Label>
                <Select value={goal} onValueChange={setGoal}>
                  <SelectTrigger id="goal">
                    <SelectValue placeholder="Select a goal" />
                  </SelectTrigger>
                  <SelectContent>
                    {fitnessGoals.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="level">Fitness Level</Label>
                <Select value={fitnessLevel} onValueChange={setFitnessLevel}>
                  <SelectTrigger id="level">
                    <SelectValue placeholder="Select your level" />
                  </SelectTrigger>
                  <SelectContent>
                    {fitnessLevels.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="preferences">Additional Preferences</Label>
              <Textarea
                id="preferences"
                placeholder="Enter any specific requirements, time constraints, or equipment you have available..."
                value={preferences}
                onChange={(e) => setPreferences(e.target.value)}
                rows={4}
              />
            </div>
            
            <Button 
              onClick={handleGenerateWorkout} 
              className="w-full"
              disabled={isGenerating || !goal || !fitnessLevel}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating AI Workout Plan...
                </>
              ) : (
                <>
                  <BrainCircuit className="mr-2 h-4 w-4" />
                  Generate Workout Plan
                </>
              )}
            </Button>
          </div>
        ) : (
          <div className="space-y-4 py-4">
            <div className="bg-secondary/50 rounded-lg p-4">
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <div dangerouslySetInnerHTML={{ __html: workoutPlan.replace(/\n/g, '<br>') }} />
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2 justify-end">
              <Button
                variant="outline"
                onClick={() => {
                  setWorkoutPlan('');
                  setGoal('');
                  setFitnessLevel('');
                  setPreferences('');
                }}
              >
                Create New Plan
              </Button>
              
              <Button 
                variant="default"
                onClick={handleSavePlan}
                className="gap-2"
              >
                <Calendar className="h-4 w-4" />
                Save to My Workouts
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
  
  // Display the feature or the premium upgrade prompt
  return (
    <SubscriptionFeature 
      featureKey="aiPlanning" 
      requiredTier="pro"
    >
      <WorkoutPlanner />
    </SubscriptionFeature>
  );
}