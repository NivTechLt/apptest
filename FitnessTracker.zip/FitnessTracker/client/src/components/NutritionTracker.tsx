import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Apple, Coffee, Egg, Pizza, Utensils } from 'lucide-react';

// Demo food database for the nutrition tracker prototype
const foodDatabase = [
  { id: 1, name: 'Apple', category: 'Fruit', calories: 95, protein: 0.5, carbs: 25, fat: 0.3 },
  { id: 2, name: 'Banana', category: 'Fruit', calories: 105, protein: 1.3, carbs: 27, fat: 0.4 },
  { id: 3, name: 'Chicken Breast', category: 'Protein', calories: 165, protein: 31, carbs: 0, fat: 3.6 },
  { id: 4, name: 'Brown Rice', category: 'Grain', calories: 216, protein: 5, carbs: 45, fat: 1.8 },
  { id: 5, name: 'Spinach', category: 'Vegetable', calories: 23, protein: 2.9, carbs: 3.6, fat: 0.4 },
  { id: 6, name: 'Egg', category: 'Protein', calories: 78, protein: 6.3, carbs: 0.6, fat: 5.3 },
  { id: 7, name: 'Salmon', category: 'Protein', calories: 206, protein: 22, carbs: 0, fat: 13 },
  { id: 8, name: 'Avocado', category: 'Fruit', calories: 240, protein: 3, carbs: 12, fat: 22 },
  { id: 9, name: 'Greek Yogurt', category: 'Dairy', calories: 100, protein: 17, carbs: 6, fat: 0.4 },
  { id: 10, name: 'Oatmeal', category: 'Grain', calories: 150, protein: 5, carbs: 27, fat: 3 },
];

interface FoodEntry {
  id: number;
  foodId: number;
  name: string;
  servingSize: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  date: Date;
}

export default function NutritionTracker() {
  const [activeTab, setActiveTab] = useState('log');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFood, setSelectedFood] = useState<number | null>(null);
  const [servingSize, setServingSize] = useState(1);
  const [mealType, setMealType] = useState<'breakfast' | 'lunch' | 'dinner' | 'snack'>('breakfast');
  const [foodLog, setFoodLog] = useState<FoodEntry[]>([]);
  
  const filteredFoods = foodDatabase.filter(food => 
    food.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleAddFood = () => {
    if (selectedFood === null) return;
    
    const food = foodDatabase.find(f => f.id === selectedFood);
    if (!food) return;
    
    const newEntry: FoodEntry = {
      id: Date.now(),
      foodId: food.id,
      name: food.name,
      servingSize,
      calories: food.calories * servingSize,
      protein: food.protein * servingSize,
      carbs: food.carbs * servingSize,
      fat: food.fat * servingSize,
      mealType,
      date: new Date()
    };
    
    setFoodLog([...foodLog, newEntry]);
    setSelectedFood(null);
    setServingSize(1);
  };
  
  const handleRemoveFood = (id: number) => {
    setFoodLog(foodLog.filter(entry => entry.id !== id));
  };
  
  const totalNutrition = foodLog.reduce((acc, entry) => {
    return {
      calories: acc.calories + entry.calories,
      protein: acc.protein + entry.protein,
      carbs: acc.carbs + entry.carbs,
      fat: acc.fat + entry.fat
    };
  }, { calories: 0, protein: 0, carbs: 0, fat: 0 });
  
  const getMealTypeIcon = (type: string) => {
    switch(type) {
      case 'breakfast': return <Coffee className="h-4 w-4" />;
      case 'lunch': return <Utensils className="h-4 w-4" />;
      case 'dinner': return <Pizza className="h-4 w-4" />;
      case 'snack': return <Apple className="h-4 w-4" />;
      default: return <Egg className="h-4 w-4" />;
    }
  };
  
  return (
    <div className="w-full">
      <Tabs defaultValue="log" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="log">Food Log</TabsTrigger>
          <TabsTrigger value="add">Add Food</TabsTrigger>
          <TabsTrigger value="summary">Summary</TabsTrigger>
        </TabsList>
        
        {/* Food Log Tab */}
        <TabsContent value="log">
          <Card>
            <CardHeader>
              <CardTitle>Today's Food Entries</CardTitle>
              <CardDescription>
                Track your daily nutrition intake
              </CardDescription>
            </CardHeader>
            <CardContent>
              {foodLog.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  No foods logged yet. Add some foods to track your nutrition.
                </div>
              ) : (
                <div className="space-y-3">
                  {foodLog.map(entry => (
                    <div key={entry.id} className="flex justify-between items-center border-b pb-2">
                      <div className="flex items-center gap-2">
                        <div className="bg-primary/10 rounded-full p-1">
                          {getMealTypeIcon(entry.mealType)}
                        </div>
                        <div>
                          <p className="font-medium">{entry.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {entry.servingSize} serving(s) • {entry.mealType}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="font-medium">{entry.calories} cal</p>
                          <p className="text-xs text-muted-foreground">
                            P: {entry.protein}g • C: {entry.carbs}g • F: {entry.fat}g
                          </p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => handleRemoveFood(entry.id)}
                          className="text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950"
                        >
                          X
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-4">
              <div>
                <p className="text-sm font-medium">Daily Totals</p>
              </div>
              <div className="text-right">
                <p className="font-bold">{totalNutrition.calories} calories</p>
                <p className="text-sm text-muted-foreground">
                  P: {totalNutrition.protein.toFixed(1)}g • C: {totalNutrition.carbs.toFixed(1)}g • F: {totalNutrition.fat.toFixed(1)}g
                </p>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Add Food Tab */}
        <TabsContent value="add">
          <Card>
            <CardHeader>
              <CardTitle>Add Food</CardTitle>
              <CardDescription>
                Search for foods to add to your log
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="search">Search Foods</Label>
                <Input 
                  id="search" 
                  placeholder="E.g., apple, chicken, rice..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              {filteredFoods.length > 0 && (
                <div className="border rounded-md">
                  <div className="max-h-[200px] overflow-y-auto">
                    {filteredFoods.map(food => (
                      <div 
                        key={food.id} 
                        className={`flex justify-between p-3 cursor-pointer border-b last:border-b-0 ${
                          selectedFood === food.id ? 'bg-primary/10' : 'hover:bg-muted'
                        }`}
                        onClick={() => setSelectedFood(food.id)}
                      >
                        <div>
                          <p className="font-medium">{food.name}</p>
                          <p className="text-xs text-muted-foreground">{food.category}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{food.calories} cal</p>
                          <p className="text-xs text-muted-foreground">
                            P: {food.protein}g • C: {food.carbs}g • F: {food.fat}g
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {selectedFood !== null && (
                <div className="space-y-4 border-t pt-4 mt-4">
                  <div className="space-y-2">
                    <Label htmlFor="serving">Serving Size</Label>
                    <Input 
                      id="serving" 
                      type="number" 
                      min="0.25" 
                      step="0.25" 
                      value={servingSize}
                      onChange={(e) => setServingSize(parseFloat(e.target.value))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="meal-type">Meal Type</Label>
                    <Select value={mealType} onValueChange={(value) => setMealType(value as any)}>
                      <SelectTrigger id="meal-type">
                        <SelectValue placeholder="Select meal type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="breakfast">Breakfast</SelectItem>
                        <SelectItem value="lunch">Lunch</SelectItem>
                        <SelectItem value="dinner">Dinner</SelectItem>
                        <SelectItem value="snack">Snack</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full" 
                disabled={selectedFood === null}
                onClick={handleAddFood}
              >
                Add to Food Log
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Summary Tab */}
        <TabsContent value="summary">
          <Card>
            <CardHeader>
              <CardTitle>Nutrition Summary</CardTitle>
              <CardDescription>
                View your nutritional intake breakdown
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-primary/10 rounded-lg p-4 text-center">
                    <p className="text-sm text-muted-foreground">Total Calories</p>
                    <p className="text-2xl font-bold">{totalNutrition.calories}</p>
                  </div>
                  <div className="bg-blue-100 dark:bg-blue-900/30 rounded-lg p-4 text-center">
                    <p className="text-sm text-muted-foreground">Protein</p>
                    <p className="text-xl font-bold">{totalNutrition.protein.toFixed(1)}g</p>
                  </div>
                  <div className="bg-amber-100 dark:bg-amber-900/30 rounded-lg p-4 text-center">
                    <p className="text-sm text-muted-foreground">Carbs</p>
                    <p className="text-xl font-bold">{totalNutrition.carbs.toFixed(1)}g</p>
                  </div>
                  <div className="bg-red-100 dark:bg-red-900/30 rounded-lg p-4 text-center">
                    <p className="text-sm text-muted-foreground">Fat</p>
                    <p className="text-xl font-bold">{totalNutrition.fat.toFixed(1)}g</p>
                  </div>
                </div>
                
                {foodLog.length > 0 && (
                  <div className="mt-6">
                    <h3 className="text-lg font-medium mb-2">Macronutrient Breakdown</h3>
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                      {totalNutrition.calories > 0 && (
                        <>
                          <div 
                            className="h-full bg-blue-500 float-left"
                            style={{ 
                              width: `${(totalNutrition.protein * 4 / totalNutrition.calories) * 100}%` 
                            }}
                          />
                          <div 
                            className="h-full bg-amber-500 float-left"
                            style={{ 
                              width: `${(totalNutrition.carbs * 4 / totalNutrition.calories) * 100}%` 
                            }}
                          />
                          <div 
                            className="h-full bg-red-500 float-left"
                            style={{ 
                              width: `${(totalNutrition.fat * 9 / totalNutrition.calories) * 100}%` 
                            }}
                          />
                        </>
                      )}
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>Protein ({Math.round((totalNutrition.protein * 4 / Math.max(totalNutrition.calories, 1)) * 100)}%)</span>
                      <span>Carbs ({Math.round((totalNutrition.carbs * 4 / Math.max(totalNutrition.calories, 1)) * 100)}%)</span>
                      <span>Fat ({Math.round((totalNutrition.fat * 9 / Math.max(totalNutrition.calories, 1)) * 100)}%)</span>
                    </div>
                  </div>
                )}
                
                {foodLog.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    Add some foods to see your nutrition summary
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" variant="outline">
                Export Nutrition Data
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}