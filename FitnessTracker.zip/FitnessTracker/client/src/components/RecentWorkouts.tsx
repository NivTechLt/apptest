import { formatDistanceToNow } from "date-fns";
import { Card, CardContent } from "@/components/ui/card";
import { getWorkoutIcon } from "@/lib/constants";
import { Link } from "wouter";
import { Workout } from "@shared/schema";
import { BarChart2, Clock, Dumbbell, ChevronRight, Flame } from "lucide-react";

interface RecentWorkoutsProps {
  workouts: Workout[];
}

export default function RecentWorkouts({ workouts }: RecentWorkoutsProps) {
  return (
    <section className="bg-white dark:bg-gray-900 rounded-xl shadow-md p-5 overflow-hidden relative">
      <div className="absolute top-0 left-0 w-32 h-32 bg-primary/5 dark:bg-primary/10 rounded-full -ml-16 -mt-16 z-0"></div>
      
      <div className="flex items-center justify-between mb-5 relative z-10">
        <div className="flex items-center">
          <Dumbbell className="h-5 w-5 text-primary mr-2" />
          <h2 className="font-bold text-lg dark:text-white">Recent Workouts</h2>
        </div>
        <Link href="/progress">
          <div className="flex items-center text-primary text-sm font-medium cursor-pointer hover:underline">
            View all
            <ChevronRight className="h-4 w-4 ml-1" />
          </div>
        </Link>
      </div>
      
      {workouts.length === 0 ? (
        <div className="text-center py-8 px-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
          <Dumbbell className="h-10 w-10 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
          <p className="text-gray-600 dark:text-gray-300 font-medium mb-2">No workouts recorded yet</p>
          <p className="text-gray-500 dark:text-gray-400 text-sm">Use the plus button to log your first workout</p>
        </div>
      ) : (
        <div className="space-y-4 relative z-10">
          {workouts.map((workout) => (
            <div 
              key={workout.id} 
              className="p-3.5 border border-gray-100 dark:border-gray-700 rounded-lg hover:shadow-sm transition-shadow dark:bg-gray-800"
            >
              <div className="flex justify-between mb-3">
                <div className="flex items-center">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                    {getWorkoutIcon(workout.exerciseType)}
                  </div>
                  <div className="ml-3">
                    <h3 className="font-medium text-gray-900 dark:text-white leading-tight">{workout.exerciseType}</h3>
                    <div className="text-xs font-medium text-gray-500 dark:text-gray-400 mt-0.5">
                      {formatDate(workout.date)}
                    </div>
                  </div>
                </div>
                <div className={`px-2 py-1 rounded-md text-xs font-medium ${
                  workout.intensity === 'high' ? 'bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400' :
                  workout.intensity === 'medium' ? 'bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400' :
                  'bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400'
                }`}>
                  {capitalize(workout.intensity)}
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-2 mt-1">
                <div className="flex items-center bg-gray-50 dark:bg-gray-700/50 p-2 rounded-md">
                  <Clock className="h-4 w-4 text-gray-400 dark:text-gray-500 mr-2" />
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{workout.duration}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">minutes</p>
                  </div>
                </div>
                <div className="flex items-center bg-gray-50 dark:bg-gray-700/50 p-2 rounded-md">
                  <Flame className="h-4 w-4 text-gray-400 dark:text-gray-500 mr-2" />
                  <div>
                    <p className="font-medium text-gray-900 dark:text-white">{(workout.calories || 0).toLocaleString()}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">calories</p>
                  </div>
                </div>
              </div>
              
              {workout.notes && (
                <div className="mt-3 text-sm text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-700/50 p-2 rounded-md">
                  {workout.notes}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function formatDate(dateInput: string | Date): string {
  try {
    const date = dateInput instanceof Date ? dateInput : new Date(dateInput);
    
    // If today, return "Today"
    if (isToday(date)) return "Today";
    
    // If yesterday, return "Yesterday"
    if (isYesterday(date)) return "Yesterday";
    
    // Otherwise format as "Jan 5" or similar
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  } catch (e) {
    return "Invalid date";
  }
}

function isToday(date: Date): boolean {
  const today = new Date();
  return date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear();
}

function isYesterday(date: Date): boolean {
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  return date.getDate() === yesterday.getDate() &&
    date.getMonth() === yesterday.getMonth() &&
    date.getFullYear() === yesterday.getFullYear();
}

function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}
