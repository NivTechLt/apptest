import React, { ReactNode } from "react";
import { 
  Activity, 
  Dumbbell, 
  Bike, 
  GlassWater, 
  Heart,
  Plus,
  Check 
} from "lucide-react";
import { cn } from "@/lib/utils";

interface ExerciseTypeButtonProps {
  icon: string;
  label: string;
  isSelected: boolean;
  onClick: () => void;
}

export default function ExerciseTypeButton({ 
  icon, 
  label, 
  isSelected, 
  onClick 
}: ExerciseTypeButtonProps) {
  const iconType = getIconType(icon);
  
  return (
    <button
      type="button"
      className={cn(
        "relative border rounded-lg py-3 px-4 flex flex-col items-center justify-center focus:outline-none transition-all duration-200 focus:ring-2 focus:ring-primary/20 h-28",
        isSelected 
          ? "border-2 shadow-sm " + getSelectedClasses(iconType) 
          : "border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 dark:text-gray-300"
      )}
      onClick={onClick}
      aria-pressed={isSelected}
    >
      <div className={cn(
        "mb-2 rounded-full p-2.5",
        isSelected 
          ? getIconClasses(iconType) 
          : "text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700"
      )}>
        {getIcon(icon)}
      </div>
      <span className="font-medium">{label}</span>
      
      {isSelected && (
        <div className="absolute top-2 right-2 text-primary dark:text-primary">
          <Check className="w-4 h-4" />
        </div>
      )}
    </button>
  );
}

function getIconType(iconName: string): string {
  switch (iconName) {
    case 'activity':
    case 'directions_run':
      return 'running';
    case 'dumbbell':
    case 'fitness_center':
      return 'weights';
    case 'bike':
    case 'directions_bike':
      return 'biking';
    case 'water':
    case 'pool':
      return 'swimming';
    case 'heart':
    case 'self_improvement':
      return 'yoga';
    case 'plus':
    case 'add':
      return 'other';
    default:
      return 'default';
  }
}

function getSelectedClasses(iconType: string): string {
  switch (iconType) {
    case 'running':
      return 'bg-green-50 dark:bg-green-900/30 border-green-200 dark:border-green-800 text-green-800 dark:text-green-400';
    case 'weights':
      return 'bg-blue-50 dark:bg-blue-900/30 border-blue-200 dark:border-blue-800 text-blue-800 dark:text-blue-400';
    case 'biking':
      return 'bg-indigo-50 dark:bg-indigo-900/30 border-indigo-200 dark:border-indigo-800 text-indigo-800 dark:text-indigo-400';
    case 'swimming':
      return 'bg-cyan-50 dark:bg-cyan-900/30 border-cyan-200 dark:border-cyan-800 text-cyan-800 dark:text-cyan-400';
    case 'yoga':
      return 'bg-red-50 dark:bg-red-900/30 border-red-200 dark:border-red-800 text-red-800 dark:text-red-400';
    case 'other':
      return 'bg-purple-50 dark:bg-purple-900/30 border-purple-200 dark:border-purple-800 text-purple-800 dark:text-purple-400';
    default:
      return 'bg-primary/10 dark:bg-primary/20 border-primary dark:border-primary/50 text-primary dark:text-primary';
  }
}

function getIconClasses(iconType: string): string {
  switch (iconType) {
    case 'running':
      return 'text-green-500 dark:text-green-400 bg-green-100 dark:bg-green-900/50';
    case 'weights':
      return 'text-blue-500 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/50';
    case 'biking':
      return 'text-indigo-500 dark:text-indigo-400 bg-indigo-100 dark:bg-indigo-900/50';
    case 'swimming':
      return 'text-cyan-500 dark:text-cyan-400 bg-cyan-100 dark:bg-cyan-900/50';
    case 'yoga':
      return 'text-red-500 dark:text-red-400 bg-red-100 dark:bg-red-900/50';
    case 'other':
      return 'text-purple-500 dark:text-purple-400 bg-purple-100 dark:bg-purple-900/50';
    default:
      return 'text-primary dark:text-primary bg-primary/10 dark:bg-primary/20';
  }
}

function getIcon(iconName: string): ReactNode {
  switch (iconName) {
    case 'activity':
    case 'directions_run':
      return React.createElement(Activity, { className: "h-5 w-5" });
    case 'dumbbell':
    case 'fitness_center':
      return React.createElement(Dumbbell, { className: "h-5 w-5" });
    case 'bike':
    case 'directions_bike':
      return React.createElement(Bike, { className: "h-5 w-5" });
    case 'water':
    case 'pool':
      return React.createElement(GlassWater, { className: "h-5 w-5" });
    case 'heart':
    case 'self_improvement':
      return React.createElement(Heart, { className: "h-5 w-5" });
    case 'plus':
    case 'add':
      return React.createElement(Plus, { className: "h-5 w-5" });
    default:
      return React.createElement(Activity, { className: "h-5 w-5" });
  }
}
