import { cn } from "@/lib/utils";
import { Flame } from "lucide-react";

interface IntensityButtonGroupProps {
  selectedIntensity: 'low' | 'medium' | 'high';
  onSelect: (intensity: 'low' | 'medium' | 'high') => void;
}

export default function IntensityButtonGroup({ 
  selectedIntensity, 
  onSelect 
}: IntensityButtonGroupProps) {
  return (
    <div className="grid grid-cols-3 gap-3">
      <button
        type="button"
        className={cn(
          "relative py-4 text-sm font-medium rounded-lg focus:outline-none transition-all duration-200 focus:ring-2 focus:ring-primary/20",
          selectedIntensity === 'low' 
            ? "bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 border-2 border-blue-200 dark:border-blue-800 shadow-sm" 
            : "bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-700 dark:text-gray-300"
        )}
        onClick={() => onSelect('low')}
        aria-label="Low intensity"
      >
        <div className="flex flex-col items-center">
          <div className="mb-1 text-blue-500 dark:text-blue-400">
            <Flame className="h-5 w-5" />
          </div>
          <span>Low</span>
        </div>
        {selectedIntensity === 'low' && (
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-blue-500 dark:bg-blue-400 rounded-full"></span>
        )}
      </button>
      
      <button
        type="button"
        className={cn(
          "relative py-4 text-sm font-medium rounded-lg focus:outline-none transition-all duration-200 focus:ring-2 focus:ring-primary/20",
          selectedIntensity === 'medium' 
            ? "bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-400 border-2 border-green-200 dark:border-green-800 shadow-sm" 
            : "bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-700 dark:text-gray-300"
        )}
        onClick={() => onSelect('medium')}
        aria-label="Medium intensity"
      >
        <div className="flex flex-col items-center">
          <div className="mb-1 text-green-500 dark:text-green-400">
            <div className="flex">
              <Flame className="h-5 w-5" />
              <Flame className="h-5 w-5 -ml-1" />
            </div>
          </div>
          <span>Medium</span>
        </div>
        {selectedIntensity === 'medium' && (
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-green-500 dark:bg-green-400 rounded-full"></span>
        )}
      </button>
      
      <button
        type="button"
        className={cn(
          "relative py-4 text-sm font-medium rounded-lg focus:outline-none transition-all duration-200 focus:ring-2 focus:ring-primary/20",
          selectedIntensity === 'high' 
            ? "bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-400 border-2 border-red-200 dark:border-red-800 shadow-sm" 
            : "bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-700 dark:text-gray-300"
        )}
        onClick={() => onSelect('high')}
        aria-label="High intensity"
      >
        <div className="flex flex-col items-center">
          <div className="mb-1 text-red-500 dark:text-red-400">
            <div className="flex">
              <Flame className="h-5 w-5" />
              <Flame className="h-5 w-5 -ml-1" />
              <Flame className="h-5 w-5 -ml-1" />
            </div>
          </div>
          <span>High</span>
        </div>
        {selectedIntensity === 'high' && (
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 dark:bg-red-400 rounded-full"></span>
        )}
      </button>
    </div>
  );
}
