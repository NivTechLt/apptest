import React, { useEffect, useRef } from 'react';

type Node = {
  x: number;
  y: number;
  z: number;
  size: number;
};

export default function NiaLogo({ width = 100, height = 100 }: { width?: number; height?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Ensure the canvas is properly sized for high DPI displays
    const devicePixelRatio = window.devicePixelRatio || 1;
    canvas.width = width * devicePixelRatio;
    canvas.height = height * devicePixelRatio;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.scale(devicePixelRatio, devicePixelRatio);

    // Network configuration
    const nodes: Node[] = [];
    const nodeCount = 15;
    const maxSize = 5;
    const minSize = 2;
    const radius = Math.min(width, height) / 2.5;
    const connectionDistance = radius * 0.7;
    const rotationSpeed = 0.0005;
    let rotation = 0;

    // Create network nodes in a sphere-like arrangement
    for (let i = 0; i < nodeCount; i++) {
      // Create points on a sphere
      const phi = Math.acos(-1 + (2 * i) / nodeCount);
      const theta = Math.sqrt(nodeCount * Math.PI) * phi;

      // Convert to Cartesian coordinates
      const x = radius * Math.cos(theta) * Math.sin(phi) + width / 2;
      const y = radius * Math.sin(theta) * Math.sin(phi) + height / 2;
      const z = radius * Math.cos(phi);

      nodes.push({
        x,
        y,
        z,
        size: Math.random() * (maxSize - minSize) + minSize,
      });
    }

    // Animation function
    function animate() {
      ctx.clearRect(0, 0, width, height);

      // Update rotation
      rotation += rotationSpeed;

      // Update node positions based on rotation
      nodes.forEach((node) => {
        const cos = Math.cos(rotation);
        const sin = Math.sin(rotation);

        // Rotate around Y axis
        const x = node.x - width / 2;
        const z = node.z;
        node.x = x * cos - z * sin + width / 2;
        node.z = z * cos + x * sin;
      });

      // Sort nodes by Z position for proper layering
      const sortedNodes = [...nodes].sort((a, b) => b.z - a.z);

      // Draw connections
      ctx.strokeStyle = '#666';
      ctx.lineWidth = 0.5;

      for (let i = 0; i < sortedNodes.length; i++) {
        for (let j = i + 1; j < sortedNodes.length; j++) {
          const node1 = sortedNodes[i];
          const node2 = sortedNodes[j];

          const dx = node1.x - node2.x;
          const dy = node1.y - node2.y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < connectionDistance) {
            const alpha = 1 - distance / connectionDistance;
            ctx.globalAlpha = alpha * 0.5;
            ctx.beginPath();
            ctx.moveTo(node1.x, node1.y);
            ctx.lineTo(node2.x, node2.y);
            ctx.stroke();
          }
        }
      }

      // Draw nodes
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#00ff00';

      sortedNodes.forEach((node) => {
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.size * (node.z + radius) / (2 * radius), 0, Math.PI * 2);
        ctx.fill();
      });

      requestAnimationFrame(animate);
    }

    animate();
  }, [width, height]);

  return <canvas ref={canvasRef} style={{ width, height }} />;
}