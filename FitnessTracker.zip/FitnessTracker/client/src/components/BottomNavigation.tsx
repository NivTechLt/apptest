import { Home, BarChart2, Flag, Settings, Plus, Crown, Trophy, Weight } from "lucide-react";
import { useLocation, useRoute, Link } from "wouter";

interface BottomNavigationProps {
  onAddWorkout: () => void;
}

export default function BottomNavigation({ onAddWorkout }: BottomNavigationProps) {
  const [location] = useLocation();
  
  const [isHomePage] = useRoute("/");
  const [isProgressPage] = useRoute("/progress");
  const [isGoalsPage] = useRoute("/goals");
  const [isSettingsPage] = useRoute("/settings");
  const [isPremiumPage] = useRoute("/premium");
  const [isChallengesPage] = useRoute("/challenges");
  const [isMeasurementsPage] = useRoute("/measurements");
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 w-full bg-white dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800 z-10 shadow-[0_-4px_10px_rgba(0,0,0,0.03)] dark:shadow-[0_-4px_10px_rgba(0,0,0,0.2)]">
      <div className="grid grid-cols-6 h-16">
        <Link href="/" className="flex-1 h-full">
          <div className={`flex flex-col items-center justify-center h-full
            ${isHomePage 
              ? "text-primary font-medium" 
              : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"} 
            cursor-pointer transition-colors`}>
            <Home className={`h-5 w-5 ${isHomePage ? "text-primary" : ""}`} />
            <span className="text-xs mt-1">Home</span>
          </div>
        </Link>
        
        <Link href="/progress" className="flex-1 h-full">
          <div className={`flex flex-col items-center justify-center h-full
            ${isProgressPage 
              ? "text-primary font-medium" 
              : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"} 
            cursor-pointer transition-colors`}>
            <BarChart2 className={`h-5 w-5 ${isProgressPage ? "text-primary" : ""}`} />
            <span className="text-xs mt-1">Progress</span>
          </div>
        </Link>
        
        <div className="flex flex-col items-center justify-center h-full relative">
          <button 
            className="absolute -top-6 bg-primary text-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg transition-transform hover:scale-105 active:scale-95"
            onClick={onAddWorkout}
            aria-label="Add workout"
          >
            <Plus className="h-6 w-6" />
          </button>
          <span className="text-xs mt-8 text-primary font-medium">Add</span>
        </div>
        
        <Link href="/goals" className="flex-1 h-full">
          <div className={`flex flex-col items-center justify-center h-full
            ${isGoalsPage 
              ? "text-primary font-medium" 
              : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"} 
            cursor-pointer transition-colors`}>
            <Flag className={`h-5 w-5 ${isGoalsPage ? "text-primary" : ""}`} />
            <span className="text-xs mt-1">Goals</span>
          </div>
        </Link>
        
        <Link href="/challenges" className="flex-1 h-full">
          <div className={`flex flex-col items-center justify-center h-full
            ${isChallengesPage 
              ? "text-primary font-medium" 
              : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"} 
            cursor-pointer transition-colors`}>
            <Trophy className={`h-5 w-5 ${isChallengesPage ? "text-primary" : ""}`} />
            <span className="text-xs mt-1">Challenges</span>
          </div>
        </Link>
        
        <Link href="/measurements" className="flex-1 h-full">
          <div className={`flex flex-col items-center justify-center h-full
            ${isMeasurementsPage 
              ? "text-primary font-medium" 
              : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"} 
            cursor-pointer transition-colors`}>
            <Weight className={`h-5 w-5 ${isMeasurementsPage ? "text-primary" : ""}`} />
            <span className="text-xs mt-1">Weight</span>
          </div>
        </Link>
      </div>
      
      {/* Floating Buttons */}
      <div className="fixed right-4 bottom-20 flex flex-col gap-3">
        {/* Premium Button */}
        <Link href="/premium">
          <button 
            className={`bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 text-gray-700 dark:text-gray-300 rounded-full w-10 h-10 flex items-center justify-center shadow-md transition-transform hover:scale-105 ${isPremiumPage ? "bg-primary/10 border-primary/20 text-primary" : ""}`}
            aria-label="Premium Features"
          >
            <Crown className={`h-5 w-5 ${isPremiumPage ? "text-primary" : ""}`} />
          </button>
        </Link>
        
        {/* Settings Button */}
        <Link href="/settings">
          <button 
            className={`bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 text-gray-700 dark:text-gray-300 rounded-full w-10 h-10 flex items-center justify-center shadow-md transition-transform hover:scale-105 ${isSettingsPage ? "bg-primary/10 border-primary/20 text-primary" : ""}`}
            aria-label="Settings"
          >
            <Settings className={`h-5 w-5 ${isSettingsPage ? "text-primary" : ""}`} />
          </button>
        </Link>
      </div>
    </nav>
  );
}
