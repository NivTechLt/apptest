import { ReactNode } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { hasFeatureAccess } from '@/lib/subscription-utils';
import { Button } from '@/components/ui/button';
import { Lock, Star } from 'lucide-react';
import { useLocation } from 'wouter';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

import { FEATURE_ACCESS_MAP } from '@/lib/subscription-utils';

interface SubscriptionFeatureProps {
  featureKey: keyof typeof FEATURE_ACCESS_MAP;
  children: ReactNode;
  fallback?: ReactNode;
  showUpgradeButton?: boolean;
  requiredTier?: 'basic' | 'premium' | 'pro';
}

export default function SubscriptionFeature({
  featureKey,
  children,
  fallback,
  showUpgradeButton = true,
  requiredTier = 'premium'
}: SubscriptionFeatureProps) {
  const { user } = useAuth();
  const [_, setLocation] = useLocation();
  
  // Check if user has access to this feature
  const hasAccess = hasFeatureAccess(user, featureKey);
  
  if (hasAccess) {
    return <>{children}</>;
  }
  
  // Determine which tier label to show
  const tierLabel = requiredTier.charAt(0).toUpperCase() + requiredTier.slice(1);
  
  // If fallback is provided, use it. Otherwise show a premium content message
  return (
    <div className="relative">
      {fallback ? (
        <>{fallback}</>
      ) : (
        <div className="p-4 bg-secondary/50 rounded-lg border border-border flex flex-col items-center justify-center text-center gap-2 min-h-[100px]">
          <div className="flex items-center gap-1 text-muted-foreground mb-1">
            <Lock className="h-4 w-4" />
            <span className="text-sm font-medium">{tierLabel} Feature</span>
          </div>
          <p className="text-sm text-muted-foreground mb-2">
            Upgrade your subscription to access this feature
          </p>
          {showUpgradeButton && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button 
                    size="sm"
                    variant="outline"
                    className="gap-1"
                    onClick={() => setLocation('/subscription')}
                  >
                    <Star className="h-3.5 w-3.5" />
                    <span>Upgrade to {tierLabel}</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Get access to all {tierLabel} features</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}
        </div>
      )}
    </div>
  );
}