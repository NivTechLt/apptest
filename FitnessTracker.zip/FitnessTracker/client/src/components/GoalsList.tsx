import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Goal } from "@shared/schema";
import { Target, ChevronRight, Award } from "lucide-react";

interface GoalsListProps {
  goals: Goal[];
}

export default function GoalsList({ goals }: GoalsListProps) {
  const { toast } = useToast();
  
  return (
    <section className="bg-white dark:bg-gray-900 rounded-xl shadow-md p-5 overflow-hidden relative">
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-primary/5 dark:bg-primary/10 rounded-full -ml-12 -mb-12 z-0"></div>
      
      <div className="flex items-center justify-between mb-4 relative z-10">
        <div className="flex items-center">
          <Target className="h-5 w-5 text-primary mr-2" />
          <h2 className="font-bold text-lg dark:text-white">Goals</h2>
        </div>
        <Link href="/goals">
          <div className="flex items-center text-primary text-sm font-medium cursor-pointer hover:underline">
            View all
            <ChevronRight className="h-4 w-4 ml-1" />
          </div>
        </Link>
      </div>
      
      {goals.length === 0 ? (
        <div className="text-center py-8 px-4 bg-gray-50 dark:bg-gray-800 rounded-lg relative z-10">
          <Target className="h-10 w-10 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
          <p className="text-gray-600 dark:text-gray-300 font-medium mb-3">No goals set yet</p>
          <p className="text-gray-500 dark:text-gray-400 text-sm mb-4">Setting goals helps you stay motivated and track your progress</p>
          <Link href="/goals">
            <div className="inline-block">
              <Button className="mt-1 font-medium" size="sm">
                Set your first goal
              </Button>
            </div>
          </Link>
        </div>
      ) : (
        <div className="space-y-4 relative z-10">
          {goals.map(goal => {
            const progress = Math.min(100, (goal.currentValue / goal.targetValue) * 100);
            const isCompleted = goal.isCompleted;
            
            return (
              <div key={goal.id} className="p-3 border border-gray-100 dark:border-gray-700 rounded-lg hover:shadow-sm transition-shadow dark:bg-gray-800">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-start space-x-2">
                    {isCompleted && (
                      <div className="bg-green-100 dark:bg-green-900/30 p-1 rounded">
                        <Award className="h-4 w-4 text-green-600 dark:text-green-400" />
                      </div>
                    )}
                    <div>
                      <span className="font-medium text-gray-900 dark:text-white">{goal.name}</span>
                      <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                        {goal.type === 'workout_count' ? 'Workouts' : 
                        goal.type === 'distance' ? 'Miles' : 'Minutes'} per {goal.periodicity}
                      </div>
                    </div>
                  </div>
                  <span className="text-sm font-bold text-gray-700 dark:text-gray-200 bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded">
                    {goal.currentValue}/{goal.targetValue}
                  </span>
                </div>
                
                <div className="mt-2 relative pt-1">
                  <div className="flex items-center justify-between mb-1">
                    <div className="text-xs font-semibold text-gray-500 dark:text-gray-400">{Math.round(progress)}% Complete</div>
                  </div>
                  <div className="h-2 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${
                        isCompleted ? 'bg-green-500' : 
                        (progress >= 60) ? 'bg-primary' : 'bg-amber-500'
                      }`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </section>
  );
}
