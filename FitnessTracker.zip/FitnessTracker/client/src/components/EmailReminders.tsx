import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { BellRing, Clock, Calendar, CheckCircle2, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ReminderSetting {
  id: string;
  type: string;
  enabled: boolean;
  time?: string;
  days?: string[];
  frequency?: string;
}

export default function EmailReminders() {
  const { toast } = useToast();
  const [reminderSettings, setReminderSettings] = useState<ReminderSetting[]>([
    { 
      id: 'workout', 
      type: 'Workout Reminders', 
      enabled: false,
      time: '08:00',
      days: ['monday', 'wednesday', 'friday']
    },
    { 
      id: 'goals', 
      type: 'Goal Progress Updates', 
      enabled: false,
      frequency: 'weekly'
    },
    { 
      id: 'inactivity', 
      type: 'Inactivity Alerts', 
      enabled: false,
      frequency: 'after3days'
    },
    { 
      id: 'motivation', 
      type: 'Motivational Messages', 
      enabled: false,
      frequency: 'daily'
    }
  ]);
  
  const [emailConfirmed, setEmailConfirmed] = useState(false);
  const [email, setEmail] = useState('');
  
  const handleToggle = (id: string) => {
    setReminderSettings(settings => 
      settings.map(setting => 
        setting.id === id ? { ...setting, enabled: !setting.enabled } : setting
      )
    );
  };
  
  const handleDayToggle = (id: string, day: string) => {
    setReminderSettings(settings => 
      settings.map(setting => {
        if (setting.id === id) {
          const days = setting.days || [];
          const updatedDays = days.includes(day) 
            ? days.filter(d => d !== day)
            : [...days, day];
          return { ...setting, days: updatedDays };
        }
        return setting;
      })
    );
  };
  
  const handleTimeChange = (id: string, time: string) => {
    setReminderSettings(settings => 
      settings.map(setting => 
        setting.id === id ? { ...setting, time } : setting
      )
    );
  };
  
  const handleFrequencyChange = (id: string, frequency: string) => {
    setReminderSettings(settings => 
      settings.map(setting => 
        setting.id === id ? { ...setting, frequency } : setting
      )
    );
  };
  
  const handleSaveSettings = () => {
    if (!emailConfirmed) {
      toast({
        title: "Please confirm your email first",
        description: "You need to add and verify your email address to receive reminders.",
        variant: "destructive"
      });
      return;
    }
    
    // In a real app, this would send the settings to the server
    toast({
      title: "Reminder settings saved!",
      description: "Your email reminder preferences have been updated.",
    });
  };
  
  const handleEmailConfirm = () => {
    if (!email || !email.includes('@')) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address.",
        variant: "destructive"
      });
      return;
    }
    
    // In a real app, this would send a confirmation email
    setEmailConfirmed(true);
    toast({
      title: "Email confirmed!",
      description: "Verification email has been sent to your inbox.",
    });
  };
  
  const dayLabels: Record<string, string> = {
    'monday': 'Mon',
    'tuesday': 'Tue',
    'wednesday': 'Wed',
    'thursday': 'Thu',
    'friday': 'Fri',
    'saturday': 'Sat',
    'sunday': 'Sun'
  };
  
  const frequencyLabels: Record<string, string> = {
    'daily': 'Daily',
    'weekly': 'Weekly',
    'monthly': 'Monthly',
    'after3days': 'After 3 Days Inactivity'
  };
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BellRing className="h-5 w-5 text-primary" />
            Email Reminder Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Email Verification */}
          <div className="border rounded-lg p-4 bg-muted/20">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                {emailConfirmed ? (
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                ) : (
                  <AlertCircle className="h-5 w-5 text-amber-500" />
                )}
                <h3 className="font-medium">Email Address for Reminders</h3>
              </div>
              <Badge variant={emailConfirmed ? "success" : "outline"}>
                {emailConfirmed ? "Verified" : "Unverified"}
              </Badge>
            </div>
            
            <div className="flex gap-2">
              <Input 
                placeholder="Enter your email" 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={emailConfirmed}
              />
              <Button 
                variant={emailConfirmed ? "outline" : "default"} 
                onClick={handleEmailConfirm}
                disabled={emailConfirmed}
              >
                {emailConfirmed ? "Verified" : "Verify Email"}
              </Button>
            </div>
          </div>
          
          {/* Reminder Types */}
          <div className="space-y-4">
            {reminderSettings.map(setting => (
              <div key={setting.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Switch 
                      checked={setting.enabled} 
                      onCheckedChange={() => handleToggle(setting.id)}
                      disabled={!emailConfirmed}
                    />
                    <Label htmlFor={setting.id} className="font-medium">
                      {setting.type}
                    </Label>
                  </div>
                </div>
                
                {setting.enabled && (
                  <div className="pl-10 space-y-3">
                    {/* Time selection for workout reminders */}
                    {setting.id === 'workout' && (
                      <>
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <Label>Reminder Time</Label>
                          </div>
                          <Input 
                            type="time" 
                            value={setting.time} 
                            onChange={(e) => handleTimeChange(setting.id, e.target.value)}
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <Label>Reminder Days</Label>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {Object.entries(dayLabels).map(([day, label]) => (
                              <Button
                                key={day}
                                variant={setting.days?.includes(day) ? "default" : "outline"}
                                size="sm"
                                onClick={() => handleDayToggle(setting.id, day)}
                                className="min-w-[3rem]"
                              >
                                {label}
                              </Button>
                            ))}
                          </div>
                        </div>
                      </>
                    )}
                    
                    {/* Frequency selection for other reminder types */}
                    {setting.id !== 'workout' && (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <Label>Frequency</Label>
                        </div>
                        <Select 
                          value={setting.frequency} 
                          onValueChange={(value) => handleFrequencyChange(setting.id, value)}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select frequency" />
                          </SelectTrigger>
                          <SelectContent>
                            {setting.id === 'inactivity' ? (
                              <SelectItem value="after3days">After 3 Days Inactivity</SelectItem>
                            ) : (
                              <>
                                <SelectItem value="daily">Daily</SelectItem>
                                <SelectItem value="weekly">Weekly</SelectItem>
                                <SelectItem value="monthly">Monthly</SelectItem>
                              </>
                            )}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            className="w-full" 
            onClick={handleSaveSettings}
            disabled={!emailConfirmed}
          >
            Save Reminder Settings
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

// Custom Badge component for email verification status
function Badge({ 
  children, 
  variant = "outline" 
}: { 
  children: React.ReactNode; 
  variant?: "outline" | "success" 
}) {
  return (
    <span 
      className={`
        inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium
        ${variant === "success" 
          ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" 
          : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
        }
      `}
    >
      {children}
    </span>
  );
}