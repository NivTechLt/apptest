import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Trash2 } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { insertGoalSchema, Goal } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import GoalsList from "@/components/GoalsList";

const DEFAULT_USER_ID = 1;

// Extended schema with validation
const goalFormSchema = insertGoalSchema.extend({
  name: z.string().min(3, "Goal name must be at least 3 characters"),
  targetValue: z.number().min(1, "Target value must be at least 1"),
});

type GoalFormValues = z.infer<typeof goalFormSchema>;

export default function Goals() {
  const { toast } = useToast();
  const [userId] = useState(DEFAULT_USER_ID);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  // Fetch goals
  const { 
    data: goals, 
    isLoading,
    error,
  } = useQuery<Goal[]>({
    queryKey: ['/api/goals/user', userId],
    queryFn: async () => {
      const response = await fetch(`/api/goals/user/${userId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch goals');
      }
      return response.json() as Promise<Goal[]>;
    },
  });
  
  // Create goal mutation
  const createGoalMutation = useMutation<unknown, Error, GoalFormValues>({
    mutationFn: (newGoal: GoalFormValues) => {
      return apiRequest('POST', '/api/goals', newGoal);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/goals/user', userId] });
      toast({
        title: "Goal created",
        description: "Your new goal has been created successfully.",
      });
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to create goal",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Delete goal mutation
  const deleteGoalMutation = useMutation<unknown, Error, number>({
    mutationFn: (goalId: number) => {
      return apiRequest('DELETE', `/api/goals/${goalId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/goals/user', userId] });
      toast({
        title: "Goal deleted",
        description: "The goal has been deleted successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete goal",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Form setup
  const form = useForm<GoalFormValues>({
    resolver: zodResolver(goalFormSchema),
    defaultValues: {
      userId,
      name: "",
      targetValue: 1,
      type: "workout_count",
      periodicity: "weekly",
    },
  });
  
  const onSubmit = (values: GoalFormValues) => {
    createGoalMutation.mutate(values);
  };
  
  const handleDeleteGoal = (goalId: number) => {
    if (confirm("Are you sure you want to delete this goal?")) {
      deleteGoalMutation.mutate(goalId);
    }
  };

  return (
    <main className="flex-1 px-4 pt-4 pb-20">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Your Goals</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" /> New Goal
            </Button>
          </DialogTrigger>
          <DialogContent aria-describedby="goal-form-description">
            <DialogHeader>
              <DialogTitle>Create a new goal</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4" id="goal-form-description">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Goal Name</FormLabel>
                      <FormControl>
                        <Input placeholder="E.g., Run 3 times a week" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Goal Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a goal type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="workout_count">Workout Count</SelectItem>
                          <SelectItem value="distance">Distance (miles)</SelectItem>
                          <SelectItem value="duration">Duration (minutes)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="targetValue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Value</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min={1}
                          {...field}
                          onChange={e => field.onChange(Number(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="periodicity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Time Period</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select time period" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={createGoalMutation.isPending}
                >
                  {createGoalMutation.isPending ? "Creating..." : "Create Goal"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-20 w-full rounded-xl" />
          <Skeleton className="h-20 w-full rounded-xl" />
          <Skeleton className="h-20 w-full rounded-xl" />
        </div>
      ) : error ? (
        <div className="bg-red-50 text-red-700 p-4 rounded-xl">
          Error loading goals
        </div>
      ) : goals && goals.length > 0 ? (
        <div className="space-y-4">
          {goals.map((goal: Goal) => (
            <Card key={goal.id} className="relative">
              <CardContent className="pt-6">
                <div className="flex justify-between items-center mb-1">
                  <h3 className="text-md font-medium">{goal.name}</h3>
                  <span className="text-md font-medium">
                    {goal.currentValue}/{goal.targetValue}
                  </span>
                </div>
                
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      goal.isCompleted ? 'bg-green-500' : 
                      (goal.currentValue / goal.targetValue >= 0.6) ? 'bg-primary' : 'bg-amber-500'
                    }`}
                    style={{ width: `${Math.min(100, (goal.currentValue / goal.targetValue) * 100)}%` }}
                  />
                </div>
                
                <div className="mt-3 text-sm text-gray-500 flex items-center justify-between">
                  <span>
                    {goal.type === 'workout_count' ? 'Workouts' : 
                     goal.type === 'distance' ? 'Miles' : 'Minutes'} per {goal.periodicity}
                  </span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-gray-500 hover:text-red-500"
                    onClick={() => handleDeleteGoal(goal.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="bg-gray-50 p-8 rounded-xl text-center">
          <p className="text-gray-500 mb-4">You don't have any goals yet.</p>
          <p className="text-sm text-gray-400">Set goals to track your fitness progress.</p>
        </div>
      )}
    </main>
  );
}
