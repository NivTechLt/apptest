import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import WeeklySummary from "@/components/WeeklySummary";
import GoalsList from "@/components/GoalsList";
import RecentWorkouts from "@/components/RecentWorkouts";
import { Skeleton } from "@/components/ui/skeleton";
import { Goal, Workout } from "@shared/schema";
import AchievementBadges from "@/components/AchievementBadges";
import AiWorkoutPlanner from "@/components/AiWorkoutPlanner";
import ExportDataButton from "@/components/ExportDataButton";
import SubscriptionFeature from "@/components/SubscriptionFeature";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Sparkles, Dumbbell, Calendar } from "lucide-react";

const DEFAULT_USER_ID = 1; // Using a default user for this example

export default function Dashboard() {
  const [userId] = useState(DEFAULT_USER_ID);
  
  // Define type for weekly stats
  interface WeeklyStats {
    workoutCount: number;
    totalMinutes: number;
    totalCalories: number;
    dailyCounts: number[];
  }

  // Fetch weekly stats
  const { 
    data: weeklyStats, 
    isLoading: isLoadingStats,
    error: statsError,
  } = useQuery<WeeklyStats>({
    queryKey: ['/api/stats/weekly', userId],
    queryFn: async () => {
      const response = await fetch(`/api/stats/weekly/${userId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch weekly stats');
      }
      return response.json() as Promise<WeeklyStats>;
    },
  });
  
  // Fetch goals
  const { 
    data: goals, 
    isLoading: isLoadingGoals,
    error: goalsError,
  } = useQuery<Goal[]>({
    queryKey: ['/api/goals/user', userId],
    queryFn: async () => {
      const response = await fetch(`/api/goals/user/${userId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch goals');
      }
      return response.json() as Promise<Goal[]>;
    },
  });
  
  // Fetch recent workouts
  const { 
    data: recentWorkouts, 
    isLoading: isLoadingWorkouts,
    error: workoutsError,
  } = useQuery<Workout[]>({
    queryKey: ['/api/workouts/recent', userId],
    queryFn: async () => {
      const response = await fetch(`/api/workouts/recent/${userId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch recent workouts');
      }
      return response.json() as Promise<Workout[]>;
    },
  });

  const { user } = useAuth();
  
  return (
    <main className="flex-1 px-4 pt-4 pb-20">
      <div id="dashboard" className="space-y-6">
        {/* Weekly Summary Section */}
        {isLoadingStats ? (
          <Skeleton className="h-64 w-full rounded-xl" />
        ) : statsError ? (
          <div className="bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 p-4 rounded-xl">
            Error loading weekly stats
          </div>
        ) : weeklyStats ? (
          <WeeklySummary 
            stats={weeklyStats}
            startDate={new Date()} // Would calculate properly in a real app
          />
        ) : (
          <div className="bg-gray-50 dark:bg-gray-950 p-4 rounded-xl text-center">
            No stats available yet
          </div>
        )}
        
        {/* Premium Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* AI Workout Planner - Pro Feature */}
          <Card className="overflow-hidden">
            <CardHeader className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                AI Workout Planner
              </CardTitle>
              <CardDescription className="text-indigo-100">
                Get personalized workout suggestions
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4 pb-2">
              <SubscriptionFeature 
                featureKey="aiPlanning" 
                requiredTier="pro"
                showUpgradeButton={true}
                fallback={
                  <div className="text-center p-4 text-muted-foreground">
                    Upgrade to Pro for AI-powered workout suggestions
                  </div>
                }
              >
                <AiWorkoutPlanner />
              </SubscriptionFeature>
            </CardContent>
            <CardFooter className="pt-0">
              <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                Pro Feature
              </Button>
            </CardFooter>
          </Card>
          
          {/* Achievement Badges - Premium Feature */}
          <Card className="overflow-hidden">
            <CardHeader className="bg-gradient-to-br from-amber-400 to-orange-500 text-white">
              <CardTitle className="flex items-center gap-2">
                <Dumbbell className="h-5 w-5" />
                Achievement Badges
              </CardTitle>
              <CardDescription className="text-amber-100">
                Track your fitness milestones
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4 pb-2">
              <SubscriptionFeature 
                featureKey="achievementBadges" 
                requiredTier="premium"
                showUpgradeButton={true}
                fallback={
                  <div className="text-center p-4 text-muted-foreground">
                    Upgrade to Premium to unlock achievement badges
                  </div>
                }
              >
                <AchievementBadges />
              </SubscriptionFeature>
            </CardContent>
            <CardFooter className="pt-0">
              <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                Premium Feature
              </Button>
            </CardFooter>
          </Card>
          
          {/* Export Data - Premium Feature */}
          <Card className="overflow-hidden">
            <CardHeader className="bg-gradient-to-br from-emerald-500 to-green-600 text-white">
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Export Your Data
              </CardTitle>
              <CardDescription className="text-emerald-100">
                Download your workout history
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4 pb-2 flex items-center justify-center">
              <SubscriptionFeature 
                featureKey="exportData" 
                requiredTier="premium"
                showUpgradeButton={true}
                fallback={
                  <div className="text-center p-4 text-muted-foreground">
                    Upgrade to Premium to export your data
                  </div>
                }
              >
                <ExportDataButton variant="outline" className="w-full" />
              </SubscriptionFeature>
            </CardContent>
            <CardFooter className="pt-0">
              <Button variant="ghost" size="sm" className="w-full justify-start text-xs">
                Premium Feature
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        {/* Goals Section */}
        {isLoadingGoals ? (
          <Skeleton className="h-48 w-full rounded-xl" />
        ) : goalsError ? (
          <div className="bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 p-4 rounded-xl">
            Error loading goals
          </div>
        ) : (
          <GoalsList goals={goals || []} />
        )}
        
        {/* Recent Workouts Section */}
        {isLoadingWorkouts ? (
          <Skeleton className="h-64 w-full rounded-xl" />
        ) : workoutsError ? (
          <div className="bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 p-4 rounded-xl">
            Error loading recent workouts
          </div>
        ) : (
          <RecentWorkouts workouts={recentWorkouts || []} />
        )}
      </div>
    </main>
  );
}
