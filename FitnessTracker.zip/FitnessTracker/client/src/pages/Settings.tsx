import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Moon, Sun, Bell, User, HelpCircle, Share2, LogOut, CreditCard, 
  AlertCircle, Crown, Twitter, Mail, Copy, CheckCheck
} from "lucide-react";
import { BsFacebook } from "react-icons/bs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useTheme } from "@/lib/theme-context";
import { Link, useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

// Define profile update schema
const profileUpdateSchema = z.object({
  firstName: z.string().nullable().optional(),
  lastName: z.string().nullable().optional(),
  email: z.string().email("Please enter a valid email address"),
});

type ProfileUpdateValues = z.infer<typeof profileUpdateSchema>;

export default function Settings() {
  const { toast } = useToast();
  const { user, logoutMutation } = useAuth();
  const { theme: currentTheme, setTheme } = useTheme();
  const [location, setLocation] = useLocation();
  const [notifications, setNotifications] = useState(true);
  const [workoutReminders, setWorkoutReminders] = useState(true);
  const [goalAlerts, setGoalAlerts] = useState(true);
  const [showProfileForm, setShowProfileForm] = useState(false);
  
  // React Hook Form setup
  const { register, handleSubmit, formState: { errors } } = useForm<ProfileUpdateValues>({
    resolver: zodResolver(profileUpdateSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      email: user?.email || "",
    }
  });
  
  // Profile update mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileUpdateValues) => {
      const response = await apiRequest("PATCH", "/api/user/profile", data);
      return await response.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(["/api/user"], data);
      setShowProfileForm(false);
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message || "An error occurred while updating your profile.",
        variant: "destructive",
      });
    },
  });
  
  const onUpdateProfileSubmit = handleSubmit((data) => {
    updateProfileMutation.mutate(data);
  });
  
  const toggleTheme = () => {
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    
    toast({
      title: "Theme changed",
      description: `App theme set to ${newTheme} mode.`,
    });
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Sharing functionality
  const [shareUrl, setShareUrl] = useState("");
  const [copied, setCopied] = useState(false);
  
  const generateShareLink = () => {
    const baseUrl = window.location.origin;
    const shareLink = `${baseUrl}/shared/${user?.username || 'user'}`;
    setShareUrl(shareLink);
    return shareLink;
  };
  
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(
      () => {
        setCopied(true);
        toast({
          title: "Link copied",
          description: "Share link copied to clipboard",
        });
        
        // Reset copied state after 3 seconds
        setTimeout(() => {
          setCopied(false);
        }, 3000);
      },
      () => {
        toast({
          title: "Copy failed",
          description: "Failed to copy link to clipboard",
          variant: "destructive",
        });
      }
    );
  };

  return (
    <main className="flex-1 px-4 pt-4 pb-20">
      <h1 className="text-2xl font-bold mb-6">Settings</h1>
      
      <div className="space-y-6">
        {/* App Theme */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Sun className="w-5 h-5 mr-2" />
              App Theme
            </CardTitle>
          </CardHeader>
          <CardContent className="pb-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="theme-mode" className="flex items-center cursor-pointer">
                {currentTheme === 'dark' ? <Moon className="w-4 h-4 mr-2" /> : <Sun className="w-4 h-4 mr-2" />}
                {currentTheme === 'dark' ? 'Dark Mode' : 'Light Mode'}
              </Label>
              <Switch 
                id="theme-mode" 
                checked={currentTheme === 'dark'}
                onCheckedChange={toggleTheme}
              />
            </div>
          </CardContent>
        </Card>
        
        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Bell className="w-5 h-5 mr-2" />
              Notifications
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="notifications" className="cursor-pointer">
                Enable Notifications
              </Label>
              <Switch 
                id="notifications" 
                checked={notifications}
                onCheckedChange={setNotifications}
              />
            </div>
            
            <Separator className="my-2" />
            
            <div className="flex items-center justify-between">
              <Label htmlFor="workout-reminders" className="cursor-pointer">
                Workout Reminders
              </Label>
              <Switch 
                id="workout-reminders" 
                checked={workoutReminders}
                disabled={!notifications}
                onCheckedChange={setWorkoutReminders}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="goal-alerts" className="cursor-pointer">
                Goal Achievement Alerts
              </Label>
              <Switch 
                id="goal-alerts" 
                checked={goalAlerts}
                disabled={!notifications}
                onCheckedChange={setGoalAlerts}
              />
            </div>
          </CardContent>
        </Card>
        
        {/* Subscription */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Crown className="w-5 h-5 mr-2" />
              Subscription
            </CardTitle>
            <CardDescription>
              Manage your subscription plan
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Current Plan</p>
                  <p className="text-sm text-muted-foreground">
                    {user?.isSubscribed ? user.subscriptionTier || 'Basic' : 'Free'}
                  </p>
                </div>
                {user?.isSubscribed && (
                  <Badge variant="outline" className="bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300">
                    Active
                  </Badge>
                )}
              </div>
              
              {user?.subscriptionEndDate && (
                <div>
                  <p className="text-sm text-muted-foreground">
                    Renews on {new Date(user.subscriptionEndDate).toLocaleDateString()}
                  </p>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              onClick={() => setLocation("/subscription")}
              className="w-full"
              variant={user?.isSubscribed ? "outline" : "default"}
            >
              <CreditCard className="mr-2 h-4 w-4" />
              {user?.isSubscribed ? "Manage Subscription" : "Upgrade Plan"}
            </Button>
          </CardFooter>
        </Card>

        {/* Account */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <User className="w-5 h-5 mr-2" />
              Account
            </CardTitle>
            <CardDescription>
              Manage your account information
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* User profile information */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-medium">Profile Information</h3>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-xs"
                    onClick={() => setShowProfileForm(!showProfileForm)}
                  >
                    {showProfileForm ? "Cancel" : "Edit"}
                  </Button>
                </div>
                
                {!showProfileForm ? (
                  <div className="bg-secondary/50 rounded-md p-3 space-y-2">
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 rounded-full p-3">
                        <User className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{user?.firstName} {user?.lastName}</p>
                        <p className="text-sm text-muted-foreground">@{user?.username}</p>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2 mt-3">
                      <div>
                        <p className="text-xs text-muted-foreground">Email</p>
                        <p className="text-sm">{user?.email}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Member Since</p>
                        <p className="text-sm">{user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : "N/A"}</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <form className="space-y-3" onSubmit={onUpdateProfileSubmit}>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <Label htmlFor="firstName">First Name</Label>
                        <Input 
                          id="firstName" 
                          placeholder="First Name"
                          defaultValue={user?.firstName || ""}
                          {...register("firstName")}
                        />
                      </div>
                      <div className="space-y-1">
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input 
                          id="lastName" 
                          placeholder="Last Name"
                          defaultValue={user?.lastName || ""}
                          {...register("lastName")}
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-1">
                      <Label htmlFor="email">Email</Label>
                      <Input 
                        id="email" 
                        type="email"
                        placeholder="Email address"
                        defaultValue={user?.email || ""}
                        {...register("email")}
                      />
                    </div>
                    
                    <div className="flex gap-2 justify-end">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setShowProfileForm(false)}
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        size="sm"
                        disabled={updateProfileMutation.isPending}
                      >
                        {updateProfileMutation.isPending ? (
                          <>
                            <span className="mr-2 h-4 w-4 animate-spin">⏳</span>
                            Saving...
                          </>
                        ) : "Save Changes"}
                      </Button>
                    </div>
                  </form>
                )}
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                {/* Share Progress Dialog */}
                <Dialog>
                  <DialogTrigger asChild>
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                      onClick={generateShareLink}
                    >
                      <Share2 className="mr-2 h-4 w-4" />
                      Share Progress
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Share your fitness journey</DialogTitle>
                      <DialogDescription>
                        Share your workout progress with friends and family to stay motivated
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                      <div className="flex flex-col space-y-2">
                        <Label htmlFor="share-link">Share link</Label>
                        <div className="flex items-center space-x-2">
                          <Input
                            id="share-link"
                            value={shareUrl}
                            readOnly
                            className="flex-1"
                          />
                          <Button 
                            size="icon" 
                            onClick={() => copyToClipboard(shareUrl)}
                            variant="outline"
                          >
                            {copied ? <CheckCheck className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                          </Button>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-2">
                        <Button variant="outline" className="flex items-center justify-center">
                          <BsFacebook className="h-4 w-4 mr-2" />
                          Facebook
                        </Button>
                        <Button variant="outline" className="flex items-center justify-center">
                          <Twitter className="h-4 w-4 mr-2" />
                          Twitter
                        </Button>
                        <Button variant="outline" className="flex items-center justify-center">
                          <Mail className="h-4 w-4 mr-2" />
                          Email
                        </Button>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" className="w-full sm:w-auto">
                        Close
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
                
                {/* Help & Support Dialog */}
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" className="w-full justify-start">
                      <HelpCircle className="mr-2 h-4 w-4" />
                      Help & Support
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Help & Support</DialogTitle>
                      <DialogDescription>
                        Find answers to common questions and get assistance with your FitTrack account
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                      <Accordion type="single" collapsible className="w-full">
                        <AccordionItem value="item-1">
                          <AccordionTrigger className="text-sm font-medium">
                            How do I log a workout?
                          </AccordionTrigger>
                          <AccordionContent className="text-sm">
                            <p>To log a workout:</p>
                            <ol className="list-decimal list-inside pl-2 mt-2 space-y-1">
                              <li>Go to the Dashboard screen</li>
                              <li>Tap the "+" button at the bottom</li>
                              <li>Select your workout type</li>
                              <li>Enter duration, intensity, and notes</li>
                              <li>Tap "Save Workout" to record it</li>
                            </ol>
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-2">
                          <AccordionTrigger className="text-sm font-medium">
                            How do I set fitness goals?
                          </AccordionTrigger>
                          <AccordionContent className="text-sm">
                            <p>To set a new fitness goal:</p>
                            <ol className="list-decimal list-inside pl-2 mt-2 space-y-1">
                              <li>Navigate to the Goals tab</li>
                              <li>Tap "Add New Goal"</li>
                              <li>Choose a goal category and target</li>
                              <li>Set your deadline</li>
                              <li>Save your goal</li>
                            </ol>
                            <p className="mt-2">FitTrack will track your progress automatically as you log workouts.</p>
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-3">
                          <AccordionTrigger className="text-sm font-medium">
                            How do I manage my subscription?
                          </AccordionTrigger>
                          <AccordionContent className="text-sm">
                            <p>To manage your subscription:</p>
                            <ol className="list-decimal list-inside pl-2 mt-2 space-y-1">
                              <li>Go to Settings</li>
                              <li>Find the Subscription section</li>
                              <li>Tap "Manage Subscription"</li>
                              <li>You can upgrade, downgrade, or cancel from this screen</li>
                            </ol>
                            <p className="mt-2">Please note that subscription changes may take effect at the end of your current billing cycle.</p>
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-4">
                          <AccordionTrigger className="text-sm font-medium">
                            How do I share my fitness progress?
                          </AccordionTrigger>
                          <AccordionContent className="text-sm">
                            <p>To share your progress:</p>
                            <ol className="list-decimal list-inside pl-2 mt-2 space-y-1">
                              <li>Go to Settings</li>
                              <li>Tap "Share Progress"</li>
                              <li>Choose from sharing options (social media, email, or copy link)</li>
                            </ol>
                            <p className="mt-2">Shared links allow others to view a snapshot of your fitness journey without logging in.</p>
                          </AccordionContent>
                        </AccordionItem>
                        <AccordionItem value="item-5">
                          <AccordionTrigger className="text-sm font-medium">
                            How to contact support?
                          </AccordionTrigger>
                          <AccordionContent className="text-sm">
                            <p>You can reach our support team by:</p>
                            <ul className="list-disc list-inside pl-2 mt-2 space-y-1">
                              <li>Email: support@fittrack.app</li>
                              <li>Chat: Open chat support from the Help menu on desktop</li>
                              <li>Knowledge Base: Visit our help center at help.fittrack.app</li>
                            </ul>
                            <p className="mt-2">Our support team is available Monday-Friday, 9am-5pm.</p>
                          </AccordionContent>
                        </AccordionItem>
                      </Accordion>
                      
                      <div className="mt-6 p-4 bg-secondary/50 rounded-md flex items-center">
                        <AlertCircle className="h-8 w-8 text-blue-500 mr-4" />
                        <div>
                          <h4 className="font-medium">Need more help?</h4>
                          <p className="text-sm text-muted-foreground">
                            Contact our support team at{" "}
                            <a href="mailto:support@fittrack.app" className="text-primary underline">
                              support@fittrack.app
                            </a>
                          </p>
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              variant="destructive" 
              className="w-full"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-4 w-4" />
              Log Out
            </Button>
          </CardFooter>
        </Card>
        
        <div className="text-center text-xs text-gray-400 pt-4">
          FitTrack v1.0.0
        </div>
      </div>
    </main>
  );
}
