import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { 
  ArrowUpDown, 
  CalendarRange, 
  LineChart as LineChartIcon, 
  Plus, 
  RefreshCw, 
  Smartphone, 
  Weight 
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatRelativeDate } from "@/lib/date-utils";
import SubscriptionFeature from "@/components/SubscriptionFeature";

interface BodyMeasurement {
  id: number;
  userId: number;
  date: string;
  weight: number;
  bmi: number | null;
  bodyFatPercentage: number | null;
  musclePercentage: number | null;
  bodyWaterPercentage: number | null;
  boneMass: number | null;
  visceralFat: number | null;
  basalMetabolicRate: number | null;
  source: string | null;
  note: string | null;
}

interface UserDevice {
  id: number;
  userId: number;
  type: string;
  name: string | null;
  deviceId: string | null;
  createdAt: string;
  lastSynced: string | null;
  isActive: boolean;
  settings: any;
}

interface UserSettings {
  id: number;
  userId: number;
  weightUnit: string;
  height: number | null;
  birthDate: string | null;
  gender: string | null;
  reminderEnabled: boolean;
  reminderTime: string | null;
  healthKitEnabled: boolean;
  fitbitEnabled: boolean;
  language: string;
  createdAt: string;
  updatedAt: string;
}

export default function BodyMeasurements() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("measurements");
  const [showAddMeasurement, setShowAddMeasurement] = useState(false);

  // Fetch measurements
  const { data: measurements = [], isLoading: measurementsLoading } = useQuery({
    queryKey: ["/api/measurements/user", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const res = await fetch(`/api/measurements/user/${user.id}`);
      if (!res.ok) throw new Error("Failed to fetch measurements");
      return res.json();
    },
    enabled: !!user,
  });

  // Fetch latest measurement
  const { data: latestMeasurement, isLoading: latestLoading } = useQuery({
    queryKey: ["/api/measurements/latest", user?.id],
    queryFn: async () => {
      if (!user) return null;
      const res = await fetch(`/api/measurements/latest/${user.id}`);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch latest measurement");
      return res.json();
    },
    enabled: !!user,
  });

  // Fetch user devices
  const { data: devices = [], isLoading: devicesLoading } = useQuery({
    queryKey: ["/api/devices"],
    queryFn: async () => {
      const res = await fetch("/api/devices");
      if (!res.ok) throw new Error("Failed to fetch devices");
      return res.json();
    },
    enabled: !!user,
  });

  // Fetch user settings
  const { data: settings, isLoading: settingsLoading } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: async () => {
      const res = await fetch("/api/settings");
      if (!res.ok) throw new Error("Failed to fetch settings");
      return res.json();
    },
    enabled: !!user,
  });

  // Add measurement mutation
  const addMeasurementMutation = useMutation({
    mutationFn: async (newMeasurement: Omit<BodyMeasurement, "id">) => {
      const res = await apiRequest("POST", "/api/measurements", newMeasurement);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to add measurement");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/measurements/user", user?.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/measurements/latest", user?.id] });
      setShowAddMeasurement(false);
      toast({
        title: "Measurement added",
        description: "Your measurement has been added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add measurement",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (updatedSettings: Partial<UserSettings>) => {
      const res = await apiRequest("PATCH", "/api/settings", updatedSettings);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to update settings");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Settings updated",
        description: "Your settings have been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update settings",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Add device mutation
  const addDeviceMutation = useMutation({
    mutationFn: async (newDevice: Omit<UserDevice, "id" | "createdAt" | "lastSynced">) => {
      const res = await apiRequest("POST", "/api/devices", newDevice);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to add device");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
      toast({
        title: "Device added",
        description: "Your device has been added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add device",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle adding a new measurement
  const handleAddMeasurement = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    
    const weight = formData.get("weight") ? parseFloat(formData.get("weight") as string) : 0;
    const bodyFat = formData.get("bodyFat") ? parseFloat(formData.get("bodyFat") as string) : null;
    const muscle = formData.get("muscle") ? parseFloat(formData.get("muscle") as string) : null;
    const water = formData.get("water") ? parseFloat(formData.get("water") as string) : null;
    const note = formData.get("note") as string || null;
    
    // Calculate BMI if height is available
    let bmi = null;
    if (settings?.height && weight) {
      const heightInMeters = settings.height / 100; // Convert cm to meters
      bmi = parseFloat((weight / (heightInMeters * heightInMeters)).toFixed(1));
    }

    const newMeasurement = {
      userId: user!.id,
      date: new Date().toISOString(),
      weight,
      bmi,
      bodyFatPercentage: bodyFat,
      musclePercentage: muscle,
      bodyWaterPercentage: water,
      boneMass: null,
      visceralFat: null,
      basalMetabolicRate: null,
      source: "manual",
      note,
    };

    addMeasurementMutation.mutate(newMeasurement);
  };

  // Toggle Health app integration
  const toggleHealthKit = (enabled: boolean) => {
    updateSettingsMutation.mutate({
      healthKitEnabled: enabled,
    });
  };

  // Toggle Fitbit integration
  const toggleFitbit = (enabled: boolean) => {
    updateSettingsMutation.mutate({
      fitbitEnabled: enabled,
    });
  };

  // Handle adding a new device
  const handleAddDevice = (type: string) => {
    if (!user) return;
    
    addDeviceMutation.mutate({
      userId: user.id,
      type,
      name: `My ${type.charAt(0).toUpperCase() + type.slice(1)}`,
      deviceId: null,
      isActive: true,
      settings: {},
    });
  };

  // Format measurement data for chart
  const chartData = [...measurements]
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .map((m) => ({
      date: new Date(m.date).toLocaleDateString(),
      weight: m.weight,
      bodyFat: m.bodyFatPercentage,
      muscle: m.musclePercentage,
      water: m.bodyWaterPercentage,
    }));

  const measurementsList = [...measurements]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="container py-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Body Measurements</h1>
        <Button 
          onClick={() => setShowAddMeasurement(true)}
          size="sm"
          className="flex items-center gap-1"
        >
          <Plus size={16} />
          <span>Add</span>
        </Button>
      </div>

      <Tabs defaultValue="measurements" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 w-full">
          <TabsTrigger value="measurements">Measurements</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="devices">Devices</TabsTrigger>
        </TabsList>

        {/* Measurements Tab */}
        <TabsContent value="measurements" className="space-y-4">
          {!measurementsLoading && measurements.length === 0 ? (
            <Card>
              <CardContent className="p-6 flex flex-col items-center justify-center text-center space-y-4">
                <Weight size={40} className="text-muted-foreground" />
                <div>
                  <h3 className="text-lg font-medium">No measurements yet</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Start tracking your body measurements to see your progress
                  </p>
                </div>
                <Button onClick={() => setShowAddMeasurement(true)}>Add Measurement</Button>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* Latest Measurement Card */}
              {!latestLoading && latestMeasurement && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">
                      Latest Measurement
                      <span className="text-sm font-normal text-muted-foreground ml-2">
                        {formatRelativeDate(new Date(latestMeasurement.date))}
                      </span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                      <div className="flex flex-col">
                        <span className="text-sm text-muted-foreground">Weight</span>
                        <span className="text-xl font-semibold">
                          {latestMeasurement.weight} {settings?.weightUnit || 'kg'}
                        </span>
                      </div>
                      {latestMeasurement.bmi && (
                        <div className="flex flex-col">
                          <span className="text-sm text-muted-foreground">BMI</span>
                          <span className="text-xl font-semibold">{latestMeasurement.bmi}</span>
                        </div>
                      )}
                      {latestMeasurement.bodyFatPercentage && (
                        <div className="flex flex-col">
                          <span className="text-sm text-muted-foreground">Body Fat</span>
                          <span className="text-xl font-semibold">{latestMeasurement.bodyFatPercentage}%</span>
                        </div>
                      )}
                      {latestMeasurement.musclePercentage && (
                        <div className="flex flex-col">
                          <span className="text-sm text-muted-foreground">Muscle</span>
                          <span className="text-xl font-semibold">{latestMeasurement.musclePercentage}%</span>
                        </div>
                      )}
                      {latestMeasurement.bodyWaterPercentage && (
                        <div className="flex flex-col">
                          <span className="text-sm text-muted-foreground">Water</span>
                          <span className="text-xl font-semibold">{latestMeasurement.bodyWaterPercentage}%</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Measurements History */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">History</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-4">
                      {measurementsList.map((measurement) => (
                        <div key={measurement.id} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="font-medium">
                              {formatRelativeDate(new Date(measurement.date))}
                            </span>
                            <span className="text-sm text-muted-foreground">
                              {measurement.source}
                            </span>
                          </div>
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                            <div className="flex items-center gap-2">
                              <Weight size={16} />
                              <span>
                                {measurement.weight} {settings?.weightUnit || 'kg'}
                              </span>
                            </div>
                            {measurement.bmi && (
                              <div className="flex items-center gap-2">
                                <ArrowUpDown size={16} />
                                <span>BMI: {measurement.bmi}</span>
                              </div>
                            )}
                            {measurement.bodyFatPercentage && (
                              <div className="flex items-center gap-2">
                                <span>Fat: {measurement.bodyFatPercentage}%</span>
                              </div>
                            )}
                          </div>
                          {measurement.note && (
                            <p className="text-sm text-muted-foreground">{measurement.note}</p>
                          )}
                          <Separator />
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        {/* Trends Tab */}
        <TabsContent value="trends">
          <SubscriptionFeature 
            featureKey="bodyCompositionAnalysis" 
            showUpgradeButton
            requiredTier="premium"
          >
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Weight Trends</CardTitle>
              </CardHeader>
              <CardContent className="pt-2">
                {chartData.length > 0 ? (
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                        <XAxis 
                          dataKey="date" 
                          tick={{ fontSize: 12 }} 
                          tickFormatter={(value) => {
                            // Format date to show only day/month
                            const [month, day] = value.split('/');
                            return `${month}/${day}`;
                          }}
                        />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Line 
                          type="monotone" 
                          dataKey="weight" 
                          name={`Weight (${settings?.weightUnit || 'kg'})`}
                          stroke="#3b82f6" 
                          strokeWidth={2} 
                          dot={{ r: 4 }} 
                          activeDot={{ r: 6 }} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                ) : (
                  <div className="h-64 flex flex-col items-center justify-center text-center p-6 space-y-4">
                    <LineChartIcon size={40} className="text-muted-foreground" />
                    <div>
                      <h3 className="text-lg font-medium">No data to analyze</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        Add at least two measurements to see your trends
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {chartData.length > 0 && (
              <Card className="mt-4">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Body Composition</CardTitle>
                </CardHeader>
                <CardContent className="pt-2">
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                        <XAxis 
                          dataKey="date" 
                          tick={{ fontSize: 12 }} 
                          tickFormatter={(value) => {
                            // Format date to show only day/month
                            const [month, day] = value.split('/');
                            return `${month}/${day}`;
                          }}
                        />
                        <YAxis tick={{ fontSize: 12 }} />
                        <Tooltip />
                        <Line 
                          type="monotone" 
                          dataKey="bodyFat" 
                          name="Body Fat (%)" 
                          stroke="#ef4444" 
                          strokeWidth={2} 
                          dot={{ r: 4 }} 
                          activeDot={{ r: 6 }} 
                        />
                        <Line 
                          type="monotone" 
                          dataKey="muscle" 
                          name="Muscle (%)" 
                          stroke="#22c55e" 
                          strokeWidth={2} 
                          dot={{ r: 4 }} 
                          activeDot={{ r: 6 }} 
                        />
                        <Line 
                          type="monotone" 
                          dataKey="water" 
                          name="Water (%)" 
                          stroke="#3b82f6" 
                          strokeWidth={2} 
                          dot={{ r: 4 }} 
                          activeDot={{ r: 6 }} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            )}
          </SubscriptionFeature>
        </TabsContent>

        {/* Devices Tab */}
        <TabsContent value="devices">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Connected Devices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Health app integration */}
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h3 className="font-medium">Health App</h3>
                    <p className="text-sm text-muted-foreground">
                      Sync measurements from your phone's health app
                    </p>
                  </div>
                  <Switch 
                    checked={settings?.healthKitEnabled} 
                    onCheckedChange={toggleHealthKit}
                    disabled={settingsLoading || updateSettingsMutation.isPending}
                  />
                </div>

                {/* Fitbit integration */}
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <h3 className="font-medium">Fitbit</h3>
                    <p className="text-sm text-muted-foreground">
                      Connect your Fitbit account to sync data
                    </p>
                  </div>
                  <Switch 
                    checked={settings?.fitbitEnabled} 
                    onCheckedChange={toggleFitbit}
                    disabled={settingsLoading || updateSettingsMutation.isPending}
                  />
                </div>

                <Separator />

                {/* List of connected smart scales */}
                <div>
                  <h3 className="font-medium mb-3">Smart Scales</h3>
                  
                  {!devicesLoading && devices.length === 0 ? (
                    <div className="text-center py-6 space-y-3">
                      <Smartphone className="mx-auto h-8 w-8 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">No devices connected</p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAddDevice("scale")}
                        disabled={addDeviceMutation.isPending}
                      >
                        <Plus className="mr-1 h-4 w-4" />
                        Add Smart Scale
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {devices.map((device) => (
                        <div key={device.id} className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{device.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {device.lastSynced ? `Last synced: ${formatRelativeDate(new Date(device.lastSynced))}` : "Never synced"}
                            </p>
                          </div>
                          <Button size="sm" variant="ghost">
                            <RefreshCw className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAddDevice("scale")}
                        disabled={addDeviceMutation.isPending}
                        className="mt-3"
                      >
                        <Plus className="mr-1 h-4 w-4" />
                        Add Another Scale
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Measurement Dialog */}
      <Dialog open={showAddMeasurement} onOpenChange={setShowAddMeasurement}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Measurement</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleAddMeasurement} className="space-y-4">
            <div className="grid gap-4 py-2">
              <div className="space-y-2">
                <Label htmlFor="weight">Weight ({settings?.weightUnit || 'kg'})*</Label>
                <Input 
                  id="weight" 
                  name="weight" 
                  type="number" 
                  step="0.1" 
                  min="0" 
                  required 
                  placeholder="Enter your weight" 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bodyFat">Body Fat (%)</Label>
                <Input 
                  id="bodyFat" 
                  name="bodyFat" 
                  type="number" 
                  step="0.1" 
                  min="0" 
                  max="100" 
                  placeholder="Enter body fat percentage" 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="muscle">Muscle (%)</Label>
                <Input 
                  id="muscle" 
                  name="muscle" 
                  type="number" 
                  step="0.1" 
                  min="0" 
                  max="100" 
                  placeholder="Enter muscle percentage" 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="water">Water (%)</Label>
                <Input 
                  id="water" 
                  name="water" 
                  type="number" 
                  step="0.1" 
                  min="0" 
                  max="100" 
                  placeholder="Enter water percentage" 
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="note">Note</Label>
                <Input id="note" name="note" placeholder="Add a note (optional)" />
              </div>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowAddMeasurement(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={addMeasurementMutation.isPending}
              >
                {addMeasurementMutation.isPending ? "Adding..." : "Add Measurement"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}