import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Eye, EyeOff, Check, X, Mail, LucideApple, AlertCircle } from "lucide-react";
import { FcGoogle } from "react-icons/fc";
import { motion, AnimatePresence } from "framer-motion";
import Footer from "@/components/Footer";
import NiaLogo from "@/components/NiaLogo";

const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters")
    .max(20, "Username must be at most 20 characters")
    .regex(/^[a-zA-Z0-9_]+$/, "Username can only contain letters, numbers, and underscores"),
  email: z.string().email("Invalid email format"),
  password: z.string().min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[^a-zA-Z0-9]/, "Password must contain at least one special character"),
  confirmPassword: z.string(),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"]
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [activeTab, setActiveTab] = useState<"login" | "register">("login");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [forgotPasswordMode, setForgotPasswordMode] = useState(false);
  const [verificationSent, setVerificationSent] = useState(false);

  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Register form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      email: "",
      firstName: "",
      lastName: "",
    },
  });
  
  // Watch password for strength meter
  const password = registerForm.watch("password");
  
  // Calculate password strength
  useEffect(() => {
    if (!password) {
      setPasswordStrength(0);
      return;
    }
    
    let strength = 0;
    
    // Length
    if (password.length >= 8) strength += 20;
    
    // Has uppercase
    if (/[A-Z]/.test(password)) strength += 20;
    
    // Has lowercase
    if (/[a-z]/.test(password)) strength += 20;
    
    // Has numbers
    if (/[0-9]/.test(password)) strength += 20;
    
    // Has special characters
    if (/[^a-zA-Z0-9]/.test(password)) strength += 20;
    
    setPasswordStrength(strength);
  }, [password]);
  
  // Get password strength color
  const getStrengthColor = () => {
    if (passwordStrength < 40) return "bg-red-500";
    if (passwordStrength < 80) return "bg-yellow-500";
    return "bg-green-500";
  };
  
  // Get password strength text
  const getStrengthText = () => {
    if (passwordStrength < 40) return "Weak";
    if (passwordStrength < 80) return "Good";
    return "Strong";
  };
  
  const onLoginSubmit = (values: LoginFormValues) => {
    loginMutation.mutate(values);
  };

  const onRegisterSubmit = (values: RegisterFormValues) => {
    registerMutation.mutate(values);
  };
  
  const handleForgotPassword = () => {
    // Would typically send a reset link to the email address
    setVerificationSent(true);
  };
  
  const handleGoogleLogin = () => {
    // This would be implemented with a backend route
    window.location.href = "/api/auth/google";
  };
  
  const handleAppleLogin = () => {
    // This would be implemented with a backend route
    window.location.href = "/api/auth/apple";
  };
  
  // Redirect if already logged in - MOVED AFTER ALL HOOKS AND FUNCTIONS
  if (user) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Form Side */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="md:w-1/2 flex items-center justify-center px-4 py-8 bg-background"
        >
          <div className="w-full max-w-md">
            <div className="mb-8 flex justify-center">
              <NiaLogo width={80} height={80} />
            </div>
            
            {forgotPasswordMode ? (
              <AnimatePresence mode="wait">
                <motion.div
                  key="forgot-password"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card>
                    <CardHeader>
                      <CardTitle>Reset Password</CardTitle>
                      <CardDescription>
                        Enter your email address and we'll send you a link to reset your password
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {verificationSent ? (
                        <Alert className="mb-4 bg-green-50 border-green-200">
                          <Mail className="h-4 w-4 text-green-500" />
                          <AlertDescription className="text-green-600">
                            If an account exists with this email, a password reset link has been sent.
                          </AlertDescription>
                        </Alert>
                      ) : (
                        <form onSubmit={(e) => {
                          e.preventDefault();
                          handleForgotPassword();
                        }} className="space-y-4">
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="example@email.com" required />
                            </FormControl>
                          </FormItem>
                          <Button type="submit" className="w-full">
                            Send Reset Link
                          </Button>
                        </form>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button 
                        variant="ghost" 
                        className="w-full" 
                        onClick={() => {
                          setForgotPasswordMode(false);
                          setVerificationSent(false);
                        }}
                      >
                        Back to Login
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              </AnimatePresence>
            ) : (
              <AnimatePresence mode="wait">
                <motion.div
                  key="login-register"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "login" | "register")}>
                    <TabsList className="grid grid-cols-2 w-full mb-8">
                      <TabsTrigger value="login">Login</TabsTrigger>
                      <TabsTrigger value="register">Register</TabsTrigger>
                    </TabsList>

                    <TabsContent value="login">
                      <Card className="border-t-4 border-t-primary shadow-lg">
                        <CardHeader>
                          <CardTitle className="text-2xl">Welcome Back</CardTitle>
                          <CardDescription>
                            Sign in to your account to continue
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <Form {...loginForm}>
                            <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                              <FormField
                                control={loginForm.control}
                                name="username"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Username</FormLabel>
                                    <FormControl>
                                      <Input placeholder="username" {...field} className="h-11" />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={loginForm.control}
                                name="password"
                                render={({ field }) => (
                                  <FormItem>
                                    <div className="flex justify-between items-center">
                                      <FormLabel>Password</FormLabel>
                                      <Button 
                                        variant="link" 
                                        type="button"
                                        size="sm"
                                        className="p-0 h-auto text-xs"
                                        onClick={() => setForgotPasswordMode(true)}
                                      >
                                        Forgot password?
                                      </Button>
                                    </div>
                                    <div className="relative">
                                      <FormControl>
                                        <Input 
                                          type={showPassword ? "text" : "password"} 
                                          placeholder="••••••••" 
                                          {...field} 
                                          className="h-11 pr-10"
                                        />
                                      </FormControl>
                                      <Button
                                        type="button"
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-0 top-0 h-full px-3 py-2 text-gray-400 hover:text-gray-700"
                                      >
                                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                      </Button>
                                    </div>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <Button type="submit" className="w-full h-11" disabled={loginMutation.isPending}>
                                {loginMutation.isPending ? 
                                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Please wait</> : 
                                  "Sign In"}
                              </Button>
                            </form>
                          </Form>
                          
                          <div className="mt-6">
                            <div className="relative">
                              <div className="absolute inset-0 flex items-center">
                                <Separator className="w-full" />
                              </div>
                              <div className="relative flex justify-center">
                                <span className="bg-background px-2 text-sm text-muted-foreground">
                                  Or continue with
                                </span>
                              </div>
                            </div>
                            
                            <div className="mt-4 grid grid-cols-2 gap-3">
                              <Button 
                                variant="outline" 
                                type="button" 
                                onClick={handleGoogleLogin}
                                className="h-11"
                              >
                                <FcGoogle className="mr-2 h-5 w-5" />
                                Google
                              </Button>
                              <Button 
                                variant="outline" 
                                type="button" 
                                onClick={handleAppleLogin}
                                className="h-11"
                              >
                                <LucideApple className="mr-2 h-5 w-5" />
                                Apple
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="flex flex-col space-y-2">
                          <div className="text-sm text-muted-foreground text-center">
                            Don't have an account?{" "}
                            <Button 
                              variant="link" 
                              className="p-0" 
                              onClick={() => setActiveTab("register")}
                            >
                              Register
                            </Button>
                          </div>
                        </CardFooter>
                      </Card>
                    </TabsContent>

                    <TabsContent value="register">
                      <Card className="border-t-4 border-t-primary shadow-lg">
                        <CardHeader>
                          <CardTitle className="text-2xl">Create an Account</CardTitle>
                          <CardDescription>
                            Join us to start tracking your fitness journey
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <Form {...registerForm}>
                            <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <FormField
                                  control={registerForm.control}
                                  name="firstName"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>First Name</FormLabel>
                                      <FormControl>
                                        <Input placeholder="John" {...field} className="h-11" />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                                
                                <FormField
                                  control={registerForm.control}
                                  name="lastName"
                                  render={({ field }) => (
                                    <FormItem>
                                      <FormLabel>Last Name</FormLabel>
                                      <FormControl>
                                        <Input placeholder="Doe" {...field} className="h-11" />
                                      </FormControl>
                                      <FormMessage />
                                    </FormItem>
                                  )}
                                />
                              </div>
                              
                              <FormField
                                control={registerForm.control}
                                name="username"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Username</FormLabel>
                                    <FormControl>
                                      <Input placeholder="username" {...field} className="h-11" />
                                    </FormControl>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={registerForm.control}
                                name="email"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Email</FormLabel>
                                    <FormControl>
                                      <Input type="email" placeholder="example@email.com" {...field} className="h-11" />
                                    </FormControl>
                                    <FormDescription className="text-xs">
                                      We'll send a verification email to this address
                                    </FormDescription>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={registerForm.control}
                                name="password"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Password</FormLabel>
                                    <div className="relative">
                                      <FormControl>
                                        <Input 
                                          type={showPassword ? "text" : "password"} 
                                          placeholder="••••••••" 
                                          {...field} 
                                          className="h-11 pr-10"
                                        />
                                      </FormControl>
                                      <Button
                                        type="button"
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-0 top-0 h-full px-3 py-2 text-gray-400 hover:text-gray-700"
                                      >
                                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                      </Button>
                                    </div>
                                    
                                    {/* Password strength meter */}
                                    {password && (
                                      <div className="mt-2 space-y-2">
                                        <div className="flex justify-between items-center text-xs">
                                          <span>Strength: {getStrengthText()}</span>
                                          <span>{passwordStrength}%</span>
                                        </div>
                                        <Progress value={passwordStrength} className={`h-1 ${getStrengthColor()}`} />
                                        
                                        <div className="grid grid-cols-2 gap-2 text-xs">
                                          <div className="flex items-center space-x-1">
                                            {/[A-Z]/.test(password) ? 
                                              <Check className="h-3 w-3 text-green-500" /> : 
                                              <X className="h-3 w-3 text-red-500" />
                                            }
                                            <span>Uppercase</span>
                                          </div>
                                          <div className="flex items-center space-x-1">
                                            {/[a-z]/.test(password) ? 
                                              <Check className="h-3 w-3 text-green-500" /> : 
                                              <X className="h-3 w-3 text-red-500" />
                                            }
                                            <span>Lowercase</span>
                                          </div>
                                          <div className="flex items-center space-x-1">
                                            {/[0-9]/.test(password) ? 
                                              <Check className="h-3 w-3 text-green-500" /> : 
                                              <X className="h-3 w-3 text-red-500" />
                                            }
                                            <span>Number</span>
                                          </div>
                                          <div className="flex items-center space-x-1">
                                            {/[^a-zA-Z0-9]/.test(password) ? 
                                              <Check className="h-3 w-3 text-green-500" /> : 
                                              <X className="h-3 w-3 text-red-500" />
                                            }
                                            <span>Special char</span>
                                          </div>
                                          <div className="flex items-center space-x-1">
                                            {password.length >= 8 ? 
                                              <Check className="h-3 w-3 text-green-500" /> : 
                                              <X className="h-3 w-3 text-red-500" />
                                            }
                                            <span>8+ characters</span>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <FormField
                                control={registerForm.control}
                                name="confirmPassword"
                                render={({ field }) => (
                                  <FormItem>
                                    <FormLabel>Confirm Password</FormLabel>
                                    <div className="relative">
                                      <FormControl>
                                        <Input 
                                          type={showConfirmPassword ? "text" : "password"} 
                                          placeholder="••••••••" 
                                          {...field} 
                                          className="h-11 pr-10"
                                        />
                                      </FormControl>
                                      <Button
                                        type="button"
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                        className="absolute right-0 top-0 h-full px-3 py-2 text-gray-400 hover:text-gray-700"
                                      >
                                        {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                      </Button>
                                    </div>
                                    <FormMessage />
                                  </FormItem>
                                )}
                              />
                              
                              <Button type="submit" className="w-full h-11" disabled={registerMutation.isPending}>
                                {registerMutation.isPending ? 
                                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Please wait</> : 
                                  "Create Account"}
                              </Button>
                            </form>
                          </Form>
                          
                          <div className="mt-6">
                            <div className="relative">
                              <div className="absolute inset-0 flex items-center">
                                <Separator className="w-full" />
                              </div>
                              <div className="relative flex justify-center">
                                <span className="bg-background px-2 text-sm text-muted-foreground">
                                  Or continue with
                                </span>
                              </div>
                            </div>
                            
                            <div className="mt-4 grid grid-cols-2 gap-3">
                              <Button 
                                variant="outline" 
                                type="button" 
                                onClick={handleGoogleLogin}
                                className="h-11"
                              >
                                <FcGoogle className="mr-2 h-5 w-5" />
                                Google
                              </Button>
                              <Button 
                                variant="outline" 
                                type="button" 
                                onClick={handleAppleLogin}
                                className="h-11"
                              >
                                <LucideApple className="mr-2 h-5 w-5" />
                                Apple
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="flex flex-col space-y-2">
                          <div className="text-sm text-muted-foreground text-center">
                            Already have an account?{" "}
                            <Button 
                              variant="link" 
                              className="p-0" 
                              onClick={() => setActiveTab("login")}
                            >
                              Login
                            </Button>
                          </div>
                        </CardFooter>
                      </Card>
                    </TabsContent>
                  </Tabs>
                </motion.div>
              </AnimatePresence>
            )}
          </div>
        </motion.div>
        
        {/* Image Side */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="md:w-1/2 bg-gradient-to-br from-primary to-primary/80 hidden md:flex flex-col justify-center items-center text-white p-12"
        >
          <div className="max-w-md text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="text-4xl font-bold mb-6"
            >
              Your Fitness Journey Begins Here
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="mb-8 text-lg"
            >
              Track workouts, set goals, and monitor your progress. Join our community of fitness enthusiasts.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
              className="flex justify-center space-x-8"
            >
              <div className="text-center">
                <div className="text-4xl font-bold">100K+</div>
                <div className="text-sm opacity-80">Active Users</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold">50M+</div>
                <div className="text-sm opacity-80">Workouts Tracked</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold">30K+</div>
                <div className="text-sm opacity-80">Goals Achieved</div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
      
      <Footer />
    </div>
  );
}