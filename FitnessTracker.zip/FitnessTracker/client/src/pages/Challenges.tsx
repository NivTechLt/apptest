import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import SubscriptionFeature from "@/components/SubscriptionFeature";
import { 
  Calendar, 
  Trophy, 
  Users, 
  Plus, 
  Check, 
  X, 
  Target, 
  Award, 
  ArrowUpRight, 
  Clock,
  CalendarClock,
  Share2
} from "lucide-react";
import { formatRelativeDate } from "@/lib/date-utils";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EXERCISE_TYPES } from "@/lib/constants";
// Extract string values from EXERCISE_TYPES for form use
const exerciseTypesList = EXERCISE_TYPES.map(type => type.value);

interface Friend {
  id: number;
  username: string;
  firstName?: string | null;
  lastName?: string | null;
}

interface Challenge {
  id: number;
  creatorId: number;
  title: string;
  description: string | null;
  exerciseType: string | null;
  targetMetric: string;
  targetValue: number;
  startDate: string;
  endDate: string;
  isPublic: boolean;
  createdAt: string;
}

interface ChallengeParticipant {
  id: number;
  challengeId: number;
  userId: number;
  joinedAt: string;
  currentProgress: number;
  completed: boolean;
  completedAt: string | null;
  user: {
    id: number;
    username: string;
    firstName?: string | null;
    lastName?: string | null;
  };
}

interface Friendship {
  id: number;
  userId: number;
  friendId: number;
  status: string;
  createdAt: string;
  sender?: {
    id: number;
    username: string;
    firstName?: string | null;
    lastName?: string | null;
  };
}

const createChallengeSchema = z.object({
  title: z.string().min(5, {message: "Title must be at least 5 characters"}),
  description: z.string().optional(),
  exerciseType: z.string().optional(),
  targetMetric: z.string({required_error: "Please select a target metric"}),
  targetValue: z.coerce.number().positive({message: "Target must be a positive number"}),
  startDate: z.string({required_error: "Start date is required"}),
  endDate: z.string({required_error: "End date is required"}),
  isPublic: z.boolean().default(true),
});

type CreateChallengeFormValues = z.infer<typeof createChallengeSchema>;

export default function Challenges() {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState("challenges");
  const [createChallengeOpen, setCreateChallengeOpen] = useState(false);
  const [progressValue, setProgressValue] = useState("");
  const [progressChallengeId, setProgressChallengeId] = useState<number | null>(null);
  const [progressDialogOpen, setProgressDialogOpen] = useState(false);

  // Challenges query
  const { data: userChallenges = [] } = useQuery({
    queryKey: ['/api/challenges/user'],
    queryFn: async () => {
      const res = await fetch('/api/challenges/user');
      if (!res.ok) throw new Error('Failed to fetch challenges');
      return res.json();
    },
    enabled: !!user && tab === "challenges",
  });

  // Public challenges query
  const { data: publicChallenges = [] } = useQuery({
    queryKey: ['/api/challenges/public'],
    queryFn: async () => {
      const res = await fetch('/api/challenges/public');
      if (!res.ok) throw new Error('Failed to fetch public challenges');
      return res.json();
    },
    enabled: !!user && tab === "discover",
  });

  // Friends query
  const { data: friends = [] } = useQuery({
    queryKey: ['/api/friends'],
    queryFn: async () => {
      const res = await fetch('/api/friends');
      if (!res.ok) throw new Error('Failed to fetch friends');
      return res.json();
    },
    enabled: !!user && tab === "friends",
  });

  // Friend requests query
  const { data: friendRequests = [] } = useQuery({
    queryKey: ['/api/friends/requests'],
    queryFn: async () => {
      const res = await fetch('/api/friends/requests');
      if (!res.ok) throw new Error('Failed to fetch friend requests');
      return res.json();
    },
    enabled: !!user && tab === "friends",
  });

  // Create challenge mutation
  const createChallengeMutation = useMutation({
    mutationFn: async (challenge: CreateChallengeFormValues) => {
      const res = await apiRequest('POST', '/api/challenges', challenge);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to create challenge');
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/challenges/user'] });
      toast({
        title: "Challenge created",
        description: "Your challenge has been created successfully",
      });
      setCreateChallengeOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to create challenge",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Join challenge mutation
  const joinChallengeMutation = useMutation({
    mutationFn: async (challengeId: number) => {
      const res = await apiRequest('POST', `/api/challenges/${challengeId}/join`);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to join challenge');
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/challenges/user'] });
      queryClient.invalidateQueries({ queryKey: ['/api/challenges/public'] });
      toast({
        title: "Challenge joined",
        description: "You have successfully joined the challenge",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to join challenge",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Update progress mutation
  const updateProgressMutation = useMutation({
    mutationFn: async ({ challengeId, progress }: { challengeId: number, progress: number }) => {
      const res = await apiRequest('POST', `/api/challenges/${challengeId}/progress`, { progress });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to update progress');
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/challenges/user'] });
      toast({
        title: "Progress updated",
        description: "Your challenge progress has been updated",
      });
      setProgressDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to update progress",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Send friend request mutation
  const sendFriendRequestMutation = useMutation({
    mutationFn: async (friendId: string) => {
      const res = await apiRequest('POST', '/api/friends/request', { friendId });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to send friend request');
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/friends'] });
      toast({
        title: "Friend request sent",
        description: "Your friend request has been sent",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to send friend request",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Respond to friend request mutation
  const respondFriendRequestMutation = useMutation({
    mutationFn: async ({ id, action }: { id: number, action: 'accept' | 'reject' }) => {
      const res = await apiRequest('POST', `/api/friends/respond/${id}`, { action });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to respond to friend request');
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/friends'] });
      queryClient.invalidateQueries({ queryKey: ['/api/friends/requests'] });
      toast({
        title: "Friend request updated",
        description: "Friend request has been updated",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to respond to friend request",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Remove friend mutation
  const removeFriendMutation = useMutation({
    mutationFn: async (friendId: number) => {
      const res = await apiRequest('DELETE', `/api/friends/${friendId}`);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to remove friend');
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/friends'] });
      toast({
        title: "Friend removed",
        description: "Friend has been removed from your list",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to remove friend",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Challenge form
  const form = useForm<CreateChallengeFormValues>({
    resolver: zodResolver(createChallengeSchema),
    defaultValues: {
      title: "",
      description: "",
      targetMetric: "duration",
      targetValue: 0,
      startDate: new Date().toISOString().substring(0, 10),
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().substring(0, 10),
      isPublic: true,
    },
  });

  const onSubmit = (values: CreateChallengeFormValues) => {
    createChallengeMutation.mutate(values);
  };

  const handleUpdateProgress = () => {
    if (!progressChallengeId || !progressValue || isNaN(Number(progressValue))) {
      toast({
        title: "Invalid input",
        description: "Please enter a valid number",
        variant: "destructive",
      });
      return;
    }
    
    updateProgressMutation.mutate({
      challengeId: progressChallengeId,
      progress: Number(progressValue)
    });
  };

  const openProgressDialog = (challengeId: number, currentProgress: number) => {
    setProgressChallengeId(challengeId);
    setProgressValue(currentProgress.toString());
    setProgressDialogOpen(true);
  };

  // Calculate challenge status
  const getChallengeStatus = (challenge: Challenge) => {
    const now = new Date();
    const startDate = new Date(challenge.startDate);
    const endDate = new Date(challenge.endDate);

    if (now < startDate) {
      return "upcoming";
    } else if (now > endDate) {
      return "completed";
    } else {
      return "active";
    }
  };

  // Calculate progress percentage
  const getProgressPercentage = (current: number, target: number) => {
    return Math.min(100, Math.round((current / target) * 100));
  };

  // Parse dates for display
  const formatDateRange = (startDate: string, endDate: string) => {
    return `${new Date(startDate).toLocaleDateString()} - ${new Date(endDate).toLocaleDateString()}`;
  };

  // Get display name
  const getDisplayName = (user: {username: string, firstName?: string | null, lastName?: string | null}) => {
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    } else if (user.firstName) {
      return user.firstName;
    } else {
      return user.username;
    }
  };

  // Function to get challenge participation status
  const isParticipatingInChallenge = (challenge: Challenge) => {
    // Creator is automatically a participant
    if (user?.id === challenge.creatorId) return true;
    
    // Check if the user is in the participants array
    // We'd need to fetch participants for each challenge, but for now we'll use a simpler approach
    return userChallenges.some((c: Challenge) => c.id === challenge.id);
  };

  // Get status badge color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-500";
      case "upcoming": return "bg-blue-500";
      case "completed": return "bg-gray-500";
      default: return "bg-gray-500";
    }
  };

  // Format friend name with initial if no full name
  const formatFriendName = (friend: Friend) => {
    if (friend.firstName && friend.lastName) {
      return `${friend.firstName} ${friend.lastName}`;
    } else if (friend.firstName) {
      return friend.firstName;
    } else {
      return friend.username;
    }
  };

  // Get initials for avatar
  const getInitials = (friend: Friend) => {
    if (friend.firstName && friend.lastName) {
      return `${friend.firstName[0]}${friend.lastName[0]}`.toUpperCase();
    } else if (friend.firstName) {
      return friend.firstName[0].toUpperCase();
    } else {
      return friend.username[0].toUpperCase();
    }
  };

  // State for friend username input
  const [friendUsername, setFriendUsername] = useState('');

  return (
    <div className="container mx-auto p-4 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Social Challenges</h1>
        <p className="text-muted-foreground">
          Create and join fitness challenges with your friends
        </p>
      </div>

      <SubscriptionFeature 
        featureKey="social_challenges"
        requiredTier="basic"
        showUpgradeButton
      >
        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-6">
            <TabsTrigger value="challenges">My Challenges</TabsTrigger>
            <TabsTrigger value="discover">Discover</TabsTrigger>
            <TabsTrigger value="friends">Friends</TabsTrigger>
          </TabsList>

          {/* My Challenges Tab */}
          <TabsContent value="challenges" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">My Challenges</h2>
              <SubscriptionFeature featureKey="create_challenges" requiredTier="premium">
                <Dialog open={createChallengeOpen} onOpenChange={setCreateChallengeOpen}>
                  <DialogTrigger asChild>
                    <Button><Plus className="mr-2 h-4 w-4" /> Create Challenge</Button>
                  </DialogTrigger>
                  <DialogContent className="h-[90vh] sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle>Create New Challenge</DialogTitle>
                      <DialogDescription>
                        Create a new fitness challenge to compete with friends.
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="max-h-[calc(90vh-180px)] overflow-y-auto pr-2">
                      <Form {...form}>
                        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                          <FormField
                            control={form.control}
                            name="title"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Challenge Title</FormLabel>
                                <FormControl>
                                  <Input placeholder="e.g. 30 Day Running Challenge" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name="description"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Description (optional)</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Describe your challenge" 
                                    {...field} 
                                    value={field.value || ""}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="exerciseType"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Exercise Type (optional)</FormLabel>
                                  <Select
                                    onValueChange={field.onChange}
                                    defaultValue={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Any exercise" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="any">Any exercise</SelectItem>
                                      {exerciseTypesList.map((type) => (
                                        <SelectItem key={type} value={type}>
                                          {type}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="targetMetric"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Target Metric</FormLabel>
                                  <Select
                                    onValueChange={field.onChange}
                                    defaultValue={field.value}
                                  >
                                    <FormControl>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select metric" />
                                      </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                      <SelectItem value="duration">Total Minutes</SelectItem>
                                      <SelectItem value="count">Workout Count</SelectItem>
                                      <SelectItem value="calories">Calories Burned</SelectItem>
                                    </SelectContent>
                                  </Select>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <FormField
                            control={form.control}
                            name="targetValue"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Target Value</FormLabel>
                                <FormControl>
                                  <Input type="number" {...field} />
                                </FormControl>
                                <FormDescription>
                                  The target value for the selected metric (e.g., 500 minutes, 10 workouts, 5000 calories)
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="startDate"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Start Date</FormLabel>
                                  <FormControl>
                                    <Input type="date" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="endDate"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>End Date</FormLabel>
                                  <FormControl>
                                    <Input type="date" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <FormField
                            control={form.control}
                            name="isPublic"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                                <div className="space-y-0.5">
                                  <FormLabel>Public Challenge</FormLabel>
                                  <FormDescription>
                                    Make this challenge visible to all users
                                  </FormDescription>
                                </div>
                                <FormControl>
                                  <input
                                    type="checkbox"
                                    checked={field.value}
                                    onChange={field.onChange}
                                    className="h-4 w-4"
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          
                          <DialogFooter>
                            <Button 
                              type="submit" 
                              disabled={createChallengeMutation.isPending}
                            >
                              {createChallengeMutation.isPending ? "Creating..." : "Create Challenge"}
                            </Button>
                          </DialogFooter>
                        </form>
                      </Form>
                    </div>
                  </DialogContent>
                </Dialog>
              </SubscriptionFeature>
            </div>
            
            {userChallenges.length === 0 ? (
              <div className="text-center p-8 border rounded-lg bg-muted/20">
                <Trophy className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No challenges yet</h3>
                <p className="text-muted-foreground mb-4">Join a challenge or create your own to get started</p>
                <div className="flex justify-center gap-2">
                  <Button 
                    variant="outline" 
                    onClick={() => setTab("discover")}
                  >
                    Discover Challenges
                  </Button>
                  <SubscriptionFeature featureKey="create_challenges" requiredTier="premium">
                    <Button onClick={() => setCreateChallengeOpen(true)}>
                      Create Challenge
                    </Button>
                  </SubscriptionFeature>
                </div>
              </div>
            ) : (
              <div className="grid gap-4">
                {userChallenges.map((challenge: Challenge) => {
                  const status = getChallengeStatus(challenge);
                  return (
                    <Card key={challenge.id} className="overflow-hidden">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Badge className={getStatusColor(status)}>{status}</Badge>
                              {challenge.creatorId === user?.id && (
                                <Badge variant="outline">Creator</Badge>
                              )}
                            </div>
                            <CardTitle>{challenge.title}</CardTitle>
                          </div>
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="outline">
                                <Trophy className="h-4 w-4 mr-1" /> Leaderboard
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Challenge Leaderboard</DialogTitle>
                                <DialogDescription>
                                  {challenge.title} - {formatDateRange(challenge.startDate, challenge.endDate)}
                                </DialogDescription>
                              </DialogHeader>
                              <LeaderboardContent challengeId={challenge.id} targetValue={challenge.targetValue} />
                            </DialogContent>
                          </Dialog>
                        </div>
                        <CardDescription className="mb-1">
                          {challenge.description || "No description provided"}
                        </CardDescription>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <CalendarClock className="h-3 w-3 mr-1" />
                          {formatDateRange(challenge.startDate, challenge.endDate)}
                          {challenge.exerciseType && (
                            <>
                              <Separator orientation="vertical" className="mx-2 h-3" />
                              <Target className="h-3 w-3 mr-1" />
                              {challenge.exerciseType}
                            </>
                          )}
                        </div>
                      </CardHeader>
                      
                      <CardContent className="pb-3">
                        <div className="mb-1">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Progress</span>
                            <span className="font-medium">
                              {challenge.targetMetric === 'duration' && '0 / ' + challenge.targetValue + ' mins'}
                              {challenge.targetMetric === 'count' && '0 / ' + challenge.targetValue + ' workouts'}
                              {challenge.targetMetric === 'calories' && '0 / ' + challenge.targetValue + ' calories'}
                            </span>
                          </div>
                          <Progress value={0} className="h-2" />
                        </div>
                      </CardContent>
                      
                      <CardFooter className="flex justify-between">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openProgressDialog(challenge.id, 0)}
                          disabled={status !== "active"}
                        >
                          Update Progress
                        </Button>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Share2 className="h-3 w-3 mr-1" />
                          {challenge.isPublic ? "Public" : "Private"} Challenge
                        </div>
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* Discover Tab */}
          <TabsContent value="discover" className="space-y-4">
            <h2 className="text-xl font-semibold mb-4">Discover Challenges</h2>
            
            {publicChallenges.length === 0 ? (
              <div className="text-center p-8 border rounded-lg bg-muted/20">
                <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-medium mb-2">No public challenges</h3>
                <p className="text-muted-foreground mb-4">Be the first to create a public challenge!</p>
                <SubscriptionFeature featureKey="create_challenges" requiredTier="premium">
                  <Button onClick={() => {
                    setTab("challenges");
                    setTimeout(() => setCreateChallengeOpen(true), 100);
                  }}>
                    Create Challenge
                  </Button>
                </SubscriptionFeature>
              </div>
            ) : (
              <div className="grid gap-4">
                {publicChallenges.map((challenge: Challenge) => {
                  const status = getChallengeStatus(challenge);
                  const participating = isParticipatingInChallenge(challenge);
                  
                  return (
                    <Card key={challenge.id} className="overflow-hidden">
                      <CardHeader className="pb-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Badge className={getStatusColor(status)}>{status}</Badge>
                              {participating && (
                                <Badge variant="outline">Joined</Badge>
                              )}
                            </div>
                            <CardTitle>{challenge.title}</CardTitle>
                          </div>
                        </div>
                        <CardDescription className="mb-1">
                          {challenge.description || "No description provided"}
                        </CardDescription>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <CalendarClock className="h-3 w-3 mr-1" />
                          {formatDateRange(challenge.startDate, challenge.endDate)}
                          {challenge.exerciseType && (
                            <>
                              <Separator orientation="vertical" className="mx-2 h-3" />
                              <Target className="h-3 w-3 mr-1" />
                              {challenge.exerciseType}
                            </>
                          )}
                        </div>
                      </CardHeader>
                      
                      <CardContent className="pb-3">
                        <div className="flex items-center gap-2">
                          <Target className="h-4 w-4 text-muted-foreground" />
                          <span>
                            {challenge.targetMetric === 'duration' && 'Target: ' + challenge.targetValue + ' minutes'}
                            {challenge.targetMetric === 'count' && 'Target: ' + challenge.targetValue + ' workouts'}
                            {challenge.targetMetric === 'calories' && 'Target: ' + challenge.targetValue + ' calories'}
                          </span>
                        </div>
                      </CardContent>
                      
                      <CardFooter>
                        <Button
                          onClick={() => joinChallengeMutation.mutate(challenge.id)}
                          disabled={participating || status === "completed" || joinChallengeMutation.isPending}
                          className="w-full"
                        >
                          {participating 
                            ? "Already Joined" 
                            : status === "completed" 
                            ? "Challenge Ended" 
                            : joinChallengeMutation.isPending 
                            ? "Joining..." 
                            : "Join Challenge"}
                        </Button>
                      </CardFooter>
                    </Card>
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* Friends Tab */}
          <TabsContent value="friends" className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold mb-4">Add a Friend</h2>
              <div className="flex gap-2">
                <Input 
                  placeholder="Enter username" 
                  value={friendUsername}
                  onChange={(e) => setFriendUsername(e.target.value)}
                  className="flex-1"
                />
                <Button 
                  onClick={() => {
                    if (friendUsername.trim()) {
                      sendFriendRequestMutation.mutate(friendUsername);
                      setFriendUsername('');
                    }
                  }}
                  disabled={!friendUsername.trim() || sendFriendRequestMutation.isPending}
                >
                  {sendFriendRequestMutation.isPending ? "Sending..." : "Send Request"}
                </Button>
              </div>
            </div>
            
            {friendRequests.length > 0 && (
              <div>
                <h2 className="text-xl font-semibold mb-4">Friend Requests</h2>
                <div className="space-y-3">
                  {friendRequests.map((request: Friendship) => (
                    <Card key={request.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarFallback>
                                {request.sender ? getInitials(request.sender) : "?"}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">
                                {request.sender ? formatFriendName(request.sender) : "Unknown User"}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                Sent {formatRelativeDate(new Date(request.createdAt))}
                              </p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => respondFriendRequestMutation.mutate({
                                id: request.id,
                                action: 'reject'
                              })}
                              disabled={respondFriendRequestMutation.isPending}
                            >
                              <X className="h-4 w-4 mr-1" /> Decline
                            </Button>
                            <Button 
                              size="sm"
                              onClick={() => respondFriendRequestMutation.mutate({
                                id: request.id,
                                action: 'accept'
                              })}
                              disabled={respondFriendRequestMutation.isPending}
                            >
                              <Check className="h-4 w-4 mr-1" /> Accept
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
            
            <div>
              <h2 className="text-xl font-semibold mb-4">My Friends</h2>
              {friends.length === 0 ? (
                <div className="text-center p-8 border rounded-lg bg-muted/20">
                  <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium mb-2">No friends yet</h3>
                  <p className="text-muted-foreground">Send a friend request to get started</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {friends.map((friend: Friend) => (
                    <Card key={friend.id}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Avatar>
                              <AvatarFallback>{getInitials(friend)}</AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{formatFriendName(friend)}</p>
                              <p className="text-xs text-muted-foreground">@{friend.username}</p>
                            </div>
                          </div>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => removeFriendMutation.mutate(friend.id)}
                            disabled={removeFriendMutation.isPending}
                          >
                            Remove
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </SubscriptionFeature>

      {/* Progress Update Dialog */}
      <Dialog open={progressDialogOpen} onOpenChange={setProgressDialogOpen}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>Update Challenge Progress</DialogTitle>
            <DialogDescription>
              Enter your current progress for this challenge
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="progress">Current Progress</Label>
              <Input
                id="progress"
                type="number"
                value={progressValue}
                onChange={(e) => setProgressValue(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              onClick={handleUpdateProgress}
              disabled={updateProgressMutation.isPending}
            >
              {updateProgressMutation.isPending ? "Updating..." : "Update Progress"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Leaderboard component
function LeaderboardContent({ challengeId, targetValue }: { challengeId: number, targetValue: number }) {
  // Calculate progress percentage for leaderboard
  const calcProgressPercentage = (current: number, target: number) => {
    return Math.min(100, Math.round((current / target) * 100));
  };
  const { data: leaderboard = [], isLoading } = useQuery({
    queryKey: [`/api/challenges/${challengeId}/leaderboard`],
    queryFn: async () => {
      const res = await fetch(`/api/challenges/${challengeId}/leaderboard`);
      if (!res.ok) throw new Error('Failed to fetch leaderboard');
      return res.json();
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin h-6 w-6 border-2 border-primary rounded-full border-t-transparent" />
      </div>
    );
  }

  return (
    <ScrollArea className="h-[300px]">
      <div className="space-y-2 pr-4">
        {leaderboard.length === 0 ? (
          <div className="text-center py-8">
            <Trophy className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
            <p className="text-muted-foreground">No participants yet</p>
          </div>
        ) : (
          leaderboard.map((participant: ChallengeParticipant, index: number) => (
            <div 
              key={participant.id} 
              className={`flex items-center p-3 border rounded-md ${index === 0 ? 'bg-amber-50 dark:bg-amber-950/20' : ''}`}
            >
              <div className="font-bold text-lg w-8 text-center">
                {index === 0 ? <Trophy className="h-5 w-5 text-amber-500 mx-auto" /> : `${index + 1}`}
              </div>
              
              <Avatar className="ml-2 mr-3">
                <AvatarFallback>
                  {participant.user.firstName?.[0] || participant.user.username[0]}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <div className="font-medium">
                  {participant.user.firstName && participant.user.lastName
                    ? `${participant.user.firstName} ${participant.user.lastName}`
                    : participant.user.firstName || participant.user.username}
                </div>
                
                <div className="flex items-center">
                  <div className="flex-1 mr-3">
                    <Progress 
                      value={calcProgressPercentage(participant.currentProgress, targetValue)} 
                      className="h-2"
                    />
                  </div>
                  <div className="text-sm whitespace-nowrap">
                    {participant.currentProgress} / {targetValue}
                    {participant.completed && (
                      <Badge variant="outline" className="ml-2 text-xs">
                        <Check className="h-3 w-3 mr-1" /> 
                        Completed
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </ScrollArea>
  );
}