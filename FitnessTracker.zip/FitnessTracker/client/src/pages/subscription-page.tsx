import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Check, Loader2, X, CreditCard, Clock, Award, Zap, Star, Shield, Lock, LifeBuoy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Redirect, Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface SubscriptionPlan {
  id: 'basic' | 'premium' | 'pro';
  name: string;
  price: number;
  description: string;
  features: string[];
}

interface SubscriptionPageProps {
  onClose?: () => void;
}

export default function SubscriptionPage({ onClose }: SubscriptionPageProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'cards' | 'comparison'>('cards');

  // Redirect if not logged in
  if (!user) {
    return <Redirect to="/auth" />;
  }

  const plans: SubscriptionPlan[] = [
    {
      id: 'basic',
      name: 'Basic',
      price: 4.99,
      description: 'Essential fitness tracking tools',
      features: [
        'Unlimited workout logs',
        'Basic workout statistics',
        'Goal tracking',
        'Progress visualization',
        'Weekly fitness summary',
        'Custom exercise types',
        'Dark/light mode support',
        'Mobile optimization',
        'Up to 10 active goals'
      ]
    },
    {
      id: 'premium',
      name: 'Premium',
      price: 9.99,
      description: 'Advanced fitness tracking and insights',
      features: [
        'All Basic features',
        'Advanced workout analytics',
        'Custom workout recommendations',
        'Progress reports',
        'Detailed performance metrics',
        'Export data to CSV/PDF',
        'Workout sharing on social media',
        'Achievement badges',
        'Up to 30 active goals',
        'Email workout reminders'
      ]
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 19.99,
      description: 'Complete fitness solution for serious athletes',
      features: [
        'All Premium features',
        'AI workout planning',
        'Nutrition tracking integration',
        'Coach consultation (2x/month)',
        'Priority support',
        'Early access to new features',
        'Personalized fitness insights',
        'Group challenges with friends',
        'Unlimited goals',
        'API access for data integration',
        'Exclusive premium workout templates'
      ]
    }
  ];

  const checkoutMutation = useMutation({
    mutationFn: async (planId: string) => {
      const res = await apiRequest("POST", `/api/checkout`, { planId });
      const data = await res.json();
      return data;
    },
    onSuccess: (data) => {
      // Redirect to Stripe checkout page
      window.location.href = data.url;
    },
    onError: (error: Error) => {
      toast({
        title: "Checkout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/cancel-subscription`);
      const data = await res.json();
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Subscription cancelled",
        description: "Your subscription has been cancelled successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to cancel subscription",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubscribe = (planId: string) => {
    setSelectedPlan(planId);
    checkoutMutation.mutate(planId);
  };

  const handleCancelSubscription = () => {
    cancelSubscriptionMutation.mutate();
  };

  const isLoading = checkoutMutation.isPending || cancelSubscriptionMutation.isPending;

  return (
    <div className="container max-w-6xl mx-auto px-4 py-8">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold mb-2">Choose Your Subscription Plan</h1>
        <p className="text-muted-foreground">Unlock premium features to enhance your fitness journey</p>
      </div>

      {/* Current subscription banner */}
      {user.isSubscribed && (
        <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 mb-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div>
              <h2 className="font-semibold text-lg">Current Subscription: {user.subscriptionTier}</h2>
              <p className="text-sm text-muted-foreground">
                {user.subscriptionEndDate && 
                  `Your subscription will renew on ${new Date(user.subscriptionEndDate).toLocaleDateString()}`}
              </p>
            </div>
            <Button 
              variant="outline" 
              className="mt-4 md:mt-0"
              onClick={handleCancelSubscription}
              disabled={isLoading}
            >
              {cancelSubscriptionMutation.isPending ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing</>
              ) : (
                "Cancel Subscription"
              )}
            </Button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card 
            key={plan.id}
            className={`relative overflow-hidden transition-all ${
              user.subscriptionTier === plan.id ? 'border-primary shadow-md' : ''
            }`}
          >
            {user.subscriptionTier === plan.id && (
              <div className="absolute top-0 right-0 bg-primary text-primary-foreground text-xs font-medium px-2 py-1 rounded-bl-md">
                Current Plan
              </div>
            )}
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription>{plan.description}</CardDescription>
              <div className="mt-2">
                <span className="text-3xl font-bold">${plan.price}</span>
                <span className="text-muted-foreground"> /month</span>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-primary shrink-0 mr-2" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button 
                className="w-full" 
                onClick={() => handleSubscribe(plan.id)}
                disabled={isLoading || user.subscriptionTier === plan.id}
                variant={user.subscriptionTier === plan.id ? "outline" : "default"}
              >
                {checkoutMutation.isPending && selectedPlan === plan.id ? (
                  <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing</>
                ) : user.subscriptionTier === plan.id ? (
                  "Current Plan"
                ) : (
                  "Subscribe"
                )}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}