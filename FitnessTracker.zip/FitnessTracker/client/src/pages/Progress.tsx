import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import SubscriptionFeature from "@/components/SubscriptionFeature";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
  AreaChart,
  Area
} from "recharts";
import { Flame } from "lucide-react";
import { Workout } from "@shared/schema";
import { 
  TrendingUp, 
  Calendar, 
  BarChart3, 
  PieChart as PieChartIcon, 
  Activity, 
  LineChart as LineChartIcon,
  Share2
} from "lucide-react";

const DEFAULT_USER_ID = 1;

export default function Progress() {
  const [userId] = useState(DEFAULT_USER_ID);
  const [viewMode, setViewMode] = useState("weekly");

  // Fetch all workouts for charts
  const { 
    data: workouts, 
    isLoading,
    error,
  } = useQuery<Workout[]>({
    queryKey: ['/api/workouts/user', userId],
    queryFn: async () => {
      const response = await fetch(`/api/workouts/user/${userId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch workouts');
      }
      return response.json() as Promise<Workout[]>;
    },
  });

  // Process workout data for charts
  const processedWorkouts = workouts || [] as Workout[];
  
  // Define interfaces for chart data
  interface ExerciseTypeItem {
    name: string;
    value: number;
  }
  
  interface DurationDayItem {
    day: string;
    duration: number;
  }
  
  // Exercise type distribution for pie chart
  const exerciseTypeData = processedWorkouts.reduce((acc: ExerciseTypeItem[], workout: Workout) => {
    const existing = acc.find((item: ExerciseTypeItem) => item.name === workout.exerciseType);
    if (existing) {
      existing.value++;
    } else {
      acc.push({ name: workout.exerciseType, value: 1 });
    }
    return acc;
  }, [] as ExerciseTypeItem[]);
  
  // Duration by day for bar chart
  const durationByDay = processedWorkouts.reduce((acc: DurationDayItem[], workout: Workout) => {
    const date = new Date(workout.date);
    const day = date.toLocaleDateString('en-US', { weekday: 'short' });
    
    const existing = acc.find((item: DurationDayItem) => item.day === day);
    if (existing) {
      existing.duration += workout.duration;
    } else {
      acc.push({ day, duration: workout.duration });
    }
    return acc;
  }, [] as DurationDayItem[]);
  
  // Colors for pie chart
  const COLORS = ['#3B82F6', '#10B981', '#8B5CF6', '#F59E0B', '#EF4444'];

  const { toast } = useToast();
  const { user } = useAuth();
  
  // Mock data for trend charts (would be calculated from real data in a full implementation)
  const trendData = [
    { name: 'Week 1', calories: 2400, duration: 180 },
    { name: 'Week 2', calories: 3000, duration: 210 },
    { name: 'Week 3', calories: 2800, duration: 200 },
    { name: 'Week 4', calories: 3600, duration: 250 },
    { name: 'Week 5', calories: 3200, duration: 220 },
    { name: 'Week 6', calories: 4100, duration: 280 },
  ];

  // Mock data for intensity distribution
  const intensityData = [
    { name: 'Low', value: 20 },
    { name: 'Medium', value: 45 },
    { name: 'High', value: 35 },
  ];

  // Share progress handler
  const handleShareProgress = () => {
    // In a full implementation, this would generate a shareable link or image
    toast({
      title: "Progress shared!",
      description: "Your workout progress has been copied to clipboard",
    });
  };

  return (
    <main className="flex-1 px-4 pt-4 pb-20">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Your Progress</h1>
        <SubscriptionFeature 
          featureKey="workoutSharing" 
          requiredTier="premium"
          fallback={
            <Button variant="outline" size="sm" disabled>
              <Share2 className="mr-2 h-4 w-4" />
              Share Progress
            </Button>
          }
        >
          <Button variant="outline" size="sm" onClick={handleShareProgress}>
            <Share2 className="mr-2 h-4 w-4" />
            Share Progress
          </Button>
        </SubscriptionFeature>
      </div>
      
      <Tabs defaultValue="weekly" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-4">
          <TabsTrigger value="weekly">
            <Calendar className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Weekly View</span>
            <span className="sm:hidden">Weekly</span>
          </TabsTrigger>
          <TabsTrigger value="activities">
            <PieChartIcon className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Activities</span>
            <span className="sm:hidden">Types</span>
          </TabsTrigger>
          <TabsTrigger value="trends">
            <TrendingUp className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Trends</span>
            <span className="sm:hidden">Trends</span>
          </TabsTrigger>
          <TabsTrigger value="advanced">
            <BarChart3 className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Advanced</span>
            <span className="sm:hidden">Pro</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Basic Weekly View - Available to all users */}
        <TabsContent value="weekly" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <Calendar className="mr-2 h-5 w-5 text-primary" />
                Workout Duration by Day
              </CardTitle>
              <CardDescription>See your activity throughout the week</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-64 w-full" />
              ) : error ? (
                <div className="bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 p-4 rounded-xl">
                  Error loading workout data
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={durationByDay}
                    margin={{
                      top: 5,
                      right: 20,
                      left: 0,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis unit="min" />
                    <RechartsTooltip
                      formatter={(value) => [`${value} minutes`, 'Duration']}
                    />
                    <Bar 
                      dataKey="duration" 
                      fill="var(--primary)" 
                      radius={[4, 4, 0, 0]} 
                    />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Activities Tab - Available to all users */}
        <TabsContent value="activities" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <PieChartIcon className="mr-2 h-5 w-5 text-primary" />
                Workout Types
              </CardTitle>
              <CardDescription>Distribution of your exercise activities</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-64 w-full" />
              ) : error ? (
                <div className="bg-red-50 dark:bg-red-950 text-red-700 dark:text-red-300 p-4 rounded-xl">
                  Error loading workout data
                </div>
              ) : (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={exerciseTypeData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({name, percent}: {name: string, percent: number}) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {exerciseTypeData.map((entry: ExerciseTypeItem, index: number) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={COLORS[index % COLORS.length]} 
                        />
                      ))}
                    </Pie>
                    <RechartsTooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Trends Tab - Premium Feature */}
        <TabsContent value="trends" className="space-y-4">
          <SubscriptionFeature 
            featureKey="advancedAnalytics" 
            requiredTier="premium"
            showUpgradeButton={true}
            fallback={
              <Card>
                <CardHeader>
                  <CardTitle>Premium Analytics</CardTitle>
                  <CardDescription>
                    Upgrade to Premium to access detailed trend analysis and performance tracking over time.
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center items-center h-64">
                  <TrendingUp className="h-16 w-16 text-muted-foreground/30" />
                </CardContent>
              </Card>
            }
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center text-base">
                    <Activity className="mr-2 h-5 w-5 text-primary" />
                    Calorie Burn Trend
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <AreaChart
                      data={trendData}
                      margin={{
                        top: 10,
                        right: 10,
                        left: 0,
                        bottom: 0,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <RechartsTooltip />
                      <Area type="monotone" dataKey="calories" stroke="#8884d8" fill="#8884d8" />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center text-base">
                    <LineChartIcon className="mr-2 h-5 w-5 text-primary" />
                    Workout Duration Trend
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart
                      data={trendData}
                      margin={{
                        top: 10,
                        right: 10,
                        left: 0,
                        bottom: 0,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <RechartsTooltip />
                      <Line type="monotone" dataKey="duration" stroke="#82ca9d" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </SubscriptionFeature>
        </TabsContent>
        
        {/* Advanced Tab - Pro Feature */}
        <TabsContent value="advanced" className="space-y-4">
          <SubscriptionFeature 
            featureKey="personalizedInsights" 
            requiredTier="pro"
            showUpgradeButton={true}
            fallback={
              <Card>
                <CardHeader>
                  <CardTitle>Pro Analytics</CardTitle>
                  <CardDescription>
                    Upgrade to Pro to unlock personalized insights, achievement forecasting, and detailed performance metrics.
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center items-center h-64">
                  <BarChart3 className="h-16 w-16 text-muted-foreground/30" />
                </CardContent>
              </Card>
            }
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center text-base">
                    Intensity Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={intensityData}
                        cx="50%"
                        cy="50%"
                        outerRadius={60}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {intensityData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={
                              index === 0 ? '#10B981' : 
                              index === 1 ? '#F59E0B' : 
                              '#EF4444'
                            } 
                          />
                        ))}
                      </Pie>
                      <RechartsTooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center text-base">
                    Personalized Insights
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[200px] flex flex-col justify-center">
                  <div className="space-y-4">
                    <div className="flex items-start gap-2">
                      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <TrendingUp className="h-3 w-3 text-primary" />
                      </div>
                      <p className="text-sm">Your strength training has improved by 15% over the last month.</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <Flame className="h-3 w-3 text-primary" />
                      </div>
                      <p className="text-sm">Try increasing cardio intensity to boost calorie burn.</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <Calendar className="h-3 w-3 text-primary" />
                      </div>
                      <p className="text-sm">You're most consistent with workouts on Tuesdays and Thursdays.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </SubscriptionFeature>
        </TabsContent>
      </Tabs>
    </main>
  );
}
