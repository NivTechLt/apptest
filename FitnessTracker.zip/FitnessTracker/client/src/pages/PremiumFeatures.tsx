import { useState } from 'react';
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import SubscriptionFeature from "@/components/SubscriptionFeature";
import ExportDataButton from "@/components/ExportDataButton";
import AchievementBadges from "@/components/AchievementBadges";
import AiWorkoutPlanner from "@/components/AiWorkoutPlanner";
import NutritionTracker from "@/components/NutritionTracker";
import CoachConsultation from "@/components/CoachConsultation";
import EmailReminders from "@/components/EmailReminders";
import {
  Diamond,
  Crown,
  Sparkles,
  BarChart3,
  Medal,
  FileDown,
  Share2,
  BellRing,
  Brain,
  Utensils,
  Users,
  HeartPulse,
  Rocket,
  Lock
} from "lucide-react";

export default function PremiumFeatures() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  
  // Helper to determine if a user has access to a specific tier
  const hasTierAccess = (tier: 'basic' | 'premium' | 'pro') => {
    if (!user || !user.isSubscribed) return false;
    
    switch(tier) {
      case 'basic':
        return ['basic', 'premium', 'pro'].includes(user.subscriptionTier || '');
      case 'premium':
        return ['premium', 'pro'].includes(user.subscriptionTier || '');
      case 'pro':
        return user.subscriptionTier === 'pro';
      default:
        return false;
    }
  };
  
  return (
    <main className="flex-1 px-4 pt-4 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Premium Features</h1>
          <p className="text-muted-foreground">Enhance your fitness journey with premium tools and features</p>
        </div>
        
        {!user?.isSubscribed && (
          <Button asChild>
            <Link href="/subscription">
              <Sparkles className="mr-2 h-4 w-4" />
              Upgrade Now
            </Link>
          </Button>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {/* Basic Tier Card */}
        <Card className={`border-2 ${hasTierAccess('basic') ? 'border-blue-500 dark:border-blue-400' : 'border-muted'}`}>
          <CardHeader className="pb-2">
            <Badge className={`mb-1 ${hasTierAccess('basic') ? 'bg-blue-500' : 'bg-muted-foreground'}`}>
              {hasTierAccess('basic') ? 'Current Plan' : 'Basic Plan'}
            </Badge>
            <CardTitle className="flex items-center gap-2">
              <Diamond className="h-5 w-5 text-blue-500" />
              Basic
            </CardTitle>
            <CardDescription>
              Essential features for beginners
            </CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <HeartPulse className="h-4 w-4 text-green-500" />
                Unlimited workout logging
              </li>
              <li className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-green-500" />
                Basic analytics &amp; charts
              </li>
              <li className="flex items-center gap-2">
                <Medal className="h-4 w-4 text-green-500" />
                Up to 10 goals tracking
              </li>
              <li className="flex items-center gap-2">
                <Lock className="h-4 w-4 text-muted-foreground" />
                No advanced features
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button 
              variant={hasTierAccess('basic') ? "outline" : "default"} 
              className="w-full"
              asChild
            >
              <Link href="/subscription">
                {hasTierAccess('basic') ? 'Current Plan' : 'Get Basic'}
              </Link>
            </Button>
          </CardFooter>
        </Card>
        
        {/* Premium Tier Card */}
        <Card className={`border-2 ${hasTierAccess('premium') ? 'border-purple-500 dark:border-purple-400' : 'border-muted'}`}>
          <CardHeader className="pb-2">
            <Badge className={`mb-1 ${hasTierAccess('premium') ? 'bg-purple-500' : 'bg-muted-foreground'}`}>
              {hasTierAccess('premium') ? 'Current Plan' : 'Most Popular'}
            </Badge>
            <CardTitle className="flex items-center gap-2">
              <Crown className="h-5 w-5 text-purple-500" />
              Premium
            </CardTitle>
            <CardDescription>
              Advanced tools for serious fitness
            </CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <HeartPulse className="h-4 w-4 text-green-500" />
                Everything in Basic
              </li>
              <li className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-green-500" />
                Advanced analytics &amp; trends
              </li>
              <li className="flex items-center gap-2">
                <Medal className="h-4 w-4 text-green-500" />
                Achievement badges
              </li>
              <li className="flex items-center gap-2">
                <FileDown className="h-4 w-4 text-green-500" />
                Export workout data
              </li>
              <li className="flex items-center gap-2">
                <Share2 className="h-4 w-4 text-green-500" />
                Share progress
              </li>
              <li className="flex items-center gap-2">
                <BellRing className="h-4 w-4 text-green-500" />
                Email reminders
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button 
              variant={hasTierAccess('premium') ? "outline" : "default"} 
              className="w-full"
              asChild
            >
              <Link href="/subscription">
                {hasTierAccess('premium') ? 'Current Plan' : 'Get Premium'}
              </Link>
            </Button>
          </CardFooter>
        </Card>
        
        {/* Pro Tier Card */}
        <Card className={`border-2 ${hasTierAccess('pro') ? 'border-amber-500 dark:border-amber-400' : 'border-muted'}`}>
          <CardHeader className="pb-2">
            <Badge className={`mb-1 ${hasTierAccess('pro') ? 'bg-amber-500' : 'bg-muted-foreground'}`}>
              {hasTierAccess('pro') ? 'Current Plan' : 'Ultimate'}
            </Badge>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-amber-500" />
              Pro
            </CardTitle>
            <CardDescription>
              Elite features for fitness pros
            </CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <HeartPulse className="h-4 w-4 text-green-500" />
                Everything in Premium
              </li>
              <li className="flex items-center gap-2">
                <Brain className="h-4 w-4 text-green-500" />
                AI workout planning
              </li>
              <li className="flex items-center gap-2">
                <Utensils className="h-4 w-4 text-green-500" />
                Nutrition tracking
              </li>
              <li className="flex items-center gap-2">
                <Users className="h-4 w-4 text-green-500" />
                Coach consultations
              </li>
              <li className="flex items-center gap-2">
                <Rocket className="h-4 w-4 text-green-500" />
                Personalized insights
              </li>
              <li className="flex items-center gap-2">
                <Medal className="h-4 w-4 text-green-500" />
                Unlimited goals
              </li>
            </ul>
          </CardContent>
          <CardFooter>
            <Button 
              variant={hasTierAccess('pro') ? "outline" : "default"} 
              className="w-full"
              asChild
            >
              <Link href="/subscription">
                {hasTierAccess('pro') ? 'Current Plan' : 'Get Pro'}
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-5 mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="data">Data Tools</TabsTrigger>
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
          <TabsTrigger value="nutrition">Nutrition</TabsTrigger>
          <TabsTrigger value="coaching">Coaching</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard
              title="Export Data"
              icon={<FileDown className="h-5 w-5 text-green-500" />}
              description="Download your workout history in CSV format"
              tier="premium"
            />
            <FeatureCard
              title="Achievement Badges"
              icon={<Medal className="h-5 w-5 text-amber-500" />}
              description="Earn badges based on your fitness accomplishments"
              tier="premium"
            />
            <FeatureCard
              title="Progress Sharing"
              icon={<Share2 className="h-5 w-5 text-blue-500" />}
              description="Share your fitness journey on social media"
              tier="premium"
            />
            <FeatureCard
              title="AI Workout Planner"
              icon={<Brain className="h-5 w-5 text-purple-500" />}
              description="Get personalized workout suggestions from AI"
              tier="pro"
            />
            <FeatureCard
              title="Nutrition Tracking"
              icon={<Utensils className="h-5 w-5 text-amber-500" />}
              description="Log and analyze your daily nutrition intake"
              tier="pro"
            />
            <FeatureCard
              title="Coach Consultation"
              icon={<Users className="h-5 w-5 text-blue-500" />}
              description="Book one-on-one sessions with fitness experts"
              tier="pro"
            />
          </div>
        </TabsContent>
        
        {/* Data Tools Tab */}
        <TabsContent value="data" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileDown className="h-5 w-5 text-primary" />
                Export Your Workout Data
              </CardTitle>
              <CardDescription>
                Download your workout history and statistics
              </CardDescription>
            </CardHeader>
            <CardContent className="flex items-center justify-center py-6">
              <SubscriptionFeature
                featureKey="exportData"
                requiredTier="premium"
                showUpgradeButton={true}
                fallback={
                  <div className="text-center space-y-4">
                    <Lock className="h-12 w-12 text-muted-foreground mx-auto" />
                    <p className="text-muted-foreground max-w-sm">
                      Upgrade to Premium to export your workout data and stats in CSV format
                    </p>
                    <Button asChild>
                      <Link href="/subscription">
                        <Crown className="mr-2 h-4 w-4" />
                        Upgrade to Premium
                      </Link>
                    </Button>
                  </div>
                }
              >
                <div className="text-center space-y-6 max-w-md">
                  <p>Download your complete workout history as a CSV file, perfect for advanced analysis in spreadsheets or other tools.</p>
                  <ExportDataButton className="w-full" />
                </div>
              </SubscriptionFeature>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Medal className="h-5 w-5 text-primary" />
                Achievement Badges
              </CardTitle>
              <CardDescription>
                Earn badges as you reach fitness milestones
              </CardDescription>
            </CardHeader>
            <CardContent className="py-6">
              <SubscriptionFeature
                featureKey="achievementBadges"
                requiredTier="premium"
                showUpgradeButton={true}
                fallback={
                  <div className="text-center space-y-4">
                    <Lock className="h-12 w-12 text-muted-foreground mx-auto" />
                    <p className="text-muted-foreground max-w-sm">
                      Upgrade to Premium to unlock achievement badges and track your milestones
                    </p>
                    <Button asChild>
                      <Link href="/subscription">
                        <Crown className="mr-2 h-4 w-4" />
                        Upgrade to Premium
                      </Link>
                    </Button>
                  </div>
                }
              >
                <AchievementBadges />
              </SubscriptionFeature>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Analysis Tab */}
        <TabsContent value="analysis" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5 text-primary" />
                AI Workout Planning
              </CardTitle>
              <CardDescription>
                Get personalized workout recommendations
              </CardDescription>
            </CardHeader>
            <CardContent className="py-6">
              <SubscriptionFeature
                featureKey="aiPlanning"
                requiredTier="pro"
                showUpgradeButton={true}
                fallback={
                  <div className="text-center space-y-4">
                    <Lock className="h-12 w-12 text-muted-foreground mx-auto" />
                    <p className="text-muted-foreground max-w-sm">
                      Upgrade to Pro to access AI-powered workout recommendations
                    </p>
                    <Button asChild>
                      <Link href="/subscription">
                        <Sparkles className="mr-2 h-4 w-4" />
                        Upgrade to Pro
                      </Link>
                    </Button>
                  </div>
                }
              >
                <AiWorkoutPlanner />
              </SubscriptionFeature>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BellRing className="h-5 w-5 text-primary" />
                Email Reminders
              </CardTitle>
              <CardDescription>
                Set up reminders for your workouts and goals
              </CardDescription>
            </CardHeader>
            <CardContent className="py-6">
              <SubscriptionFeature
                featureKey="emailReminders"
                requiredTier="premium"
                showUpgradeButton={true}
                fallback={
                  <div className="text-center space-y-4">
                    <Lock className="h-12 w-12 text-muted-foreground mx-auto" />
                    <p className="text-muted-foreground max-w-sm">
                      Upgrade to Premium to set up email reminders for your workouts
                    </p>
                    <Button asChild>
                      <Link href="/subscription">
                        <Crown className="mr-2 h-4 w-4" />
                        Upgrade to Premium
                      </Link>
                    </Button>
                  </div>
                }
              >
                <EmailReminders />
              </SubscriptionFeature>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Nutrition Tab */}
        <TabsContent value="nutrition" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Utensils className="h-5 w-5 text-primary" />
                Nutrition Tracking
              </CardTitle>
              <CardDescription>
                Track your daily nutritional intake
              </CardDescription>
            </CardHeader>
            <CardContent className="py-6">
              <SubscriptionFeature
                featureKey="nutritionTracking"
                requiredTier="pro"
                showUpgradeButton={true}
                fallback={
                  <div className="text-center space-y-4">
                    <Lock className="h-12 w-12 text-muted-foreground mx-auto" />
                    <p className="text-muted-foreground max-w-sm">
                      Upgrade to Pro to access comprehensive nutrition tracking
                    </p>
                    <Button asChild>
                      <Link href="/subscription">
                        <Sparkles className="mr-2 h-4 w-4" />
                        Upgrade to Pro
                      </Link>
                    </Button>
                  </div>
                }
              >
                <NutritionTracker />
              </SubscriptionFeature>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Coaching Tab */}
        <TabsContent value="coaching" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Coach Consultation
              </CardTitle>
              <CardDescription>
                Book personalized sessions with fitness coaches
              </CardDescription>
            </CardHeader>
            <CardContent className="py-6">
              <SubscriptionFeature
                featureKey="coachConsultation"
                requiredTier="pro"
                showUpgradeButton={true}
                fallback={
                  <div className="text-center space-y-4">
                    <Lock className="h-12 w-12 text-muted-foreground mx-auto" />
                    <p className="text-muted-foreground max-w-sm">
                      Upgrade to Pro to book one-on-one sessions with fitness coaches
                    </p>
                    <Button asChild>
                      <Link href="/subscription">
                        <Sparkles className="mr-2 h-4 w-4" />
                        Upgrade to Pro
                      </Link>
                    </Button>
                  </div>
                }
              >
                <CoachConsultation />
              </SubscriptionFeature>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  );
}

// Feature card for the overview tab
function FeatureCard({ 
  title, 
  icon, 
  description, 
  tier 
}: { 
  title: string; 
  icon: React.ReactNode; 
  description: string; 
  tier: 'basic' | 'premium' | 'pro' 
}) {
  const { user } = useAuth();
  const hasAccess = user?.isSubscribed && (
    tier === 'basic' ? ['basic', 'premium', 'pro'].includes(user.subscriptionTier || '') :
    tier === 'premium' ? ['premium', 'pro'].includes(user.subscriptionTier || '') :
    user.subscriptionTier === 'pro'
  );
  
  const getTierBadge = () => {
    switch(tier) {
      case 'basic':
        return <Badge className="bg-blue-500">Basic</Badge>;
      case 'premium':
        return <Badge className="bg-purple-500">Premium</Badge>;
      case 'pro':
        return <Badge className="bg-amber-500">Pro</Badge>;
    }
  };
  
  return (
    <Card className={`${hasAccess ? 'border-primary' : 'border-muted'}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="rounded-full p-2 bg-primary/10">
            {icon}
          </div>
          {getTierBadge()}
        </div>
        <CardTitle className="mt-2">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardFooter>
        {hasAccess ? (
          <Button variant="outline" className="w-full">Available</Button>
        ) : (
          <Button className="w-full" asChild>
            <Link href="/subscription">Upgrade</Link>
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}