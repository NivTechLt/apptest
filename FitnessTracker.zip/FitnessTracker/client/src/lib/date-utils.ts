import { format, addDays, startOfWeek, endOfWeek } from "date-fns";

/**
 * Get the week range as a formatted string
 * @param date A date within the week
 * @returns Formatted string like "Jul 10 - Jul 16"
 */
export function getWeekRangeString(date: Date): string {
  const start = startOfWeek(date, { weekStartsOn: 1 }); // Start from Monday
  const end = endOfWeek(date, { weekStartsOn: 1 }); // End on Sunday
  return `${format(start, 'MMM d')} - ${format(end, 'MMM d')}`;
}

/**
 * Get an array of day names for the week
 * @returns Array of weekday abbreviations
 */
export function getWeekdayNames(): string[] {
  return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
}

/**
 * Format a date relative to today (Today, Yesterday, or formatted date)
 * @param date The date to format
 * @returns Formatted date string
 */
export function formatRelativeDate(date: Date): string {
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  
  if (isSameDay(date, today)) {
    return 'Today';
  } else if (isSameDay(date, yesterday)) {
    return 'Yesterday';
  } else {
    return format(date, 'MMM d');
  }
}

/**
 * Check if two dates are the same day
 * @param date1 First date
 * @param date2 Second date
 * @returns True if same day, false otherwise
 */
function isSameDay(date1: Date, date2: Date): boolean {
  return (
    date1.getDate() === date2.getDate() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getFullYear() === date2.getFullYear()
  );
}
