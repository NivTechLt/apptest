import { 
  Activity, 
  Dumbbell, 
  Bike, 
  GlassWater, 
  Heart, 
  Plus 
} from "lucide-react";
import React, { ReactNode } from "react";

export const EXERCISE_TYPES = [
  { value: 'Running', label: 'Running', icon: 'activity' },
  { value: 'Weight Training', label: 'Weights', icon: 'dumbbell' },
  { value: 'Cycling', label: 'Cycling', icon: 'bike' },
  { value: 'Swimming', label: 'Swimming', icon: 'water' },
  { value: 'Yoga', label: 'Yoga', icon: 'heart' },
  { value: 'Other', label: 'Other', icon: 'plus' },
];

export function getWorkoutIcon(exerciseType: string): ReactNode {
  switch (exerciseType) {
    case 'Running':
      return React.createElement(Activity, { className: "h-5 w-5 text-primary" });
    case 'Weight Training':
      return React.createElement(Dumbbell, { className: "h-5 w-5 text-purple-500" });
    case 'Cycling':
      return React.createElement(Bike, { className: "h-5 w-5 text-green-500" });
    case 'Swimming':
      return React.createElement(GlassWater, { className: "h-5 w-5 text-blue-500" });
    case 'Yoga':
      return React.createElement(Heart, { className: "h-5 w-5 text-orange-500" });
    default:
      return React.createElement(Plus, { className: "h-5 w-5 text-gray-500" });
  }
}
