import { User } from '@shared/schema';

type SubscriptionTier = 'basic' | 'premium' | 'pro';

// Map of features to the minimum subscription level required
export const FEATURE_ACCESS_MAP = {
  // Basic features (available to all paid subscribers)
  unlimitedWorkouts: ['basic', 'premium', 'pro'],
  basicStats: ['basic', 'premium', 'pro'],
  goalTracking: ['basic', 'premium', 'pro'],
  progressVisualization: ['basic', 'premium', 'pro'],
  weeklyFitnessSummary: ['basic', 'premium', 'pro'],
  customExerciseTypes: ['basic', 'premium', 'pro'],
  darkMode: ['basic', 'premium', 'pro'],
  mobileOptimization: ['basic', 'premium', 'pro'],
  
  // Social features
  social_challenges: ['basic', 'premium', 'pro'],
  create_challenges: ['premium', 'pro'],
  
  // Premium features
  advancedAnalytics: ['premium', 'pro'],
  customRecommendations: ['premium', 'pro'],
  progressReports: ['premium', 'pro'],
  detailedMetrics: ['premium', 'pro'],
  exportData: ['premium', 'pro'],
  workoutSharing: ['premium', 'pro'],
  achievementBadges: ['premium', 'pro'],
  emailReminders: ['premium', 'pro'],
  bodyCompositionAnalysis: ['premium', 'pro'],
  
  // Pro features
  aiPlanning: ['pro'],
  nutritionTracking: ['pro'],
  coachConsultation: ['pro'],
  prioritySupport: ['pro'],
  earlyAccess: ['pro'],
  personalizedInsights: ['pro'],
  groupChallenges: ['pro'],
  unlimitedGoals: ['pro'],
  apiAccess: ['pro'],
  premiumTemplates: ['pro']
};

// Maximum number of active goals by subscription tier
export const MAX_GOALS = {
  free: 3,
  basic: 10,
  premium: 30,
  pro: Infinity
};

/**
 * Check if a user has access to a specific feature based on their subscription
 * @param user The user object
 * @param featureKey The feature key to check
 * @returns boolean indicating if the user has access to the feature
 */
export function hasFeatureAccess(
  user: User | null, 
  featureKey: keyof typeof FEATURE_ACCESS_MAP
): boolean {
  if (!user) return false;
  
  // Free users have access to a limited set of basic features only
  if (!user.isSubscribed) {
    return false;
  }
  
  const userTier = user.subscriptionTier || '';
  if (!isValidSubscriptionTier(userTier)) {
    return false;
  }
  return FEATURE_ACCESS_MAP[featureKey].includes(userTier);
}

/**
 * Get the maximum number of goals a user can create based on their subscription
 * @param user The user object
 * @returns number representing max allowed goals
 */
export function getMaxGoals(user: User | null): number {
  if (!user) return MAX_GOALS.free;
  
  if (!user.isSubscribed) {
    return MAX_GOALS.free;
  }
  
  const tier = user.subscriptionTier || '';
  if (!isValidSubscriptionTier(tier)) {
    return MAX_GOALS.free;
  }
  
  switch(tier) {
    case 'basic': return MAX_GOALS.basic;
    case 'premium': return MAX_GOALS.premium;
    case 'pro': return MAX_GOALS.pro;
    default: return MAX_GOALS.free;
  }
}

/**
 * Check if a string is a valid subscription tier
 */
export function isValidSubscriptionTier(tier: string): tier is SubscriptionTier {
  return ['basic', 'premium', 'pro'].includes(tier);
}